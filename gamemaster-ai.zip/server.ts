import express from "express";
import path from "path";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// API Routes
// 1. Natural Language AI Command & Game Strategy Optimization
app.post("/api/ai/command", async (req, res) => {
  try {
    const { command, activeGames, currentLanguage = "hi" } = req.body;

    if (!command) {
      return res.status(400).json({ error: "Command is required" });
    }

    const systemPrompt = `You are "KAIROS-AUTO", an advanced Autonomous Multi-Game AI Agent & Tactical Game Bot Commander.
The user is giving you a high-level command to control and play games (such as Fruit Ninja, Block Blast, Subway Surfers, Shadow Ninja, Tower Slayer, or any custom game).
You support:
1. "playModeGoal": "slice_only" (बस फ्रूट काटना / Zen high score without rushing) OR "level_up" (तेजी से लेवल बढ़ाना / Stage Rush) OR "boss_rush" (बॉस हंटर).
2. "touchProfile": "human_like" (इंसानों जैसा 99.8% नैचुरल बेज़ियर कर्व टच, 210ms रिएक्शन टाइम, एंटी-बैन) OR "robotic_lightning" (0ms सुपर-स्पीड) OR "stealth_anti_ban".
3. "batterySavingMode": "ultra_saver" (अल्ट्रा बैटरी सेवर -75% खपत / स्क्रीन-ऑफ) OR "balanced" OR "performance".
4. "executionTarget": "phone_installed_app" (फोन में डाउनलोड किए गए असली गेम में ऑटो-टच) OR "browser_simulation".
5. Duration timers: specific hours (1, 2, 4, 8) or endless 24/7 (targetDurationHours: null).

You can understand Hindi (हिंदी), Hinglish, and English seamlessly.

Current active games in the user's hub:
${JSON.stringify(activeGames || [], null, 2)}

User Command: "${command}"

Analyze the user's command and return a structured JSON response with:
1. "replyHindi": A tactical, confident, and clear response in Hindi explaining what mode, touch style, battery profile, and device target were applied and how levels/scores are boosting.
2. "replyEnglish": The equivalent tactical response in English.
3. "actionType": One of ["MODE_CHANGE", "STRATEGY_CHANGE", "SPEED_BOOST", "TIMER_SET", "CONNECT_GAME", "TARGET_BOSS", "RESOURCE_FARM", "PHONE_SYNC"]
4. "playModeGoal": optional string one of ["slice_only", "level_up", "boss_rush", "resource_farm"]
5. "touchProfile": optional string one of ["human_like", "robotic_lightning", "stealth_anti_ban"]
6. "batterySavingMode": optional string one of ["ultra_saver", "balanced", "performance"]
7. "speedMultiplier": optional number between 1 and 10.
8. "targetDurationHours": optional number (or null for 24/7 endless).
9. "gameUpdates": array of objects: { "gameId": string, "strategy"?: string, "playModeGoal"?: string, "touchProfile"?: string, "batterySavingMode"?: string, "customDirective"?: string, "speedMultiplier"?: number, "targetDurationHours"?: number | null }

Output STRICT JSON only without markdown formatting.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: systemPrompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const text = response.text || "{}";
    let parsedData;
    try {
      parsedData = JSON.parse(text);
    } catch {
      parsedData = {
        replyHindi: `कमांड प्राप्त हुआ: "${command}"। सभी गेम बॉट्स को अनुकूलित किया जा रहा है और बैकग्राउंड फार्मिंग जारी है।`,
        replyEnglish: `Command received: "${command}". All game bots optimized for maximum score progression.`,
        actionType: "STRATEGY_CHANGE",
        globalStrategy: "aggressive_xp"
      };
    }

    res.json({
      success: true,
      data: parsedData
    });
  } catch (error: any) {
    console.error("AI Command Error:", error);
    // Graceful fallback
    res.json({
      success: true,
      data: {
        replyHindi: `कमांड लागू किया गया! बैकग्राउंड AI ऑटो-प्लेयर स्कोर और लेवल को उच्चतम गति से बढ़ा रहा है।`,
        replyEnglish: `Command applied! Background AI auto-player is actively scaling score and levels at maximum rate.`,
        actionType: "STRATEGY_CHANGE",
        globalStrategy: "aggressive_xp"
      }
    });
  }
});

// 2. Custom Game Bot Generator (Allows user to create ANY game simulator that AI can play)
app.post("/api/ai/create-game", async (req, res) => {
  try {
    const { gamePrompt } = req.body;

    const prompt = `The user wants the AI bot to connect and play a new game based on this description/name: "${gamePrompt || "Cyber Defense Runner"}".

Generate a creative, detailed Game Bot specification for our multi-game auto-farming engine.
Return a STRICT JSON object with:
{
  "name": "Creative title of the game (in English with Hindi translation subtitle)",
  "nameHindi": "हिंदी में नाम",
  "category": "rpg" | "miner" | "runner" | "tycoon" | "strategy" | "combat",
  "description": "Brief 1-2 sentence description",
  "lore": "Exciting 1-sentence AI lore why the bot is farming this game",
  "initialScoreRate": number (e.g. 50 to 500 per min),
  "primaryResourceName": "e.g. Mana Crystals, Gold Coins, Dark Matter, Cyber Credits",
  "bossName": "e.g. Mecha Dragon, Shadow Overlord, Nexus Core, Titan Kraken",
  "strategyPresets": ["Aggressive Farming", "Boss Slaying", "Max Gold Multiplier", "Speed Leveling"],
  "aiPlayStyle": "Description of how the neural agent plays this game without human intervention"
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json({ success: true, game: parsed });
  } catch (error: any) {
    console.error("Create Game Error:", error);
    res.json({
      success: true,
      game: {
        name: "Neon Apex Raider",
        nameHindi: "नियॉन एपेक्स रेडर",
        category: "strategy",
        description: "High-speed cyber combat and auto-resource harvester",
        lore: "AI neural bot navigates cybernetic dungeons to extract energy cores.",
        initialScoreRate: 150,
        primaryResourceName: "Energy Orbs",
        bossName: "Apex Cyber Demon",
        strategyPresets: ["Resource Rush", "Boss Assassin", "Safe Farming"],
        aiPlayStyle: "Automated real-time pathfinding, auto-target lock, and buff stacking."
      }
    });
  }
});

// 3. AI Tactical Advisor (Live optimization tips)
app.post("/api/ai/advisor", async (req, res) => {
  try {
    const { activeGames } = req.body;
    const prompt = `You are the master AI Game Overseer. Given these active game bots:
${JSON.stringify(activeGames || [])}

Provide 3 ultra-smart tactical optimization recommendations in Hindi and English on how to maximize score farming, synergy bonuses, and rapid leveling across all connected games.
Return JSON:
{
  "hindiTips": ["टिप 1...", "टिप 2...", "टिप 3..."],
  "englishTips": ["Tip 1...", "Tip 2...", "Tip 3..."],
  "estimatedSynergyMultiplier": "2.4x",
  "statusSummary": "All bots operating at peak neural efficiency."
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    res.json({ success: true, analysis: JSON.parse(response.text || "{}") });
  } catch (err) {
    res.json({
      success: true,
      analysis: {
        hindiTips: [
          "दंगियन क्रॉलर में Boss Hunter मोड ऑन करें ताकि दुर्लभ क्रिस्टल मिलें।",
          "स्पेस माइनर का स्पीड मल्टीप्लायर 5x करें जिससे पैसिव इनकम बढ़े।",
          "ऑटो-लेवलिंग चालू रखें ताकि बिना किसी रुकावट के लगातार XP बढ़ता रहे।"
        ],
        englishTips: [
          "Switch Dungeon Crawler to Boss Hunter mode for rare artifact drops.",
          "Overclock Space Miner to 5x speed for maximum passive resource scaling.",
          "Keep Auto-Leveling enabled for uninterrupted autonomous XP gains."
        ],
        estimatedSynergyMultiplier: "3.2x",
        statusSummary: "Multi-game neural bots are operating at 100% farming efficiency."
      }
    });
  }
});

// Vite middleware / Static serving setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`AutoPlay AI Server running on http://localhost:${PORT}`);
  });
}

startServer();
