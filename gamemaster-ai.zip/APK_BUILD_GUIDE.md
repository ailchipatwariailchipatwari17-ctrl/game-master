# 📱 AutoPlay AI - 1-Click APK निर्माण मार्गदर्शिका (APK Builder & ZIP Guide)

इस ZIP में वह सब कुछ पहले से तैयार है जिससे आप **बिना किसी जटिल कोडिंग के 1 क्लिक में Android APK** बना सकें।

---

## ⚡ विधि 1: PWA Builder द्वारा 1-क्लिक में APK बनाएं (अनुशंसित एवं सबसे तेज़)

1. ऐप को AI Studio में खोलें या Share/Deploy करें।
2. **[PWABuilder.com](https://www.pwabuilder.com/)** पर जाएं।
3. अपने ऐप का URL डालें (प्रोजेक्ट में `public/manifest.json`, `public/icon.svg` और PWA मेटा टैग्स पहले से पूरी तरह कॉन्फ़िगर हैं)।
4. **"Generate APK" / "Package for Android"** पर क्लिक करें।
5. सीधे अपने फोन में इंस्टॉल करने योग्य `.apk` डाउनलोड करें!

---

## 🛠️ विधि 2: Android Studio / Capacitor (Native Code)

यदि आप इस ZIP को अपने कंप्यूटर पर एक्सपोर्ट करके Android Studio में APK बनाना चाहते हैं:

### 1. ZIP निकालें और टर्मिनल में चलाएं:
```bash
npm install
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap add android
npm run build
npx cap sync
```

### 2. Android Studio खोलें और APK बनाएं:
```bash
npx cap open android
```
- Android Studio मेन्यू में जाएं: **Build > Build Bundle(s) / APK(s) > Build APK(s)**
- आपकी APK फ़ाइल तैयार हो जाएगी: `android/app/build/outputs/apk/debug/app-debug.apk`

---

## 🛡️ विज्ञापन और डाउनलोड से सुरक्षा (Ad Auto-Skip & 0-Download Shield):
- **ऑटो-क्रॉस/स्किप (Auto Skip & Cross):** पॉपअप, रिवार्डेड या इंटरस्टीशियल ऐड्स पर AI केवल [✕] (Cross) या 'Skip' बटन को ही डिटेक्ट करके दबाएगा।
- **शून्य ऐप डाउनलोड (0 App Downloads):** किसी भी 'Install', 'Open Store' या फेक बटन पर क्लिक पूरी तरह ब्लॉक है।
