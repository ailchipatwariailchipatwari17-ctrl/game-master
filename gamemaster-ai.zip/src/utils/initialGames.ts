import { GameBotState } from '../types';

// Starts completely clean with 0 fake demo games (as requested by user)
export const INITIAL_GAMES: GameBotState[] = [];
