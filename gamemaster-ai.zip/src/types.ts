export type GameCategory = 'block_blast' | 'fruit_ninja' | 'dungeon_rpg' | 'space_miner' | 'cyber_runner' | 'empire_tycoon' | 'neon_dodger' | 'combat' | 'strategy' | 'custom';

export type BotStrategy = 'balanced' | 'aggressive_xp' | 'boss_hunter' | 'gold_farmer' | 'survival_safe' | 'overclock';

export interface BotLog {
  id: string;
  timestamp: number;
  messageHindi: string;
  messageEnglish: string;
  type: 'combat' | 'loot' | 'level_up' | 'command' | 'offline' | 'boss' | 'system' | 'timer' | 'ad_block';
  gameId: string;
}

export interface ItemDrop {
  id: string;
  name: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  bonus: string;
}

export interface GameBotState {
  id: string;
  name: string;
  nameHindi: string;
  category: GameCategory;
  description: string;
  descriptionHindi: string;
  status: 'active' | 'paused' | 'boss_battle' | 'farming';
  level: number;
  exp: number;
  maxExp: number;
  score: number;
  highScore: number;
  coins: number;
  crystals: number;
  bossesDefeated: number;
  currentBossHealth?: number;
  maxBossHealth?: number;
  bossName?: string;
  actionsPerMinute: number;
  speedMultiplier: number; // 1x to 10x
  strategy: BotStrategy;
  customDirectives: string[];
  uptimeSeconds: number;
  targetDurationHours: number | null; // null = Infinite / लगातार 24/7
  remainingSeconds: number | null; // null = Infinite
  autoUpgrade: boolean;
  botConfidence: number; // 0-100%
  skills: {
    strength: number;
    agility: number;
    intelligence: number;
    vitality: number;
  };
  inventory: ItemDrop[];
  lastTickTime: number;
  // Specific Game Mode & Execution Preferences (User Configurable)
  playModeGoal?: 'slice_only' | 'level_up' | 'boss_rush' | 'resource_farm' | 'endless_score';
  touchProfile?: 'human_like' | 'robotic_lightning' | 'stealth_anti_ban';
  batterySavingMode?: 'ultra_saver' | 'balanced' | 'performance';
  executionTarget?: 'phone_installed_app' | 'browser_simulation';
  phonePackageName?: string;
  // Ad Interception & Anti-Download Shield Preferences
  autoCrossAds?: boolean; // Always close/cross ads (Never download)
  blockAdDownloads?: boolean; // Block clicking anywhere except real 'X' / close
  adDismissStats?: {
    adsDismissed: number;
    downloadsBlocked: number;
    fakeCrossesFiltered: number;
  };
  // Specific live simulation params
  simulationParams: {
    heroX: number;
    heroY: number;
    monstersCount: number;
    multiplier: number;
    currentWave: number;
    dronesCount?: number;
    oresMined?: number;
    distanceMeters?: number;
    combosCount?: number;
    blocksCleared?: number;
    comboLines?: number;
    fruitsSliced?: number;
    bombsDodged?: number;
  };
}

export interface OfflineReport {
  timeAwaySeconds: number;
  totalScoreGained: number;
  totalExpGained: number;
  levelsGained: number;
  goldGained: number;
  crystalsGained: number;
  bossesDefeatedGained: number;
  gamesBreakdown: {
    gameId: string;
    name: string;
    nameHindi: string;
    scoreGained: number;
    levelsGained: number;
    goldGained: number;
  }[];
}

export interface AiCommandResult {
  replyHindi: string;
  replyEnglish: string;
  actionType: string;
  speedMultiplier?: number;
  globalStrategy?: string;
  targetDurationHours?: number | null;
  gameUpdates?: {
    gameId: string;
    strategy?: string;
    customDirective?: string;
    speedMultiplier?: number;
    targetDurationHours?: number | null;
  }[];
  newGameSuggestion?: {
    name: string;
    nameHindi?: string;
    type?: string;
    category?: string;
    description: string;
    initialGoal: string;
  };
}

export interface HubSettings {
  language: 'hi' | 'en';
  soundEnabled: boolean;
  autoSaveInterval: number;
  backgroundFarmingEnabled: boolean;
  offlineNotifications: boolean;
  globalOverclock: number;
  autoCrossAds: boolean; // Auto dismiss all popup ads via Cross [X]
  blockAdDownloads: boolean; // Strict zero-download policy
}
