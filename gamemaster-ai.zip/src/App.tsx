import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Navbar } from './components/Navbar';
import { AICommanderBar } from './components/AICommanderBar';
import { GameCard } from './components/GameCard';
import { ConnectGameModal } from './components/ConnectGameModal';
import { PhoneCompanionModal } from './components/PhoneCompanionModal';
import { GameInspectModal } from './components/GameInspectModal';
import { OfflineGainsModal } from './components/OfflineGainsModal';
import { TelemetryHub } from './components/TelemetryHub';
import { GameBotState, BotLog, OfflineReport, AiCommandResult, BotStrategy } from './types';
import { INITIAL_GAMES } from './utils/initialGames';
import {
  tickGame,
  calculateOfflineProgression,
  saveGameStateToStorage,
  loadGameStateFromStorage
} from './utils/gameSimulation';
import { playSound } from './utils/audio';

export default function App() {
  const [games, setGames] = useState<GameBotState[]>(INITIAL_GAMES);
  const [language, setLanguage] = useState<'hi' | 'en'>('hi');
  const [logs, setLogs] = useState<BotLog[]>([]);
  const [offlineReport, setOfflineReport] = useState<OfflineReport | null>(null);
  const [inspectingGameId, setInspectingGameId] = useState<string | null>(null);
  const [isConnectModalOpen, setIsConnectModalOpen] = useState(false);
  const [isPhoneModalOpen, setIsPhoneModalOpen] = useState(false);
  const [isProcessingCommand, setIsProcessingCommand] = useState(false);
  const [latestAiResponse, setLatestAiResponse] = useState<AiCommandResult | null>(null);

  const gamesRef = useRef<GameBotState[]>(games);
  gamesRef.current = games;

  const inspectingGame = games.find((g) => g.id === inspectingGameId) || null;

  // Append new logs safely and deduplicate by id
  const addLogs = useCallback((newLogs: BotLog[]) => {
    if (!newLogs || newLogs.length === 0) return;
    setLogs((prev) => {
      const existingIds = new Set(prev.map((l) => l.id));
      const filtered = newLogs.filter((l) => !existingIds.has(l.id));
      if (filtered.length === 0) return prev;
      return [...filtered, ...prev].slice(0, 40);
    });
  }, []);

  const addLog = useCallback((log: BotLog) => {
    addLogs([log]);
  }, [addLogs]);

  // 1. Initial Load & Offline Progression Calculation
  useEffect(() => {
    const { games: savedGames, lastActiveTime } = loadGameStateFromStorage();
    const baseGames = savedGames && savedGames.length > 0 ? savedGames : INITIAL_GAMES;

    const { updatedGames, report } = calculateOfflineProgression(baseGames, lastActiveTime);
    setGames(updatedGames);

    if (report && report.timeAwaySeconds > 15) {
      setOfflineReport(report);
    }

    addLog({
      id: `log_init_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
      messageHindi: '🟢 AI गेमिंग हब ऑनलाइन: सभी कनेक्टेड गेम्स (Block Blast, Fruit Ninja आदि) में बैकग्राउंड फार्मिंग सक्रिय है।',
      messageEnglish: '🟢 AI Gaming Hub Online: Background farming active across all connected games.',
      type: 'system',
      gameId: 'hub'
    });
  }, [addLog]);

  // 2. Real-time Simulation Tick Loop (Runs continuously even in background)
  useEffect(() => {
    let lastTick = performance.now();

    const interval = setInterval(() => {
      const now = performance.now();
      const deltaSeconds = Math.min(1.5, Math.max(0.1, (now - lastTick) / 1000));
      lastTick = now;

      let hasAnyLevelUp = false;
      let hasAnyBossKill = false;
      const collectedLogs: BotLog[] = [];

      const currentGames = gamesRef.current;
      const nextGames = currentGames.map((game) => {
        const res = tickGame(game, deltaSeconds, (newLog) => {
          collectedLogs.push(newLog);
        });
        if (res.leveledUp) hasAnyLevelUp = true;
        if (res.bossKilled) hasAnyBossKill = true;
        return res.updatedGame;
      });

      // Update state cleanly
      setGames(nextGames);
      saveGameStateToStorage(nextGames);

      if (hasAnyLevelUp) playSound('levelup');
      if (hasAnyBossKill) playSound('boss_kill');
      if (collectedLogs.length > 0) {
        addLogs(collectedLogs);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [addLogs]);

  // 3. Page Visibility & Unload Handlers (Ensures offline time tracking)
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        saveGameStateToStorage(gamesRef.current);
      } else {
        const { lastActiveTime } = loadGameStateFromStorage();
        const { updatedGames, report } = calculateOfflineProgression(gamesRef.current, lastActiveTime);
        if (report && report.timeAwaySeconds > 20) {
          setGames(updatedGames);
          setOfflineReport(report);
        }
      }
    };

    const handleBeforeUnload = () => {
      saveGameStateToStorage(gamesRef.current);
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, []);

  // Update game strategy
  const handleUpdateStrategy = (gameId: string, strategy: BotStrategy) => {
    setGames((prev) =>
      prev.map((g) => (g.id === gameId ? { ...g, strategy } : g))
    );
  };

  // Update speed
  const handleUpdateSpeed = (gameId: string, speed: number) => {
    setGames((prev) =>
      prev.map((g) => (g.id === gameId ? { ...g, speedMultiplier: speed } : g))
    );
  };

  // Update duration / gameplay hours timer
  const handleUpdateDuration = (gameId: string, hours: number | null) => {
    playSound('click');
    setGames((prev) =>
      prev.map((g) =>
        g.id === gameId
          ? {
              ...g,
              targetDurationHours: hours,
              remainingSeconds: hours ? hours * 3600 : null,
              status: 'active'
            }
          : g
      )
    );
  };

  // Toggle pause
  const handleTogglePause = (gameId: string) => {
    playSound('click');
    setGames((prev) =>
      prev.map((g) =>
        g.id === gameId
          ? { ...g, status: g.status === 'paused' ? 'active' : 'paused' }
          : g
      )
    );
  };

  // Remove / Disconnect game
  const handleRemoveGame = (gameId: string) => {
    playSound('click');
    setGames((prev) => prev.filter((g) => g.id !== gameId));
    if (inspectingGameId === gameId) {
      setInspectingGameId(null);
    }
  };

  // Add directive
  const handleAddDirective = (gameId: string, directive: string) => {
    setGames((prev) =>
      prev.map((g) =>
        g.id === gameId
          ? { ...g, customDirectives: [...g.customDirectives, directive] }
          : g
      )
    );
  };

  // Upgrade Skill
  const handleUpgradeSkill = (gameId: string, skill: keyof GameBotState['skills']) => {
    setGames((prev) =>
      prev.map((g) => {
        if (g.id === gameId) {
          const updatedSkills = { ...g.skills, [skill]: g.skills[skill] + 1 };
          return { ...g, skills: updatedSkills };
        }
        return g;
      })
    );
  };

  // Connect new game
  const handleAddGame = (newGame: GameBotState) => {
    setGames((prev) => [newGame, ...prev]);
    addLog({
      id: `log_add_${Date.now()}`,
      timestamp: Date.now(),
      messageHindi: `🎮 नया गेम कनेक्ट हुआ: ${newGame.nameHindi}! AI तुरंत खेलना शुरू कर रहा है।`,
      messageEnglish: `🎮 New Game Connected: ${newGame.name}! AI beginning autonomous farming.`,
      type: 'system',
      gameId: newGame.id
    });
  };

  // Global Overclock
  const handleGlobalOverclock = () => {
    setGames((prev) =>
      prev.map((g) => ({ ...g, speedMultiplier: 5, strategy: 'overclock' }))
    );
    addLog({
      id: `log_oc_${Date.now()}`,
      timestamp: Date.now(),
      messageHindi: '⚡ सभी गेम्स को 5x ओवरक्लॉक स्पीड पर सेट किया गया!',
      messageEnglish: '⚡ All games overclocked to 5x AI speed multiplier!',
      type: 'command',
      gameId: 'hub'
    });
  };

  // Natural Language AI Command Execution
  const handleApplyCommand = async (commandText: string): Promise<AiCommandResult | null> => {
    setIsProcessingCommand(true);
    try {
      const res = await fetch('/api/ai/command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          command: commandText,
          activeGames: gamesRef.current,
          currentLanguage: language
        })
      });

      const json = await res.json();
      const result: AiCommandResult = json.data;

      setLatestAiResponse(result);

      // Apply changes to games
      setGames((currentGames) => {
        return currentGames.map((game) => {
          let updated = { ...game };

          if (result.globalStrategy) {
            updated.strategy = result.globalStrategy as BotStrategy;
          }
          if ((result as any).playModeGoal) {
            updated.playModeGoal = (result as any).playModeGoal;
          }
          if ((result as any).touchProfile) {
            updated.touchProfile = (result as any).touchProfile;
          }
          if ((result as any).batterySavingMode) {
            updated.batterySavingMode = (result as any).batterySavingMode;
          }
          if (result.speedMultiplier) {
            updated.speedMultiplier = result.speedMultiplier;
          }
          if (result.targetDurationHours !== undefined) {
            updated.targetDurationHours = result.targetDurationHours;
            updated.remainingSeconds = result.targetDurationHours ? result.targetDurationHours * 3600 : null;
            updated.status = 'active';
          }

          // Game specific updates
          if (result.gameUpdates && Array.isArray(result.gameUpdates)) {
            const match = result.gameUpdates.find((u) => u.gameId === game.id);
            if (match) {
              if (match.strategy) updated.strategy = match.strategy as BotStrategy;
              if ((match as any).playModeGoal) updated.playModeGoal = (match as any).playModeGoal;
              if ((match as any).touchProfile) updated.touchProfile = (match as any).touchProfile;
              if ((match as any).batterySavingMode) updated.batterySavingMode = (match as any).batterySavingMode;
              if (match.speedMultiplier) updated.speedMultiplier = match.speedMultiplier;
              if (match.targetDurationHours !== undefined) {
                updated.targetDurationHours = match.targetDurationHours;
                updated.remainingSeconds = match.targetDurationHours ? match.targetDurationHours * 3600 : null;
                updated.status = 'active';
              }
              if (match.customDirective) {
                updated.customDirectives = [...updated.customDirectives, match.customDirective];
              }
            }
          }

          return updated;
        });
      });

      // If user asked to connect a game and AI created a template
      if (result.newGameSuggestion) {
        const sg = result.newGameSuggestion;
        const generatedGame: GameBotState = {
          id: `game_ai_${Date.now()}`,
          name: sg.name,
          nameHindi: sg.nameHindi || sg.name,
          category: (sg.category as any) || 'combat',
          description: sg.description || 'AI Auto-generated connected game.',
          descriptionHindi: sg.description || 'AI द्वारा जनरेट किया गया गेम।',
          status: 'active',
          level: 1,
          exp: 0,
          maxExp: 600,
          score: 8500,
          highScore: 8500,
          coins: 2000,
          crystals: 20,
          bossesDefeated: 0,
          bossName: 'Nexus Boss',
          currentBossHealth: 2000,
          maxBossHealth: 2000,
          actionsPerMinute: 300,
          speedMultiplier: 2,
          strategy: 'aggressive_xp',
          customDirectives: [sg.initialGoal || 'Maximize level up velocity'],
          uptimeSeconds: 0,
          targetDurationHours: null,
          remainingSeconds: null,
          autoUpgrade: true,
          botConfidence: 99,
          skills: { strength: 12, agility: 12, intelligence: 12, vitality: 12 },
          inventory: [{ id: `item_${Date.now()}`, name: 'Nexus Blade', rarity: 'rare', bonus: '+20% APM' }],
          lastTickTime: Date.now(),
          simulationParams: { heroX: 100, heroY: 100, monstersCount: 4, multiplier: 1.5, currentWave: 1 }
        };
        handleAddGame(generatedGame);
      }

      addLog({
        id: `log_cmd_${Date.now()}`,
        timestamp: Date.now(),
        messageHindi: `🤖 AI कमांडर ने आदेश लागू किया: "${commandText}"`,
        messageEnglish: `🤖 AI Commander executed directive: "${commandText}"`,
        type: 'command',
        gameId: 'hub'
      });

      return result;
    } catch (err) {
      console.error('Command Execution Error:', err);
      return null;
    } finally {
      setIsProcessingCommand(false);
    }
  };

  // Aggregate metrics
  const totalScore = games.reduce((acc, g) => acc + g.score, 0);
  const totalLevel = games.reduce((acc, g) => acc + g.level, 0);
  const totalApm = games.reduce((acc, g) => acc + (g.status === 'active' ? g.actionsPerMinute : 0), 0);
  const activeCount = games.filter((g) => g.status === 'active').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 selection:bg-emerald-500 selection:text-white">
      {/* Background cyber grid & glow */}
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(16,185,129,0.15),rgba(255,255,255,0))]" />

      {/* Top Navbar */}
      <Navbar
        language={language}
        onToggleLanguage={() => setLanguage((l) => (l === 'hi' ? 'en' : 'hi'))}
        activeCount={activeCount}
        totalScore={totalScore}
        totalLevel={totalLevel}
        totalApm={totalApm}
        onOpenConnectModal={() => setIsConnectModalOpen(true)}
        onOpenPhoneModal={() => setIsPhoneModalOpen(true)}
        onGlobalOverclock={handleGlobalOverclock}
      />

      <main className="relative z-10 space-y-4 pb-16">
        {/* Tactical AI Commander Bar */}
        <AICommanderBar
          language={language}
          activeGames={games}
          onApplyCommand={handleApplyCommand}
          isProcessing={isProcessingCommand}
          latestAiResponse={latestAiResponse}
        />

        {/* Connected Games Grid */}
        <section className="mx-auto w-full max-w-7xl px-4 sm:px-6">
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold uppercase tracking-wider text-white sm:text-lg">
                {language === 'hi' ? 'कनेक्टेड गेम्स व ऑटोनॉमस बॉट्स' : 'Connected Games & Autonomous Bots'}
              </h2>
              <span className="rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-xs font-bold text-emerald-400">
                {games.length} {language === 'hi' ? 'गेम्स' : 'Games'}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  playSound('click');
                  setIsPhoneModalOpen(true);
                }}
                className="flex items-center gap-1.5 rounded-lg border border-cyan-500/40 bg-cyan-500/10 px-3 py-1.5 text-xs font-bold text-cyan-300 hover:bg-cyan-500/20 active:scale-95 shadow-sm"
              >
                <span>📱 {language === 'hi' ? 'फोन गेम्स सिंक' : 'Phone Games'}</span>
              </button>

              <button
                onClick={() => {
                  playSound('click');
                  setIsConnectModalOpen(true);
                }}
                className="rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-3 py-1.5 text-xs font-semibold text-emerald-300 hover:bg-emerald-500/20 active:scale-95"
              >
                {language === 'hi' ? '+ नया गेम जोड़ें' : '+ Add Game'}
              </button>
            </div>
          </div>

          {games.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-800 p-12 text-center">
              <p className="text-sm text-slate-400">
                {language === 'hi'
                  ? 'कोई गेम कनेक्ट नहीं है। नया गेम जोड़कर AI को ऑटो-प्ले शुरू करवाएं!'
                  : 'No games connected. Connect a game to let AI start 24/7 autonomous farming!'}
              </p>
              <button
                onClick={() => setIsConnectModalOpen(true)}
                className="mt-4 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-bold text-white hover:bg-emerald-500"
              >
                {language === 'hi' ? '+ गेम कनेक्ट करें' : '+ Connect Game'}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3">
              {games.map((game) => (
                <GameCard
                  key={game.id}
                  game={game}
                  language={language}
                  onUpdateStrategy={handleUpdateStrategy}
                  onUpdateSpeed={handleUpdateSpeed}
                  onUpdateDuration={handleUpdateDuration}
                  onTogglePause={handleTogglePause}
                  onInspect={(g) => setInspectingGameId(g.id)}
                  onRemove={handleRemoveGame}
                  onAddDirective={handleAddDirective}
                />
              ))}
            </div>
          )}
        </section>

        {/* Real-time Telemetry & AI Tactical Advisor Stream */}
        <TelemetryHub
          logs={logs}
          activeGames={games}
          language={language}
        />
      </main>

      {/* Connect Game Modal */}
      <ConnectGameModal
        isOpen={isConnectModalOpen}
        onClose={() => setIsConnectModalOpen(false)}
        onAddGame={handleAddGame}
        onOpenPhoneModal={() => setIsPhoneModalOpen(true)}
        language={language}
      />

      {/* Phone Companion & Installed Mobile Games Sync Modal */}
      <PhoneCompanionModal
        isOpen={isPhoneModalOpen}
        onClose={() => setIsPhoneModalOpen(false)}
        onConnectPhoneGame={handleAddGame}
        language={language}
      />

      {/* Fullscreen Inspector & Skill Allocator */}
      <GameInspectModal
        game={inspectingGame}
        isOpen={!!inspectingGame}
        onClose={() => setInspectingGameId(null)}
        onUpdateStrategy={handleUpdateStrategy}
        onUpdateDuration={handleUpdateDuration}
        onUpgradeSkill={handleUpgradeSkill}
        onAddDirective={handleAddDirective}
        language={language}
      />

      {/* Offline Farming Gains Modal */}
      <OfflineGainsModal
        report={offlineReport}
        onClaim={() => setOfflineReport(null)}
        language={language}
      />
    </div>
  );
}
