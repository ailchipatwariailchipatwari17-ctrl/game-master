import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Navbar } from './components/Navbar';
import { AICommanderBar } from './components/AICommanderBar';
import { GameCard } from './components/GameCard';
import { ConnectGameModal } from './components/ConnectGameModal';
import { PhoneCompanionModal } from './components/PhoneCompanionModal';
import { GameInspectModal } from './components/GameInspectModal';
import { OfflineGainsModal } from './components/OfflineGainsModal';
import { TelemetryHub } from './components/TelemetryHub';
import { GameBotState, BotLog, OfflineReport, AiCommandResult, BotStrategy } from './types';
import { INITIAL_GAMES } from './utils/initialGames';
import {
  tickGame,
  calculateOfflineProgression,
  saveGameStateToStorage,
  loadGameStateFromStorage
} from './utils/gameSimulation';
import { playSound } from './utils/audio';
import { Smartphone, Plus, Gamepad2, Sparkles, Terminal, Activity, Zap } from 'lucide-react';

export default function App() {
  const [games, setGames] = useState<GameBotState[]>(INITIAL_GAMES);
  const [language, setLanguage] = useState<'hi' | 'en'>('hi');
  const [logs, setLogs] = useState<BotLog[]>([]);
  const [offlineReport, setOfflineReport] = useState<OfflineReport | null>(null);
  const [inspectingGameId, setInspectingGameId] = useState<string | null>(null);
  const [isConnectModalOpen, setIsConnectModalOpen] = useState(false);
  const [isPhoneModalOpen, setIsPhoneModalOpen] = useState(false);
  const [activeNavTab, setActiveNavTab] = useState<'bots' | 'scanner' | 'commander' | 'logs'>('bots');

  const gamesRef = useRef<GameBotState[]>(games);
  gamesRef.current = games;

  const inspectingGame = games.find((g) => g.id === inspectingGameId) || null;

  // Append new logs safely
  const addLogs = useCallback((newLogs: BotLog[]) => {
    if (!newLogs || newLogs.length === 0) return;
    setLogs((prev) => {
      const existingIds = new Set(prev.map((l) => l.id));
      const filtered = newLogs.filter((l) => !existingIds.has(l.id));
      if (filtered.length === 0) return prev;
      return [...filtered, ...prev].slice(0, 30);
    });
  }, []);

  const addLog = useCallback((log: BotLog) => {
    addLogs([log]);
  }, [addLogs]);

  // 1. Initial Load & Offline Progression Calculation
  useEffect(() => {
    const { games: savedGames, lastActiveTime } = loadGameStateFromStorage();
    const baseGames = savedGames && savedGames.length > 0 ? savedGames : INITIAL_GAMES;

    const { updatedGames, report } = calculateOfflineProgression(baseGames, lastActiveTime);
    setGames(updatedGames);

    if (report && report.timeAwaySeconds > 15 && updatedGames.length > 0) {
      setOfflineReport(report);
    }
  }, [addLog]);

  // 2. Real-time Simulation Tick Loop
  useEffect(() => {
    let lastTick = performance.now();

    const interval = setInterval(() => {
      if (gamesRef.current.length === 0) return;

      const now = performance.now();
      const deltaSeconds = Math.min(1.5, Math.max(0.1, (now - lastTick) / 1000));
      lastTick = now;

      let hasAnyLevelUp = false;
      let hasAnyBossKill = false;
      const collectedLogs: BotLog[] = [];

      const currentGames = gamesRef.current;
      const nextGames = currentGames.map((game) => {
        const res = tickGame(game, deltaSeconds, (newLog) => {
          collectedLogs.push(newLog);
        });
        if (res.leveledUp) hasAnyLevelUp = true;
        if (res.bossKilled) hasAnyBossKill = true;
        return res.updatedGame;
      });

      setGames(nextGames);
      saveGameStateToStorage(nextGames);

      if (hasAnyLevelUp) playSound('levelup');
      if (hasAnyBossKill) playSound('boss_kill');
      if (collectedLogs.length > 0) {
        addLogs(collectedLogs);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [addLogs]);

  // Update game strategy
  const handleUpdateStrategy = (gameId: string, strategy: BotStrategy) => {
    setGames((prev) => prev.map((g) => (g.id === gameId ? { ...g, strategy } : g)));
  };

  // Update speed
  const handleUpdateSpeed = (gameId: string, speed: number) => {
    setGames((prev) => prev.map((g) => (g.id === gameId ? { ...g, speedMultiplier: speed } : g)));
  };

  // Update duration
  const handleUpdateDuration = (gameId: string, hours: number | null) => {
    playSound('click');
    setGames((prev) =>
      prev.map((g) =>
        g.id === gameId
          ? {
              ...g,
              targetDurationHours: hours,
              remainingSeconds: hours ? hours * 3600 : null,
              status: 'active'
            }
          : g
      )
    );
  };

  // Toggle pause
  const handleTogglePause = (gameId: string) => {
    playSound('click');
    setGames((prev) =>
      prev.map((g) =>
        g.id === gameId
          ? { ...g, status: g.status === 'paused' ? 'active' : 'paused' }
          : g
      )
    );
  };

  // Remove game
  const handleRemoveGame = (gameId: string) => {
    playSound('click');
    setGames((prev) => prev.filter((g) => g.id !== gameId));
    if (inspectingGameId === gameId) {
      setInspectingGameId(null);
    }
  };

  // Add directive
  const handleAddDirective = (gameId: string, directive: string) => {
    setGames((prev) =>
      prev.map((g) =>
        g.id === gameId
          ? { ...g, customDirectives: [...g.customDirectives, directive] }
          : g
      )
    );
  };

  // Upgrade Skill
  const handleUpgradeSkill = (gameId: string, skill: keyof GameBotState['skills']) => {
    setGames((prev) =>
      prev.map((g) => {
        if (g.id === gameId) {
          const updatedSkills = { ...g.skills, [skill]: g.skills[skill] + 1 };
          return { ...g, skills: updatedSkills };
        }
        return g;
      })
    );
  };

  // Connect new game
  const handleAddGame = (newGame: GameBotState) => {
    setGames((prev) => [newGame, ...prev]);
    setActiveNavTab('bots');
    addLog({
      id: `log_add_${Date.now()}`,
      timestamp: Date.now(),
      messageHindi: `🎮 गेम जुड़ा: ${newGame.nameHindi}`,
      messageEnglish: `🎮 Game Linked: ${newGame.name}`,
      type: 'system',
      gameId: newGame.id
    });
  };

  // Global Overclock
  const handleGlobalOverclock = () => {
    setGames((prev) =>
      prev.map((g) => ({ ...g, speedMultiplier: 5, strategy: 'overclock' }))
    );
    addLog({
      id: `log_oc_${Date.now()}`,
      timestamp: Date.now(),
      messageHindi: '⚡ 5x ओवरक्लॉक सक्रिय!',
      messageEnglish: '⚡ 5x Overclock active!',
      type: 'command',
      gameId: 'hub'
    });
  };

  // Natural Language AI Command Execution
  const handleApplyCommand = async (commandText: string): Promise<any> => {
    try {
      const res = await fetch('/api/ai/command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          command: commandText,
          activeGames: gamesRef.current,
          currentLanguage: language
        })
      });

      const json = await res.json();
      const result: AiCommandResult = json.data;

      // Apply updates to games
      setGames((currentGames) => {
        return currentGames.map((game) => {
          let updated = { ...game };
          if (result.globalStrategy) updated.strategy = result.globalStrategy as BotStrategy;
          if (result.speedMultiplier) updated.speedMultiplier = result.speedMultiplier;
          if (result.targetDurationHours !== undefined) {
            updated.targetDurationHours = result.targetDurationHours;
            updated.remainingSeconds = result.targetDurationHours ? result.targetDurationHours * 3600 : null;
            updated.status = 'active';
          }
          return updated;
        });
      });

      return result;
    } catch {
      return null;
    }
  };

  const totalScore = games.reduce((acc, g) => acc + g.score, 0);
  const totalLevel = games.reduce((acc, g) => acc + g.level, 0);
  const totalApm = games.reduce((acc, g) => acc + (g.status === 'active' ? g.actionsPerMinute : 0), 0);
  const activeCount = games.filter((g) => g.status === 'active').length;
  const isHindi = language === 'hi';

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-20 selection:bg-emerald-500 selection:text-white">
      
      {/* Top Mobile Navbar */}
      <Navbar
        language={language}
        onToggleLanguage={() => setLanguage((l) => (l === 'hi' ? 'en' : 'hi'))}
        activeCount={activeCount}
        totalScore={totalScore}
        totalLevel={totalLevel}
        totalApm={totalApm}
        onOpenConnectModal={() => setIsConnectModalOpen(true)}
        onOpenPhoneModal={() => setIsPhoneModalOpen(true)}
        onGlobalOverclock={handleGlobalOverclock}
      />

      {/* Main Mobile App Container */}
      <main className="mx-auto max-w-md px-3 pt-3 space-y-3">
        
        {/* TAB 1: BOTS & GAMES */}
        {activeNavTab === 'bots' && (
          <div className="space-y-3">
            {/* Quick Commander Widget */}
            <AICommanderBar
              games={games}
              onApplyTacticalCommand={handleApplyCommand}
              language={language}
            />

            {/* Games List Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Gamepad2 className="h-4 w-4 text-emerald-400" />
                <span className="text-xs font-bold uppercase tracking-wider text-white">
                  {isHindi ? 'सक्रिय गेम्स' : 'Active Games'} ({games.length})
                </span>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => {
                    playSound('click');
                    setIsPhoneModalOpen(true);
                  }}
                  className="flex items-center gap-1 rounded-lg border border-cyan-500/40 bg-cyan-500/10 px-2 py-1 text-[11px] font-bold text-cyan-300 active:scale-95"
                >
                  <Smartphone className="h-3 w-3" />
                  <span>{isHindi ? 'स्कैनर' : 'Scan'}</span>
                </button>
                <button
                  onClick={() => {
                    playSound('click');
                    setIsConnectModalOpen(true);
                  }}
                  className="flex items-center gap-1 rounded-lg bg-emerald-600 px-2 py-1 text-[11px] font-bold text-white active:scale-95 shadow-sm"
                >
                  <Plus className="h-3 w-3" />
                  <span>{isHindi ? 'नया गेम' : 'Add'}</span>
                </button>
              </div>
            </div>

            {/* Empty State (0 games) */}
            {games.length === 0 ? (
              <div className="rounded-3xl border border-dashed border-slate-800 bg-slate-900/40 p-6 text-center shadow-lg">
                <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 text-2xl">
                  📱
                </div>
                <h3 className="text-sm font-bold text-white">
                  {isHindi ? 'कोई गेम कनेक्ट नहीं है' : 'No Games Connected'}
                </h3>
                <p className="mt-1 text-xs text-slate-400">
                  {isHindi
                    ? 'अपने फोन का गेम स्कैन करें या नया गेम जोड़कर AI ऑटो-प्ले चालू करें।'
                    : 'Scan phone apps or connect a game to start 24/7 AI play.'}
                </p>

                <div className="mt-4 flex flex-col gap-2">
                  <button
                    onClick={() => {
                      playSound('click');
                      setIsPhoneModalOpen(true);
                    }}
                    className="flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 py-2.5 text-xs font-bold text-white shadow-lg active:scale-95"
                  >
                    <Smartphone className="h-4 w-4" />
                    <span>{isHindi ? '📱 फोन के गेम्स स्कैन करें' : '📱 Scan Phone Games'}</span>
                  </button>

                  <button
                    onClick={() => {
                      playSound('click');
                      setIsConnectModalOpen(true);
                    }}
                    className="flex items-center justify-center gap-2 rounded-2xl border border-slate-700 bg-slate-800 py-2.5 text-xs font-bold text-slate-200 hover:bg-slate-700 active:scale-95"
                  >
                    <Plus className="h-4 w-4" />
                    <span>{isHindi ? '+ सूची से नया गेम जोड़ें' : '+ Connect New Game'}</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {games.map((game) => (
                  <GameCard
                    key={game.id}
                    game={game}
                    language={language}
                    onUpdateStrategy={handleUpdateStrategy}
                    onUpdateSpeed={handleUpdateSpeed}
                    onUpdateDuration={handleUpdateDuration}
                    onTogglePause={handleTogglePause}
                    onInspect={(g) => setInspectingGameId(g.id)}
                    onRemove={handleRemoveGame}
                    onAddDirective={handleAddDirective}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: SCANNER */}
        {activeNavTab === 'scanner' && (
          <div className="space-y-3">
            <div className="rounded-3xl border border-cyan-500/30 bg-slate-900/90 p-4 text-center">
              <Smartphone className="mx-auto h-12 w-12 text-cyan-400 mb-2" />
              <h3 className="text-sm font-bold text-white">
                {isHindi ? 'मोबाइल ऐप लिंकर' : 'Mobile App Linker'}
              </h3>
              <p className="mt-1 text-xs text-slate-400">
                {isHindi
                  ? 'सटीक डिवाइस व गेम स्कैनर खोलें'
                  : 'Open real-time phone scanner & app selector'}
              </p>
              <button
                onClick={() => {
                  playSound('click');
                  setIsPhoneModalOpen(true);
                }}
                className="mt-3 w-full rounded-xl bg-cyan-600 py-2 text-xs font-bold text-white shadow-md active:scale-95"
              >
                {isHindi ? '📱 स्कैनर विंडो खोलें' : 'Open Scanner'}
              </button>
            </div>
          </div>
        )}

        {/* TAB 3: COMMANDER */}
        {activeNavTab === 'commander' && (
          <div className="space-y-3">
            <AICommanderBar
              games={games}
              onApplyTacticalCommand={handleApplyCommand}
              language={language}
            />
          </div>
        )}

        {/* TAB 4: LOGS & TELEMETRY */}
        {activeNavTab === 'logs' && (
          <div className="space-y-3">
            <TelemetryHub
              logs={logs}
              activeGames={games}
              language={language}
            />
          </div>
        )}

      </main>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-slate-800 bg-slate-950/95 backdrop-blur-md">
        <div className="mx-auto flex max-w-md items-center justify-around py-1.5 text-center">
          <button
            onClick={() => {
              playSound('click');
              setActiveNavTab('bots');
            }}
            className={`flex flex-col items-center gap-0.5 p-1 text-[10px] font-bold ${
              activeNavTab === 'bots' ? 'text-emerald-400' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <Gamepad2 className="h-4 w-4" />
            <span>{isHindi ? 'गेम्स' : 'Bots'}</span>
          </button>

          <button
            onClick={() => {
              playSound('click');
              setIsPhoneModalOpen(true);
            }}
            className="flex flex-col items-center gap-0.5 p-1 text-[10px] font-bold text-cyan-400 hover:text-cyan-300"
          >
            <Smartphone className="h-4 w-4" />
            <span>{isHindi ? 'स्कैनर' : 'Scan'}</span>
          </button>

          <button
            onClick={() => {
              playSound('click');
              setActiveNavTab('commander');
            }}
            className={`flex flex-col items-center gap-0.5 p-1 text-[10px] font-bold ${
              activeNavTab === 'commander' ? 'text-emerald-400' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <Sparkles className="h-4 w-4" />
            <span>{isHindi ? 'AI वॉइस' : 'AI Voice'}</span>
          </button>

          <button
            onClick={() => {
              playSound('click');
              setActiveNavTab('logs');
            }}
            className={`flex flex-col items-center gap-0.5 p-1 text-[10px] font-bold ${
              activeNavTab === 'logs' ? 'text-emerald-400' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <Terminal className="h-4 w-4" />
            <span>{isHindi ? 'लॉग' : 'Logs'}</span>
          </button>
        </div>
      </nav>

      {/* Connect Game Modal */}
      <ConnectGameModal
        isOpen={isConnectModalOpen}
        onClose={() => setIsConnectModalOpen(false)}
        onAddGame={handleAddGame}
        onOpenPhoneModal={() => setIsPhoneModalOpen(true)}
        language={language}
      />

      {/* Phone Companion & Installed Mobile Games Sync Modal */}
      <PhoneCompanionModal
        isOpen={isPhoneModalOpen}
        onClose={() => setIsPhoneModalOpen(false)}
        onConnectPhoneGame={handleAddGame}
        language={language}
      />

      {/* Fullscreen Inspector & Skill Allocator */}
      <GameInspectModal
        game={inspectingGame}
        isOpen={!!inspectingGame}
        onClose={() => setInspectingGameId(null)}
        onUpdateStrategy={handleUpdateStrategy}
        onUpdateDuration={handleUpdateDuration}
        onUpgradeSkill={handleUpgradeSkill}
        onAddDirective={handleAddDirective}
        language={language}
      />

      {/* Offline Farming Gains Modal */}
      <OfflineGainsModal
        report={offlineReport}
        onClaim={() => setOfflineReport(null)}
        language={language}
      />
    </div>
  );
}
