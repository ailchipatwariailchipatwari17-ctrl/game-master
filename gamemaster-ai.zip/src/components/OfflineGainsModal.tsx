import React, { useEffect } from 'react';
import { Sparkles, Coins, Award, Zap, Skull, Check } from 'lucide-react';
import confetti from 'canvas-confetti';
import { OfflineReport } from '../types';
import { playSound } from '../utils/audio';

interface OfflineGainsModalProps {
  report: OfflineReport | null;
  onClaim: () => void;
  language: 'hi' | 'en';
}

export const OfflineGainsModal: React.FC<OfflineGainsModalProps> = ({
  report,
  onClaim,
  language
}) => {
  if (!report) return null;

  const isHindi = language === 'hi';

  useEffect(() => {
    playSound('levelup');
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // Ignore confetti issues
    }
  }, []);

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    if (hrs > 0) return `${hrs}h ${mins}m`;
    if (mins > 0) return `${mins}m ${secs}s`;
    return `${secs}s`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-md">
      <div className="relative w-full max-w-lg overflow-hidden rounded-2xl border border-emerald-500/50 bg-slate-900 p-6 shadow-2xl">
        {/* Glow */}
        <div className="pointer-events-none absolute -top-24 left-1/2 h-48 w-48 -translate-x-1/2 rounded-full bg-emerald-500/20 blur-3xl" />

        {/* Title */}
        <div className="text-center">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-700 shadow-lg shadow-emerald-500/30">
            <Sparkles className="h-8 w-8 text-white" />
          </div>
          <h2 className="mt-3 text-xl font-bold text-white">
            {isHindi ? 'बैकग्राउंड AI फार्मिंग रिपोर्ट' : 'Background AI Farming Report'}
          </h2>
          <p className="text-xs text-slate-400">
            {isHindi
              ? `जब आप दूर थे (${formatTime(report.timeAwaySeconds)}), AI ने बिना रुके खेला और प्रगति की!`
              : `While you were away (${formatTime(report.timeAwaySeconds)}), AI bots farmed autonomously!`}
          </p>
        </div>

        {/* Main Rewards Grid */}
        <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-3 text-center">
            <span className="block text-[10px] uppercase tracking-wider text-slate-400">
              {isHindi ? 'स्कोर वृद्धि' : 'Score Gained'}
            </span>
            <span className="text-sm font-bold text-amber-400">+{report.totalScoreGained.toLocaleString()}</span>
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-3 text-center">
            <span className="block text-[10px] uppercase tracking-wider text-slate-400">
              {isHindi ? 'लेवल बढ़े' : 'Levels Up'}
            </span>
            <span className="text-sm font-bold text-emerald-400">+{report.levelsGained} Lv.</span>
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-3 text-center">
            <span className="block text-[10px] uppercase tracking-wider text-slate-400">
              {isHindi ? 'गोल्ड कॉइन्स' : 'Gold Coins'}
            </span>
            <span className="text-sm font-bold text-yellow-300">+{report.goldGained.toLocaleString()}</span>
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-3 text-center">
            <span className="block text-[10px] uppercase tracking-wider text-slate-400">
              {isHindi ? 'क्रिस्टल्स' : 'Crystals'}
            </span>
            <span className="text-sm font-bold text-cyan-400">+{report.crystalsGained}</span>
          </div>
        </div>

        {/* Games Breakdown List */}
        <div className="mt-4 max-h-44 overflow-y-auto space-y-2 rounded-xl border border-slate-800 bg-slate-950/80 p-3">
          <h4 className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            {isHindi ? 'प्रत्येक गेम का परिणाम:' : 'Individual Game Gains:'}
          </h4>
          {report.gamesBreakdown.map((g) => (
            <div key={g.gameId} className="flex items-center justify-between text-xs border-b border-slate-900 pb-1.5 last:border-0 last:pb-0">
              <span className="font-medium text-slate-200">{isHindi ? g.nameHindi : g.name}</span>
              <div className="flex items-center gap-2">
                <span className="text-emerald-400 font-bold">+{g.levelsGained} Lv</span>
                <span className="text-amber-400 font-mono">+{g.scoreGained.toLocaleString()} pts</span>
              </div>
            </div>
          ))}
        </div>

        {/* Claim Button */}
        <button
          onClick={() => {
            playSound('coin');
            onClaim();
          }}
          className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 py-3 text-sm font-bold text-white shadow-lg shadow-emerald-950 transition-all hover:from-emerald-400 hover:to-teal-500 active:scale-98"
        >
          <Check className="h-4 w-4" />
          <span>{isHindi ? 'सभी रिवार्ड्स कलेक्ट करें (Claim Rewards)' : 'Claim All Rewards'}</span>
        </button>
      </div>
    </div>
  );
};
