import React, { useState } from 'react';
import { Play, Pause, Zap, Crosshair, Shield, Coins, Sparkles, Maximize2, Trash2, Cpu, Award, Skull, Clock, Infinity as InfinityIcon, ChevronDown, Check, Eye } from 'lucide-react';
import { GameBotState, BotStrategy } from '../types';
import { playSound } from '../utils/audio';
import { LiveGameScreen } from './LiveGameScreen';

interface GameCardProps {
  game: GameBotState;
  language: 'hi' | 'en';
  onUpdateStrategy: (gameId: string, strategy: BotStrategy) => void;
  onUpdateSpeed: (gameId: string, speed: number) => void;
  onUpdateDuration: (gameId: string, hours: number | null) => void;
  onTogglePause: (gameId: string) => void;
  onInspect: (game: GameBotState) => void;
  onRemove: (gameId: string) => void;
  onAddDirective: (gameId: string, directive: string) => void;
}

export const GameCard: React.FC<GameCardProps> = ({
  game,
  language,
  onUpdateStrategy,
  onUpdateSpeed,
  onUpdateDuration,
  onTogglePause,
  onInspect,
  onRemove,
  onAddDirective
}) => {
  const [showDurationPicker, setShowDurationPicker] = useState(false);
  const [customHoursInput, setCustomHoursInput] = useState('');
  const isHindi = language === 'hi';

  const formatCountdown = (seconds: number | null) => {
    if (seconds === null || seconds === undefined) return null;
    const s = Math.max(0, Math.floor(seconds));
    const hrs = Math.floor(s / 3600);
    const mins = Math.floor((s % 3600) / 60);
    const secs = s % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const expPercentage = Math.min(100, Math.floor((game.exp / game.maxExp) * 100));
  const countdownText = formatCountdown(game.remainingSeconds);

  return (
    <div className="flex flex-col justify-between overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/90 shadow-lg backdrop-blur-md transition-all hover:border-emerald-500/40">
      
      {/* Header */}
      <div className="border-b border-slate-800 p-3">
        <div className="flex items-start justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <span className="rounded-md bg-emerald-500/10 px-2 py-0.5 text-xs font-bold text-emerald-400">
                Lv. {game.level}
              </span>
              <h3 className="font-bold text-white line-clamp-1 text-sm">
                {isHindi ? game.nameHindi : game.name}
              </h3>
            </div>
            
            {/* Custom Mode & Behavior Badges */}
            <div className="mt-1.5 flex flex-wrap items-center gap-1">
              <span className="rounded bg-cyan-500/15 border border-cyan-500/30 px-1.5 py-0.5 text-[10px] font-bold text-cyan-300">
                👆 {isHindi ? 'लाइव टच सक्रिय' : 'Live Touch Active'}
              </span>

              {game.touchProfile === 'human_like' && (
                <span className="rounded bg-emerald-500/15 border border-emerald-500/30 px-1.5 py-0.5 text-[10px] font-medium text-emerald-300">
                  👤 {isHindi ? 'नेचुरल टच' : 'Natural Touch'}
                </span>
              )}

              {game.executionTarget === 'phone_installed_app' && (
                <span className="rounded bg-amber-500/15 border border-amber-500/30 px-1.5 py-0.5 text-[10px] font-bold text-amber-300">
                  📱 {isHindi ? 'फोन गेम' : 'Phone Game'}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => onInspect(game)}
              className="flex h-7 w-7 items-center justify-center rounded-lg border border-slate-700 bg-slate-800 text-slate-300 hover:border-emerald-500 hover:text-white"
              title={isHindi ? 'बड़ी स्क्रीन में देखें' : 'Inspect Screen'}
            >
              <Maximize2 className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => onTogglePause(game.id)}
              className={`flex h-7 w-7 items-center justify-center rounded-lg border ${
                game.status === 'paused'
                  ? 'border-emerald-500 bg-emerald-500/20 text-emerald-400'
                  : 'border-amber-500/40 bg-amber-500/10 text-amber-300'
              }`}
              title={game.status === 'paused' ? 'Resume' : 'Pause'}
            >
              {game.status === 'paused' ? <Play className="h-3.5 w-3.5" /> : <Pause className="h-3.5 w-3.5" />}
            </button>
            <button
              onClick={() => onRemove(game.id)}
              className="flex h-7 w-7 items-center justify-center rounded-lg border border-slate-700 bg-slate-800 text-slate-400 hover:border-rose-500 hover:text-rose-400"
              title={isHindi ? 'गेम हटाएं' : 'Disconnect'}
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* 🔴 FULL LIVE GAME SCREEN WITH TOUCH CLICKS & AI GAMEPLAY */}
      <div className="p-2 bg-slate-950/80">
        <LiveGameScreen game={game} language={language} height={200} showOverlayStats={true} />
      </div>

      {/* Duration / Timer Status Ribbon */}
      <div className="flex items-center justify-between border-y border-slate-800/80 bg-slate-950/90 px-3 py-1.5 text-xs">
        <div className="flex items-center gap-1.5">
          <Clock className="h-3.5 w-3.5 text-cyan-400" />
          <span className="text-[11px] text-slate-400">
            {isHindi ? 'अवधि:' : 'Timer:'}
          </span>
          {countdownText ? (
            <span className="flex items-center gap-1 rounded bg-cyan-950/70 px-1.5 py-0.5 font-mono text-[11px] font-bold text-cyan-300 border border-cyan-500/30">
              <span className="h-1.5 w-1.5 animate-ping rounded-full bg-cyan-400" />
              {countdownText}
            </span>
          ) : (
            <span className="flex items-center gap-1 rounded bg-emerald-950/60 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-emerald-400 border border-emerald-500/20">
              <InfinityIcon className="h-3 w-3" />
              {isHindi ? 'लगातार 24/7' : 'Endless 24/7'}
            </span>
          )}
        </div>

        {/* Change Duration Button */}
        <div className="relative">
          <button
            onClick={() => {
              playSound('click');
              setShowDurationPicker(!showDurationPicker);
            }}
            className="flex items-center gap-1 rounded bg-slate-800 px-2 py-0.5 text-[10px] font-medium text-slate-300 hover:bg-slate-700 hover:text-white"
          >
            <span>{isHindi ? 'घंटे सेट करें' : 'Set Hours'}</span>
            <ChevronDown className="h-3 w-3" />
          </button>

          {/* Duration Dropdown Popover */}
          {showDurationPicker && (
            <div className="absolute right-0 top-6 z-30 w-48 rounded-xl border border-slate-700 bg-slate-900 p-2 shadow-2xl">
              <div className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                {isHindi ? 'AI कितने घंटे खेले?' : 'Play Duration:'}
              </div>

              <div className="space-y-1 text-xs">
                <button
                  onClick={() => {
                    playSound('click');
                    onUpdateDuration(game.id, null);
                    setShowDurationPicker(false);
                  }}
                  className={`flex w-full items-center justify-between rounded-lg px-2 py-1 text-left ${
                    game.targetDurationHours === null
                      ? 'bg-emerald-600 text-white font-bold'
                      : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span>{isHindi ? '♾️ लगातार 24/7' : '♾️ Endless (24/7)'}</span>
                  {game.targetDurationHours === null && <Check className="h-3 w-3" />}
                </button>

                {[1, 2, 4, 8, 12, 24].map((hrs) => (
                  <button
                    key={hrs}
                    onClick={() => {
                      playSound('click');
                      onUpdateDuration(game.id, hrs);
                      setShowDurationPicker(false);
                    }}
                    className={`flex w-full items-center justify-between rounded-lg px-2 py-1 text-left ${
                      game.targetDurationHours === hrs
                        ? 'bg-cyan-600 text-white font-bold'
                        : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span>{hrs} {isHindi ? (hrs === 1 ? 'घंटा' : 'घंटे') : (hrs === 1 ? 'hour' : 'hours')}</span>
                    {game.targetDurationHours === hrs && <Check className="h-3 w-3" />}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-3 gap-2 border-y border-slate-800 bg-slate-950/60 p-2 text-center text-xs">
        <div>
          <span className="block text-[10px] text-slate-400">{isHindi ? 'स्कोर' : 'Score'}</span>
          <span className="font-bold text-amber-400">{game.score.toLocaleString()}</span>
        </div>
        <div>
          <span className="block text-[10px] text-slate-400">{isHindi ? 'गोल्ड/सिक्के' : 'Coins'}</span>
          <span className="font-bold text-yellow-400">{game.coins.toLocaleString()}</span>
        </div>
        <div>
          <span className="block text-[10px] text-slate-400">{isHindi ? 'टच APM' : 'Touch APM'}</span>
          <span className="font-bold text-cyan-400">{game.actionsPerMinute}/min</span>
        </div>
      </div>

      {/* Quick Speed & Action Controls */}
      <div className="flex items-center justify-between p-2.5 bg-slate-900/60 gap-2">
        <div className="flex items-center gap-1 text-xs">
          <span className="text-[10px] text-slate-400 font-bold">{isHindi ? 'स्पीड:' : 'Speed:'}</span>
          {[1, 2, 5].map((spd) => (
            <button
              key={spd}
              onClick={() => {
                playSound('click');
                onUpdateSpeed(game.id, spd);
              }}
              className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${
                game.speedMultiplier === spd
                  ? 'bg-cyan-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {spd}x
            </button>
          ))}
        </div>

        <button
          onClick={() => onInspect(game)}
          className="flex items-center gap-1 rounded-lg bg-emerald-600/20 border border-emerald-500/40 px-2.5 py-1 text-xs font-bold text-emerald-300 hover:bg-emerald-600 hover:text-white transition-all"
        >
          <Eye className="h-3.5 w-3.5" />
          <span>{isHindi ? 'बड़ी स्क्रीन में देखें' : 'Full Screen View'}</span>
        </button>
      </div>

    </div>
  );
};
