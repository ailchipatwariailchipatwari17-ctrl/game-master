import React, { useRef, useEffect, useState } from 'react';
import { Play, Pause, Zap, Crosshair, Shield, Coins, Sparkles, Maximize2, Trash2, Cpu, Award, Skull, Clock, Infinity as InfinityIcon, ChevronDown, Check } from 'lucide-react';
import { GameBotState, BotStrategy } from '../types';
import { playSound } from '../utils/audio';

interface GameCardProps {
  game: GameBotState;
  language: 'hi' | 'en';
  onUpdateStrategy: (gameId: string, strategy: BotStrategy) => void;
  onUpdateSpeed: (gameId: string, speed: number) => void;
  onUpdateDuration: (gameId: string, hours: number | null) => void;
  onTogglePause: (gameId: string) => void;
  onInspect: (game: GameBotState) => void;
  onRemove: (gameId: string) => void;
  onAddDirective: (gameId: string, directive: string) => void;
}

export const GameCard: React.FC<GameCardProps> = ({
  game,
  language,
  onUpdateStrategy,
  onUpdateSpeed,
  onUpdateDuration,
  onTogglePause,
  onInspect,
  onRemove,
  onAddDirective
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [showDurationPicker, setShowDurationPicker] = useState(false);
  const [customHoursInput, setCustomHoursInput] = useState('');
  const isHindi = language === 'hi';

  const gameRef = useRef(game);
  gameRef.current = game;

  const isHindiRef = useRef(isHindi);
  isHindiRef.current = isHindi;

  // Format remaining seconds into HH:MM:SS
  const formatCountdown = (seconds: number | null) => {
    if (seconds === null || seconds === undefined) return null;
    const s = Math.max(0, Math.floor(seconds));
    const hrs = Math.floor(s / 3600);
    const mins = Math.floor((s % 3600) / 60);
    const secs = s % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Mini live Canvas simulation renderer for high immersion
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let frame = 0;

    const render = () => {
      frame++;
      const w = canvas.width;
      const h = canvas.height;
      const currentGame = gameRef.current;
      const currentHindi = isHindiRef.current;

      // Dark sci-fi background
      ctx.fillStyle = '#050b14';
      ctx.fillRect(0, 0, w, h);

      // Grid lines
      ctx.strokeStyle = '#0f233a';
      ctx.lineWidth = 1;
      const gridSize = 20;
      for (let x = 0; x < w; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y < h; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      if (currentGame.status === 'paused') {
        ctx.fillStyle = 'rgba(0,0,0,0.75)';
        ctx.fillRect(0, 0, w, h);
        ctx.fillStyle = '#94a3b8';
        ctx.font = 'bold 12px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(
          currentGame.remainingSeconds === 0
            ? (currentHindi ? '⏰ समय पूरा हुआ / COMPLETED' : '⏰ SESSION TIME COMPLETED')
            : (currentHindi ? '⏸️ रुका हुआ / PAUSED' : '⏸️ PAUSED'),
          w / 2,
          h / 2
        );
        animId = requestAnimationFrame(render);
        return;
      }

      // ==========================================
      // 1. BLOCK BLAST CUSTOM AI SIMULATOR
      // ==========================================
      if (currentGame.category === 'block_blast') {
        const cellSize = 11;
        const gridW = 8;
        const gridH = 8;
        const startX = (w - gridW * cellSize) / 2;
        const startY = 12;

        // Draw 8x8 Block Blast Grid
        ctx.fillStyle = '#091528';
        ctx.fillRect(startX - 2, startY - 2, gridW * cellSize + 4, gridH * cellSize + 4);
        ctx.strokeStyle = '#1e3a5f';
        ctx.strokeRect(startX - 2, startY - 2, gridW * cellSize + 4, gridH * cellSize + 4);

        const colors = ['#06b6d4', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899'];

        for (let row = 0; row < gridH; row++) {
          for (let col = 0; col < gridW; col++) {
            const seed = (row * 8 + col + Math.floor(frame / 40)) % 11;
            const isFilled = seed < 6;
            const x = startX + col * cellSize;
            const y = startY + row * cellSize;

            ctx.strokeStyle = '#122b48';
            ctx.strokeRect(x, y, cellSize, cellSize);

            if (isFilled) {
              const color = colors[(row + col) % colors.length];
              ctx.fillStyle = color;
              ctx.fillRect(x + 1, y + 1, cellSize - 2, cellSize - 2);

              // Highlights
              ctx.fillStyle = 'rgba(255,255,255,0.4)';
              ctx.fillRect(x + 1, y + 1, (cellSize - 2) / 2, 2);
            }
          }
        }

        // Animated combo blast laser line clearing
        const blastRow = Math.floor((frame / 20) % 8);
        const blastFlash = Math.sin(frame * 0.2);
        if (blastFlash > 0.3) {
          ctx.fillStyle = 'rgba(251, 191, 36, 0.8)';
          ctx.fillRect(startX, startY + blastRow * cellSize, gridW * cellSize, cellSize);

          // Particles
          ctx.fillStyle = '#fef08a';
          for (let p = 0; p < 8; p++) {
            ctx.beginPath();
            ctx.arc(startX + p * 12 + Math.sin(frame + p) * 4, startY + blastRow * cellSize + 5, 2, 0, Math.PI * 2);
            ctx.fill();
          }

          // Combo Text
          ctx.fillStyle = '#facc15';
          ctx.font = 'bold 10px monospace';
          ctx.textAlign = 'right';
          ctx.fillText(`COMBO x4 BLAST!`, w - 10, h - 12);
        }

        // Next pieces on left and right
        ctx.fillStyle = '#38bdf8';
        ctx.fillRect(15, 30, 8, 8);
        ctx.fillRect(23, 30, 8, 8);
        ctx.fillRect(15, 38, 8, 8);

        ctx.fillStyle = '#10b981';
        ctx.fillRect(w - 30, 30, 16, 8);
        ctx.fillRect(w - 30, 38, 8, 8);
      }

      // ==========================================
      // 2. FRUIT NINJA CUSTOM AI SIMULATOR
      // ==========================================
      else if (currentGame.category === 'fruit_ninja') {
        const fruitTypes = [
          { name: 'Watermelon', color: '#22c55e', inner: '#ef4444', r: 10 },
          { name: 'Orange', color: '#f97316', inner: '#fed7aa', r: 9 },
          { name: 'Banana', color: '#eab308', inner: '#fef9c3', r: 8 },
          { name: 'Strawberry', color: '#f43f5e', inner: '#ffe4e6', r: 7 }
        ];

        // 3 Flying fruits
        for (let i = 0; i < 3; i++) {
          const t = ((frame * 0.04) + i * 1.8) % Math.PI;
          const fx = 40 + i * 110 + Math.cos(t) * 25;
          const fy = h - Math.sin(t) * (h - 25);
          const f = fruitTypes[i % fruitTypes.length];

          // Fruit Left Half
          ctx.fillStyle = f.color;
          ctx.beginPath();
          ctx.arc(fx - 4, fy, f.r, Math.PI / 2, (3 * Math.PI) / 2);
          ctx.fill();
          ctx.fillStyle = f.inner;
          ctx.beginPath();
          ctx.arc(fx - 4, fy, f.r - 2, Math.PI / 2, (3 * Math.PI) / 2);
          ctx.fill();

          // Fruit Right Half
          ctx.fillStyle = f.color;
          ctx.beginPath();
          ctx.arc(fx + 4, fy, f.r, -(Math.PI / 2), Math.PI / 2);
          ctx.fill();
          ctx.fillStyle = f.inner;
          ctx.beginPath();
          ctx.arc(fx + 4, fy, f.r - 2, -(Math.PI / 2), Math.PI / 2);
          ctx.fill();

          // Juice Splatters
          ctx.fillStyle = f.inner;
          ctx.beginPath();
          ctx.arc(fx + Math.sin(frame * 0.1 + i) * 12, fy - 6, 2, 0, Math.PI * 2);
          ctx.arc(fx - Math.cos(frame * 0.1 + i) * 10, fy + 8, 1.5, 0, Math.PI * 2);
          ctx.fill();
        }

        // Dynamic Katana Blade Slash Arc
        const slashProgress = (frame * 0.08) % 1;
        const sx1 = 30 + slashProgress * (w - 60);
        const sy1 = 20 + Math.sin(frame * 0.1) * 35;
        const sx2 = sx1 + 45;
        const sy2 = sy1 + 25;

        // Glowing blade trail
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.8)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(sx1 - 20, sy1 - 10);
        ctx.quadraticCurveTo(sx1, sy1, sx2, sy2);
        ctx.stroke();

        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(sx1 - 15, sy1 - 8);
        ctx.quadraticCurveTo(sx1, sy1, sx2, sy2);
        ctx.stroke();

        // Bomb Avoidance Shield icon
        ctx.fillStyle = '#10b981';
        ctx.font = 'bold 9px monospace';
        ctx.textAlign = 'right';
        ctx.fillText(`🛡️ 0 BOMBS HIT | BLITZ`, w - 10, h - 12);
      }

      // ==========================================
      // 3. DUNGEON RPG / COMBAT
      // ==========================================
      else if (currentGame.category === 'dungeon_rpg' || currentGame.category === 'combat') {
        const hX = ((currentGame.simulationParams.heroX || 30) % (w - 40)) + 20;
        const hY = ((currentGame.simulationParams.heroY || 30) % (h - 40)) + 20;

        const pulse = Math.sin(frame * 0.1) * 4;
        ctx.fillStyle = 'rgba(16, 185, 129, 0.25)';
        ctx.beginPath();
        ctx.arc(hX, hY, 14 + pulse, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#10b981';
        ctx.beginPath();
        ctx.arc(hX, hY, 8, 0, Math.PI * 2);
        ctx.fill();

        for (let i = 0; i < 4; i++) {
          const angle = (frame * 0.02) + (i * Math.PI / 2);
          const mX = hX + Math.cos(angle) * (45 + Math.sin(frame * 0.05 + i) * 10);
          const mY = hY + Math.sin(angle) * (35 + Math.cos(frame * 0.05 + i) * 10);

          if (mX > 5 && mX < w - 5 && mY > 5 && mY < h - 5) {
            ctx.fillStyle = '#f43f5e';
            ctx.fillRect(mX - 4, mY - 4, 8, 8);

            if (i === Math.floor((frame / 15) % 4)) {
              ctx.strokeStyle = '#38bdf8';
              ctx.lineWidth = 2;
              ctx.beginPath();
              ctx.moveTo(hX, hY);
              ctx.lineTo(mX, mY);
              ctx.stroke();

              ctx.fillStyle = '#facc15';
              ctx.font = '9px monospace';
              ctx.fillText('-' + (currentGame.level * 45), mX, mY - 8);
            }
          }
        }
      }

      // ==========================================
      // 4. SPACE MINER / RUNNER / TYCOON
      // ==========================================
      else if (currentGame.category === 'space_miner') {
        const sX = w / 2;
        const sY = h / 2;

        ctx.fillStyle = '#38bdf8';
        ctx.beginPath();
        ctx.arc(sX, sY, 10, 0, Math.PI * 2);
        ctx.fill();

        for (let i = 0; i < 5; i++) {
          const angle = (frame * 0.015) + (i * Math.PI * 2 / 5);
          const aX = sX + Math.cos(angle) * 55;
          const aY = sY + Math.sin(angle) * 35;

          ctx.fillStyle = '#a855f7';
          ctx.beginPath();
          ctx.arc(aX, aY, 6, 0, Math.PI * 2);
          ctx.fill();

          ctx.strokeStyle = 'rgba(56, 189, 248, 0.6)';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(sX, sY);
          ctx.lineTo(aX, aY);
          ctx.stroke();
        }
      } else if (currentGame.category === 'cyber_runner') {
        const rY = h / 2 + Math.sin(frame * 0.15) * 20;
        const rX = 40;

        ctx.strokeStyle = '#ec4899';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(0, rY);
        ctx.lineTo(rX, rY);
        ctx.stroke();

        ctx.fillStyle = '#06b6d4';
        ctx.beginPath();
        ctx.arc(rX, rY, 8, 0, Math.PI * 2);
        ctx.fill();

        for (let i = 0; i < 3; i++) {
          const oX = (w - ((frame * 3 + i * 80) % w));
          const oY = (h / 2) + ((i % 2 === 0 ? 1 : -1) * 25);
          ctx.fillStyle = '#f43f5e';
          ctx.fillRect(oX, oY - 10, 8, 20);
        }
      } else {
        for (let i = 0; i < 6; i++) {
          const bX = 25 + (i * 35);
          const bH = 15 + Math.abs(Math.sin(frame * 0.05 + i) * 35);
          ctx.fillStyle = i % 2 === 0 ? '#10b981' : '#6366f1';
          ctx.fillRect(bX, h - 20 - bH, 20, bH);
        }
      }

      // HUD Overlay Top
      ctx.fillStyle = '#10b981';
      ctx.font = '9px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`AI APM: ${currentGame.actionsPerMinute} | SP: ${currentGame.speedMultiplier}x`, 8, 14);

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [game.id]);

  const expPercentage = Math.min(100, Math.floor((game.exp / game.maxExp) * 100));
  const bossHealthPercentage =
    game.maxBossHealth && game.currentBossHealth
      ? Math.max(0, Math.min(100, Math.floor((game.currentBossHealth / game.maxBossHealth) * 100)))
      : 100;

  const countdownText = formatCountdown(game.remainingSeconds);

  return (
    <div className="flex flex-col justify-between overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/90 shadow-lg backdrop-blur-md transition-all hover:border-emerald-500/40 hover:shadow-emerald-950/20">
      {/* Header */}
      <div className="border-b border-slate-800 p-4">
        <div className="flex items-start justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <span className="rounded-md bg-emerald-500/10 px-2 py-0.5 text-xs font-bold text-emerald-400">
                Lv. {game.level}
              </span>
              <h3 className="font-bold text-white line-clamp-1 text-sm">
                {isHindi ? game.nameHindi : game.name}
              </h3>
            </div>
            
            {/* Custom Mode & Behavior Badges */}
            <div className="mt-1.5 flex flex-wrap items-center gap-1">
              {game.playModeGoal === 'slice_only' ? (
                <span className="rounded bg-teal-500/15 border border-teal-500/30 px-1.5 py-0.5 text-[10px] font-bold text-teal-300">
                  🍉 {isHindi ? 'बस फ्रूट काटना' : 'Just Slice'}
                </span>
              ) : game.playModeGoal === 'level_up' ? (
                <span className="rounded bg-emerald-500/15 border border-emerald-500/30 px-1.5 py-0.5 text-[10px] font-bold text-emerald-300">
                  🚀 {isHindi ? 'लेवल रश' : 'Level Rush'}
                </span>
              ) : game.playModeGoal === 'boss_rush' ? (
                <span className="rounded bg-purple-500/15 border border-purple-500/30 px-1.5 py-0.5 text-[10px] font-bold text-purple-300">
                  👑 {isHindi ? 'बॉस हंटर' : 'Boss Hunter'}
                </span>
              ) : null}

              {game.touchProfile === 'human_like' && (
                <span className="rounded bg-cyan-500/15 border border-cyan-500/30 px-1.5 py-0.5 text-[10px] font-medium text-cyan-300">
                  👤 {isHindi ? 'इंसानी टच' : 'Human Touch'}
                </span>
              )}

              {game.batterySavingMode === 'ultra_saver' && (
                <span className="rounded bg-emerald-500/15 border border-emerald-500/30 px-1.5 py-0.5 text-[10px] font-medium text-emerald-300">
                  🔋 {isHindi ? 'बैटरी सेवर' : 'Eco Saver'}
                </span>
              )}

              {game.executionTarget === 'phone_installed_app' ? (
                <span className="rounded bg-amber-500/15 border border-amber-500/30 px-1.5 py-0.5 text-[10px] font-bold text-amber-300">
                  📱 {isHindi ? 'फोन ऐप' : 'Phone App'}
                </span>
              ) : (
                <span className="rounded bg-slate-800 px-1.5 py-0.5 text-[10px] text-slate-400">
                  💻 {isHindi ? 'हब इंजन' : 'Hub Engine'}
                </span>
              )}

              {game.autoCrossAds !== false && (
                <span className="rounded bg-rose-500/15 border border-rose-500/30 px-1.5 py-0.5 text-[10px] font-medium text-rose-300">
                  🛡️ ✕ {isHindi ? `${game.adDismissStats?.adsDismissed || 0} ऐड कट (0 डाउनलोड)` : `${game.adDismissStats?.adsDismissed || 0} Ads Cut (0 DL)`}
                </span>
              )}
            </div>

            <p className="mt-1 text-xs text-slate-400 line-clamp-1">
              {isHindi ? game.descriptionHindi : game.description}
            </p>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => onInspect(game)}
              className="flex h-7 w-7 items-center justify-center rounded-lg border border-slate-700 bg-slate-800 text-slate-300 hover:border-emerald-500 hover:text-white"
              title={isHindi ? 'फुलस्क्रीन इंस्पेक्ट' : 'Inspect Game'}
            >
              <Maximize2 className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => onTogglePause(game.id)}
              className={`flex h-7 w-7 items-center justify-center rounded-lg border ${
                game.status === 'paused'
                  ? 'border-emerald-500 bg-emerald-500/20 text-emerald-400'
                  : 'border-amber-500/40 bg-amber-500/10 text-amber-300'
              }`}
              title={game.status === 'paused' ? 'Resume' : 'Pause'}
            >
              {game.status === 'paused' ? <Play className="h-3.5 w-3.5" /> : <Pause className="h-3.5 w-3.5" />}
            </button>
            <button
              onClick={() => onRemove(game.id)}
              className="flex h-7 w-7 items-center justify-center rounded-lg border border-slate-700 bg-slate-800 text-slate-400 hover:border-rose-500 hover:text-rose-400"
              title={isHindi ? 'गेम हटाएं' : 'Disconnect'}
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Mini Simulation Visualizer Canvas */}
      <div className="relative h-28 w-full bg-slate-950">
        <canvas ref={canvasRef} width={340} height={112} className="h-full w-full object-cover" />
        <div className="pointer-events-none absolute bottom-2 right-2 rounded bg-slate-900/90 px-1.5 py-0.5 text-[10px] font-mono text-emerald-400 border border-emerald-500/30">
          🟢 {isHindi ? 'AI ऑटो-प्लेइंग' : 'AI Autoplay Active'}
        </div>
      </div>

      {/* Duration / Timer Status Ribbon (घंटे या लगातार खेलता रहे) */}
      <div className="flex items-center justify-between border-y border-slate-800/80 bg-slate-950/90 px-3 py-1.5 text-xs">
        <div className="flex items-center gap-1.5">
          <Clock className="h-3.5 w-3.5 text-cyan-400" />
          <span className="text-[11px] text-slate-400">
            {isHindi ? 'अवधि:' : 'Timer:'}
          </span>
          {countdownText ? (
            <span className="flex items-center gap-1 rounded bg-cyan-950/70 px-1.5 py-0.5 font-mono text-[11px] font-bold text-cyan-300 border border-cyan-500/30">
              <span className="h-1.5 w-1.5 animate-ping rounded-full bg-cyan-400" />
              {countdownText}
            </span>
          ) : (
            <span className="flex items-center gap-1 rounded bg-emerald-950/60 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-emerald-400 border border-emerald-500/20">
              <InfinityIcon className="h-3 w-3" />
              {isHindi ? 'लगातार 24/7 (अनंत)' : 'Endless 24/7'}
            </span>
          )}
        </div>

        {/* Change Duration Button */}
        <div className="relative">
          <button
            onClick={() => {
              playSound('click');
              setShowDurationPicker(!showDurationPicker);
            }}
            className="flex items-center gap-1 rounded bg-slate-800 px-2 py-0.5 text-[10px] font-medium text-slate-300 hover:bg-slate-700 hover:text-white"
          >
            <span>{isHindi ? 'घंटे सेट करें' : 'Set Hours'}</span>
            <ChevronDown className="h-3 w-3" />
          </button>

          {/* Duration Dropdown Popover */}
          {showDurationPicker && (
            <div className="absolute right-0 top-6 z-30 w-48 rounded-xl border border-slate-700 bg-slate-900 p-2 shadow-2xl">
              <div className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                {isHindi ? 'AI कितने घंटे खेले?' : 'Play Duration:'}
              </div>

              <div className="space-y-1 text-xs">
                <button
                  onClick={() => {
                    playSound('click');
                    onUpdateDuration(game.id, null);
                    setShowDurationPicker(false);
                  }}
                  className={`flex w-full items-center justify-between rounded-lg px-2 py-1 text-left ${
                    game.targetDurationHours === null
                      ? 'bg-emerald-600 text-white font-bold'
                      : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span>{isHindi ? '♾️ लगातार खेलता रहे' : '♾️ Endless (24/7)'}</span>
                  {game.targetDurationHours === null && <Check className="h-3 w-3" />}
                </button>

                {[1, 2, 4, 8, 12, 24].map((hrs) => (
                  <button
                    key={hrs}
                    onClick={() => {
                      playSound('click');
                      onUpdateDuration(game.id, hrs);
                      setShowDurationPicker(false);
                    }}
                    className={`flex w-full items-center justify-between rounded-lg px-2 py-1 text-left ${
                      game.targetDurationHours === hrs
                        ? 'bg-cyan-600 text-white font-bold'
                        : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span>{hrs} {isHindi ? (hrs === 1 ? 'घंटा' : 'घंटे') : (hrs === 1 ? 'hour' : 'hours')}</span>
                    {game.targetDurationHours === hrs && <Check className="h-3 w-3" />}
                  </button>
                ))}

                {/* Custom Hours Input */}
                <div className="border-t border-slate-800 pt-1.5 mt-1">
                  <div className="flex gap-1">
                    <input
                      type="number"
                      min="1"
                      max="100"
                      value={customHoursInput}
                      onChange={(e) => setCustomHoursInput(e.target.value)}
                      placeholder={isHindi ? 'घंटे...' : 'Hours...'}
                      className="w-full rounded bg-slate-950 px-2 py-1 text-[11px] text-white border border-slate-700 focus:outline-none focus:border-cyan-500"
                    />
                    <button
                      onClick={() => {
                        const val = parseFloat(customHoursInput);
                        if (val > 0) {
                          playSound('click');
                          onUpdateDuration(game.id, val);
                          setCustomHoursInput('');
                          setShowDurationPicker(false);
                        }
                      }}
                      className="rounded bg-cyan-600 px-2 py-1 text-[10px] font-bold text-white hover:bg-cyan-500"
                    >
                      OK
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-3 gap-2 border-y border-slate-800 bg-slate-950/60 p-3 text-center text-xs">
        <div>
          <span className="block text-[10px] text-slate-400">{isHindi ? 'स्कोर' : 'Score'}</span>
          <span className="font-bold text-amber-400">{game.score.toLocaleString()}</span>
        </div>
        <div>
          <span className="block text-[10px] text-slate-400">{isHindi ? 'गोल्ड/सिक्के' : 'Coins'}</span>
          <span className="font-bold text-yellow-300">🪙 {game.coins.toLocaleString()}</span>
        </div>
        <div>
          <span className="block text-[10px] text-slate-400">{isHindi ? 'क्रिस्टल' : 'Crystals'}</span>
          <span className="font-bold text-cyan-400">💎 {game.crystals}</span>
        </div>
      </div>

      {/* Level XP Progress */}
      <div className="px-4 py-2.5">
        <div className="mb-1 flex items-center justify-between text-xs">
          <span className="text-slate-400 flex items-center gap-1">
            <Sparkles className="h-3 w-3 text-emerald-400" />
            {isHindi ? 'लेवल प्रगति (XP)' : 'Level Progress (XP)'}
          </span>
          <span className="font-mono text-[11px] text-emerald-400">
            {game.exp} / {game.maxExp} ({expPercentage}%)
          </span>
        </div>
        <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 to-cyan-500 transition-all duration-300"
            style={{ width: `${expPercentage}%` }}
          />
        </div>
      </div>

      {/* Boss Battle HP Bar */}
      {game.bossName && (
        <div className="px-4 py-2 bg-rose-950/20 border-t border-rose-900/30">
          <div className="mb-1 flex items-center justify-between text-xs">
            <span className="text-rose-300 flex items-center gap-1 font-semibold truncate max-w-[200px]">
              <Skull className="h-3 w-3 text-rose-400 shrink-0" />
              {game.bossName}
            </span>
            <span className="font-mono text-[10px] text-rose-400 shrink-0">
              {bossHealthPercentage}% HP
            </span>
          </div>
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
            <div
              className="h-full bg-gradient-to-r from-rose-500 to-amber-500 transition-all duration-300"
              style={{ width: `${bossHealthPercentage}%` }}
            />
          </div>
        </div>
      )}

      {/* Strategy and Speed Controls */}
      <div className="p-4 pt-2 space-y-3 bg-slate-900/60">
        {/* Strategy Selector */}
        <div>
          <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1">
            {isHindi ? 'AI रणनीति मोड (Strategy):' : 'AI Bot Strategy:'}
          </label>
          <select
            value={game.strategy}
            onChange={(e) => {
              playSound('click');
              onUpdateStrategy(game.id, e.target.value as BotStrategy);
            }}
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-white focus:border-emerald-500 focus:outline-none"
          >
            <option value="aggressive_xp">{isHindi ? '⚔️ एग्रेसिव XP फार्मिंग (+120% XP)' : '⚔️ Aggressive XP Farming'}</option>
            <option value="boss_hunter">{isHindi ? '👑 बॉस हंटर (+लूट और क्रिस्टल्स)' : '👑 Boss Hunter Mode'}</option>
            <option value="gold_farmer">{isHindi ? '🪙 गोल्ड रश (+180% पैसिव इनकम)' : '🪙 Gold Rush Farmer'}</option>
            <option value="balanced">{isHindi ? '⚖️ बैलेंस्ड ऑटोप्ले' : '⚖️ Balanced Autoplay'}</option>
            <option value="overclock">{isHindi ? '🚀 ओवरक्लॉक मोड (मैक्स स्पीड)' : '🚀 Overclock AI Mode'}</option>
          </select>
        </div>

        {/* Speed Selector Buttons */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              {isHindi ? 'AI फार्मिंग स्पीड:' : 'AI Farm Speed:'}
            </span>
            <span className="text-xs font-bold text-amber-400">{game.speedMultiplier}x</span>
          </div>
          <div className="grid grid-cols-5 gap-1">
            {[1, 2, 3, 5, 10].map((spd) => (
              <button
                key={spd}
                type="button"
                onClick={() => {
                  playSound('overclock');
                  onUpdateSpeed(game.id, spd);
                }}
                className={`rounded-md py-1 text-xs font-bold transition-all ${
                  game.speedMultiplier === spd
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-sm shadow-emerald-900'
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'
                }`}
              >
                {spd}x
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
