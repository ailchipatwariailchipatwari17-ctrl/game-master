import React, { useState } from 'react';
import { Send, Sparkles, Mic, MicOff, Bot, RefreshCw, Terminal, CheckCircle2, ChevronRight } from 'lucide-react';
import { playSound } from '../utils/audio';
import { AiCommandResult, GameBotState } from '../types';

interface AICommanderBarProps {
  language: 'hi' | 'en';
  activeGames: GameBotState[];
  onApplyCommand: (commandText: string) => Promise<AiCommandResult | null>;
  isProcessing: boolean;
  latestAiResponse: AiCommandResult | null;
}

const HINDI_QUICK_COMMANDS = [
  '🛡️ सभी गेम्स में ऐड आते ही "✕" क्रॉस से कट करो और कोई ऐप डाउनलोड न करो',
  '🍉 Fruit Ninja में बस फ्रूट काटने का मोड और इंसानों जैसा टच लगाओ',
  '🚀 Block Blast में तेजी से लेवल पार करो और अल्ट्रा बैटरी सेवर ऑन करो',
  '📱 फोन पर डाउनलोड किए हुए गेम्स में स्क्रीन एक्सेसिबिलिटी से ऑटो-टच चलाओ',
  '👤 सभी बॉट्स को इंसानों जैसा नैचुरल स्वाइप (Human-like) पर सेट करो',
  '🔋 बैटरी सेवर ऑन करो ताकि मोबाइल की बैटरी न खत्म हो'
];

const ENGLISH_QUICK_COMMANDS = [
  '🛡️ Always Dismiss Ads with [✕] Cross Only, Zero App Downloads Guaranteed',
  '🍉 Set Fruit Ninja to Just-Slice Mode with Human-like Natural Swipes',
  '🚀 Set Block Blast to Fast Level-Up & enable Ultra Battery Saver',
  '📱 Run AI touch automation directly on Downloaded Phone Games',
  '👤 Enable 99.8% Human Natural Bezier touch profile on all bots',
  '🔋 Activate Screen-Off Ultra Battery Saver (-75% drain)'
];

export const AICommanderBar: React.FC<AICommanderBarProps> = ({
  language,
  activeGames,
  onApplyCommand,
  isProcessing,
  latestAiResponse
}) => {
  const [inputCommand, setInputCommand] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [terminalOpen, setTerminalOpen] = useState(true);

  const isHindi = language === 'hi';
  const quickCommands = isHindi ? HINDI_QUICK_COMMANDS : ENGLISH_QUICK_COMMANDS;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputCommand.trim() || isProcessing) return;
    playSound('ai_command');
    const cmd = inputCommand;
    setInputCommand('');
    await onApplyCommand(cmd);
  };

  const handleQuickCommand = async (cmd: string) => {
    playSound('ai_command');
    await onApplyCommand(cmd);
  };

  const handleVoiceToggle = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert(isHindi ? 'आपका ब्राउज़र स्पीच रिकॉग्निशन सपोर्ट नहीं करता।' : 'Speech recognition not supported in this browser.');
      return;
    }

    try {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.lang = isHindi ? 'hi-IN' : 'en-US';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListening(true);
        playSound('click');
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputCommand(transcript);
        setIsListening(false);
        playSound('ai_command');
        onApplyCommand(transcript);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch {
      setIsListening(false);
    }
  };

  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-4 sm:px-6">
      <div className="relative overflow-hidden rounded-2xl border border-emerald-500/30 bg-slate-900/90 p-4 shadow-xl backdrop-blur-xl sm:p-5">
        {/* Glow effect */}
        <div className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-emerald-500/10 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-20 -left-20 h-56 w-56 rounded-full bg-cyan-500/10 blur-3xl" />

        {/* Top bar */}
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-500/20 text-emerald-400">
              <Sparkles className="h-4 w-4" />
            </div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-emerald-400 sm:text-base">
              {isHindi ? 'AI सामरिक कमांडर (AI Tactical Commander)' : 'AI Autonomous Fleet Commander'}
            </h2>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-ping" />
            <span>
              {isHindi
                ? `${activeGames.length} गेम्स AI कंट्रोल में सक्रिय`
                : `${activeGames.length} Games under Neural Control`}
            </span>
          </div>
        </div>

        {/* Command Input Form */}
        <form onSubmit={handleSubmit} className="relative flex items-center gap-2">
          <div className="relative flex-1">
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
              <Bot className="h-4 w-4 text-emerald-400" />
            </div>
            <input
              type="text"
              value={inputCommand}
              onChange={(e) => setInputCommand(e.target.value)}
              placeholder={
                isHindi
                  ? 'AI को आदेश दें (उदा. "सब बॉट्स का लेवल 50 करो", "Speed 5x करो", "Boss पर हमला करो")...'
                  : 'Instruct the AI bot (e.g. "Focus all bots on XP farming", "Overclock speed to 5x", "Slay Dungeon Boss")...'
              }
              className="w-full rounded-xl border border-slate-700 bg-slate-950/80 py-3 pl-10 pr-12 text-sm text-white placeholder-slate-500 shadow-inner transition-all focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            />
            {/* Voice button */}
            <button
              type="button"
              onClick={handleVoiceToggle}
              className={`absolute inset-y-0 right-2 my-auto flex h-8 w-8 items-center justify-center rounded-lg transition-all ${
                isListening
                  ? 'bg-rose-500/20 text-rose-400 animate-pulse'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
              title={isHindi ? 'माइक से बोलें' : 'Voice Command'}
            >
              {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            </button>
          </div>

          <button
            type="submit"
            disabled={isProcessing || !inputCommand.trim()}
            className="flex h-11 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 px-5 text-sm font-semibold text-white shadow-lg shadow-emerald-950 transition-all hover:from-emerald-500 hover:to-cyan-500 active:scale-95 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {isProcessing ? (
              <RefreshCw className="h-4 w-4 animate-spin text-white" />
            ) : (
              <>
                <Send className="h-4 w-4" />
                <span className="hidden sm:inline">{isHindi ? 'लागू करें' : 'Execute'}</span>
              </>
            )}
          </button>
        </form>

        {/* Quick Suggestion Chips */}
        <div className="mt-3 flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 mr-1">
            {isHindi ? 'त्वरित निर्देश:' : 'Quick Directives:'}
          </span>
          {quickCommands.map((cmd, idx) => (
            <button
              key={idx}
              type="button"
              disabled={isProcessing}
              onClick={() => handleQuickCommand(cmd)}
              className="rounded-lg border border-slate-800 bg-slate-950/60 px-2.5 py-1 text-xs text-slate-300 transition-all hover:border-emerald-500/40 hover:bg-emerald-500/10 hover:text-emerald-300 active:scale-95 disabled:opacity-50"
            >
              {cmd}
            </button>
          ))}
        </div>

        {/* Latest AI Tactical Decision Terminal / Response */}
        {latestAiResponse && (
          <div className="mt-4 rounded-xl border border-emerald-500/30 bg-slate-950/90 p-3.5 shadow-inner">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
              <div className="flex items-center gap-2">
                <Terminal className="h-4 w-4 text-cyan-400" />
                <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">
                  {isHindi ? 'AI न्यूरल एग्जीक्यूशन लॉग' : 'AI Neural Execution Log'}
                </span>
                <span className="rounded bg-emerald-500/20 px-1.5 py-0.5 text-[10px] font-bold text-emerald-300">
                  {latestAiResponse.actionType || 'STRATEGY_APPLIED'}
                </span>
              </div>
              <span className="text-[11px] text-slate-400">
                {isHindi ? 'तत्काल प्रभाव से सक्रिय' : 'Applied in real-time'}
              </span>
            </div>

            <div className="pt-2.5 text-xs sm:text-sm">
              <p className="font-medium text-emerald-200">
                {isHindi ? latestAiResponse.replyHindi : latestAiResponse.replyEnglish}
              </p>
              {latestAiResponse.newGameSuggestion && (
                <div className="mt-2 flex items-center justify-between rounded-lg border border-cyan-500/30 bg-cyan-950/30 p-2 text-xs text-cyan-200">
                  <span>
                    🎮 {isHindi ? 'नया गेम तैयार:' : 'New Game Ready:'}{' '}
                    <strong>{latestAiResponse.newGameSuggestion.name}</strong>
                  </span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
