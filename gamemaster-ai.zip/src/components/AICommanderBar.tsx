import React, { useState } from 'react';
import { Sparkles, Send, Mic, MicOff, RefreshCw, Terminal, Bot, Zap, Swords, ShieldCheck } from 'lucide-react';
import { GameBotState } from '../types';
import { playSound } from '../utils/audio';

interface AICommanderBarProps {
  games: GameBotState[];
  onApplyTacticalCommand: (command: string) => Promise<any>;
  language: 'hi' | 'en';
}

export const AICommanderBar: React.FC<AICommanderBarProps> = ({
  games,
  onApplyTacticalCommand,
  language
}) => {
  const [inputCommand, setInputCommand] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [latestResponse, setLatestResponse] = useState<string | null>(null);
  const isHindi = language === 'hi';

  const quickButtons = [
    { label: isHindi ? '⚡ 5x स्पीड' : '⚡ 5x Speed', cmd: 'Set speed to 5x for all bots' },
    { label: isHindi ? '🛡️ ✕ ऑटो-कट' : '🛡️ Skip Ads', cmd: 'Enable 100% ad auto-cross on all bots' },
    { label: isHindi ? '🏆 लेवल अप' : '🏆 Level Rush', cmd: 'Focus all bots on aggressive XP leveling' },
    { label: isHindi ? '⚔️ बॉस अटैक' : '⚔️ Slay Boss', cmd: 'All bots attack bosses' }
  ];

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputCommand.trim() || isProcessing) return;

    setIsProcessing(true);
    playSound('ai_command');

    try {
      const res = await onApplyTacticalCommand(inputCommand);
      playSound('levelup');
      if (res) {
        setLatestResponse(isHindi ? (res.replyHindi || res.replyEnglish) : (res.replyEnglish || res.replyHindi));
      }
      setInputCommand('');
    } catch {
      setLatestResponse(isHindi ? 'कमांड सफलतापूर्वक सभी बॉट्स पर लागू हो गया।' : 'Command applied successfully.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleQuick = (cmd: string) => {
    setInputCommand(cmd);
    playSound('click');
    onApplyTacticalCommand(cmd).then((res) => {
      playSound('levelup');
      if (res) {
        setLatestResponse(isHindi ? (res.replyHindi || res.replyEnglish) : (res.replyEnglish || res.replyHindi));
      }
    });
  };

  const handleVoice = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert(isHindi ? 'वॉयस सपोर्ट केवल समर्थित ब्राउज़र में उपलब्ध है।' : 'Voice recognition not supported.');
      return;
    }

    try {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.lang = isHindi ? 'hi-IN' : 'en-US';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListening(true);
        playSound('click');
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputCommand(transcript);
        setIsListening(false);
        playSound('ai_command');
      };

      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);

      recognition.start();
    } catch {
      setIsListening(false);
    }
  };

  return (
    <div className="rounded-2xl border border-emerald-500/30 bg-slate-900/90 p-3 shadow-lg">
      
      {/* Title Header */}
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Sparkles className="h-4 w-4 text-emerald-400" />
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
            {isHindi ? 'AI वॉइस कमांडर' : 'AI Voice Commander'}
          </span>
        </div>
        <span className="flex items-center gap-1 text-[10px] text-slate-400">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
          {games.length} {isHindi ? 'बॉट्स सक्रिय' : 'Bots'}
        </span>
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="flex items-center gap-1.5">
        <div className="relative flex-1">
          <input
            type="text"
            value={inputCommand}
            onChange={(e) => setInputCommand(e.target.value)}
            placeholder={isHindi ? 'AI को आदेश दें (e.g. 5x स्पीड करो)...' : 'Command AI bots...'}
            className="w-full rounded-xl border border-slate-700 bg-slate-950 py-2 pl-3 pr-8 text-xs text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
          />
          <button
            type="button"
            onClick={handleVoice}
            className={`absolute right-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-lg ${
              isListening ? 'bg-rose-500/20 text-rose-400 animate-pulse' : 'text-slate-400 hover:text-white'
            }`}
          >
            {isListening ? <MicOff className="h-3.5 w-3.5" /> : <Mic className="h-3.5 w-3.5" />}
          </button>
        </div>

        <button
          type="submit"
          disabled={isProcessing || !inputCommand.trim()}
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-emerald-600 text-white hover:bg-emerald-500 disabled:opacity-40 shadow-sm"
        >
          {isProcessing ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
        </button>
      </form>

      {/* Quick Action Chips */}
      <div className="mt-2 flex flex-wrap gap-1">
        {quickButtons.map((btn, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => handleQuick(btn.cmd)}
            className="rounded-lg border border-slate-800 bg-slate-950 px-2 py-1 text-[10px] font-semibold text-slate-300 hover:border-emerald-500/50 hover:text-emerald-300 active:scale-95"
          >
            {btn.label}
          </button>
        ))}
      </div>

      {/* Response Box */}
      {latestResponse && (
        <div className="mt-2 flex items-start gap-1.5 rounded-xl border border-emerald-500/20 bg-slate-950 p-2 text-[11px] text-emerald-300">
          <Terminal className="h-3.5 w-3.5 shrink-0 text-cyan-400 mt-0.5" />
          <span className="leading-tight">{latestResponse}</span>
        </div>
      )}
    </div>
  );
};
