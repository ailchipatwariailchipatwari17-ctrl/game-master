import React from 'react';
import { Bot, Zap, Volume2, VolumeX, Globe, Plus, ShieldCheck, Cpu, Smartphone } from 'lucide-react';
import { playSound, setMuted, getMuted } from '../utils/audio';

interface NavbarProps {
  language: 'hi' | 'en';
  onToggleLanguage: () => void;
  activeCount: number;
  totalScore: number;
  totalLevel: number;
  totalApm: number;
  onOpenConnectModal: () => void;
  onOpenPhoneModal: () => void;
  onGlobalOverclock: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  language,
  onToggleLanguage,
  activeCount,
  totalScore,
  totalLevel,
  totalApm,
  onOpenConnectModal,
  onOpenPhoneModal,
  onGlobalOverclock
}) => {
  const [muted, setMutedState] = React.useState(getMuted());

  const handleToggleSound = () => {
    const next = !muted;
    setMuted(next);
    setMutedState(next);
    if (!next) {
      playSound('click');
    }
  };

  const isHindi = language === 'hi';

  return (
    <header className="sticky top-0 z-40 w-full border-b border-emerald-500/20 bg-slate-950/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        {/* Left: Branding & Status */}
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-600 shadow-lg shadow-emerald-500/20">
            <Bot className="h-6 w-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold tracking-tight text-white sm:text-xl">
                {isHindi ? 'AutoPlay AI' : 'AutoPlay AI'}
              </h1>
              <span className="inline-flex items-center gap-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 text-xs font-semibold text-emerald-400">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
                {isHindi ? 'बैकग्राउंड 24/7' : '24/7 Background'}
              </span>
            </div>
            <p className="hidden text-xs text-slate-400 sm:block">
              {isHindi
                ? 'मल्टी-गेम ऑटोनॉमस AI फार्मिंग हब (बिना रुकावट स्कोर और लेवल बढ़ाएं)'
                : 'Multi-Game Autonomous AI Bot & Leveling Hub'}
            </p>
          </div>
        </div>

        {/* Center: Live Real-time Telemetry Stats */}
        <div className="hidden items-center gap-6 rounded-xl border border-slate-800 bg-slate-900/80 px-4 py-1.5 md:flex">
          <div className="text-center">
            <span className="block text-[10px] font-medium uppercase tracking-wider text-slate-400">
              {isHindi ? 'सक्रिय गेम्स' : 'Active Games'}
            </span>
            <span className="text-sm font-bold text-emerald-400">{activeCount} Bots</span>
          </div>
          <div className="h-6 w-[1px] bg-slate-800" />
          <div className="text-center">
            <span className="block text-[10px] font-medium uppercase tracking-wider text-slate-400">
              {isHindi ? 'कुल स्कोर' : 'Total Score'}
            </span>
            <span className="text-sm font-bold text-amber-400">{totalScore.toLocaleString()}</span>
          </div>
          <div className="h-6 w-[1px] bg-slate-800" />
          <div className="text-center">
            <span className="block text-[10px] font-medium uppercase tracking-wider text-slate-400">
              {isHindi ? 'कुल लेवल' : 'Combined Level'}
            </span>
            <span className="text-sm font-bold text-cyan-400">Lv. {totalLevel}</span>
          </div>
          <div className="h-6 w-[1px] bg-slate-800" />
          <div className="text-center">
            <span className="block text-[10px] font-medium uppercase tracking-wider text-slate-400">
              {isHindi ? 'AI स्पीड' : 'Total APM'}
            </span>
            <span className="text-sm font-bold text-purple-400">{totalApm} APM</span>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2">
          {/* Phone Game Companion Link */}
          <button
            onClick={() => {
              playSound('click');
              onOpenPhoneModal();
            }}
            className="flex items-center gap-1.5 rounded-lg border border-cyan-500/40 bg-cyan-500/10 px-3 py-1.5 text-xs font-bold text-cyan-300 transition-all hover:bg-cyan-500/20 active:scale-95 shadow-sm shadow-cyan-950"
            title={isHindi ? 'फोन पर डाउनलोड किए गए गेम्स सिंक करें' : 'Connect & Sync Downloaded Phone Games'}
          >
            <Smartphone className="h-3.5 w-3.5 text-cyan-400" />
            <span>{isHindi ? '📱 फोन गेम सिंक' : '📱 Phone Sync'}</span>
          </button>

          {/* Global Overclock */}
          <button
            onClick={() => {
              playSound('overclock');
              onGlobalOverclock();
            }}
            className="flex items-center gap-1.5 rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-1.5 text-xs font-semibold text-amber-300 transition-all hover:bg-amber-500/20 active:scale-95"
            title={isHindi ? 'सभी गेम्स को 5x स्पीड पर ओवरक्लॉक करें' : 'Overclock all games to 5x speed'}
          >
            <Zap className="h-3.5 w-3.5 text-amber-400" />
            <span className="hidden sm:inline">{isHindi ? '5x ओवरक्लॉक' : '5x Overclock'}</span>
          </button>

          {/* Connect New Game */}
          <button
            onClick={() => {
              playSound('click');
              onOpenConnectModal();
            }}
            className="flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 px-3 py-1.5 text-xs font-semibold text-white shadow-md shadow-emerald-900/30 transition-all hover:from-emerald-500 hover:to-teal-500 active:scale-95"
          >
            <Plus className="h-4 w-4" />
            <span>{isHindi ? '+ नया गेम जोड़ें' : '+ Connect Game'}</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={handleToggleSound}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-800 bg-slate-900 text-slate-400 transition-colors hover:text-white"
            title={muted ? 'Unmute' : 'Mute'}
          >
            {muted ? <VolumeX className="h-4 w-4 text-rose-400" /> : <Volume2 className="h-4 w-4 text-emerald-400" />}
          </button>

          {/* Language Toggle */}
          <button
            onClick={() => {
              playSound('click');
              onToggleLanguage();
            }}
            className="flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-900 px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white"
          >
            <Globe className="h-3.5 w-3.5 text-cyan-400" />
            <span>{isHindi ? 'EN' : 'हिंदी'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
