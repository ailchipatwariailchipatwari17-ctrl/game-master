import React from 'react';
import { Bot, Zap, Volume2, VolumeX, Globe, Plus, Smartphone } from 'lucide-react';
import { playSound, setMuted, getMuted } from '../utils/audio';

interface NavbarProps {
  language: 'hi' | 'en';
  onToggleLanguage: () => void;
  activeCount: number;
  totalScore: number;
  totalLevel: number;
  totalApm: number;
  onOpenConnectModal: () => void;
  onOpenPhoneModal: () => void;
  onGlobalOverclock: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  language,
  onToggleLanguage,
  activeCount,
  totalScore,
  totalLevel,
  totalApm,
  onOpenConnectModal,
  onOpenPhoneModal,
  onGlobalOverclock
}) => {
  const [muted, setMutedState] = React.useState(getMuted());

  const handleToggleSound = () => {
    const next = !muted;
    setMuted(next);
    setMutedState(next);
    if (!next) playSound('click');
  };

  const isHindi = language === 'hi';

  return (
    <header className="sticky top-0 z-40 w-full border-b border-emerald-500/20 bg-slate-950/95 backdrop-blur-md">
      <div className="mx-auto flex max-w-md items-center justify-between px-3 py-2.5">
        
        {/* Left: App Logo & Active Pill */}
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-600 shadow-md shadow-emerald-500/20 text-white font-black text-sm">
            🤖
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-sm font-bold tracking-tight text-white">
                AutoPlay AI
              </h1>
              <span className="flex items-center gap-1 rounded-full bg-emerald-500/20 px-1.5 py-0.2 text-[9px] font-bold text-emerald-400">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
                24/7
              </span>
            </div>
          </div>
        </div>

        {/* Right: Quick Action Icons */}
        <div className="flex items-center gap-1.5">
          {/* Phone Game Scanner Icon */}
          <button
            onClick={() => {
              playSound('click');
              onOpenPhoneModal();
            }}
            className="flex h-8 items-center gap-1 rounded-lg border border-cyan-500/40 bg-cyan-500/10 px-2 text-[11px] font-bold text-cyan-300 active:scale-95 shadow-sm"
            title={isHindi ? 'फोन गेम स्कैनर' : 'Phone Scanner'}
          >
            <Smartphone className="h-3.5 w-3.5 text-cyan-400" />
            <span>{isHindi ? 'स्कैन' : 'Scan'}</span>
          </button>

          {/* 5x Overclock */}
          <button
            onClick={() => {
              playSound('overclock');
              onGlobalOverclock();
            }}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-amber-500/30 bg-amber-500/10 text-amber-400 active:scale-95"
            title="5x Overclock"
          >
            <Zap className="h-4 w-4 fill-amber-400" />
          </button>

          {/* Add Game */}
          <button
            onClick={() => {
              playSound('click');
              onOpenConnectModal();
            }}
            className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-600 text-white active:scale-95 shadow-md shadow-emerald-950"
            title={isHindi ? 'नया गेम जोड़ें' : 'Add Game'}
          >
            <Plus className="h-4 w-4" />
          </button>

          {/* Audio */}
          <button
            onClick={handleToggleSound}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-800 bg-slate-900 text-slate-400"
          >
            {muted ? <VolumeX className="h-3.5 w-3.5 text-rose-400" /> : <Volume2 className="h-3.5 w-3.5 text-emerald-400" />}
          </button>

          {/* Lang */}
          <button
            onClick={() => {
              playSound('click');
              onToggleLanguage();
            }}
            className="flex h-8 items-center justify-center rounded-lg border border-slate-800 bg-slate-900 px-2 text-[10px] font-bold text-slate-300"
          >
            {isHindi ? 'EN' : 'हिं'}
          </button>
        </div>
      </div>

      {/* Mini Stats Ribbon */}
      <div className="mx-auto flex max-w-md items-center justify-around border-t border-slate-900 bg-slate-900/60 py-1 px-3 text-[10px]">
        <div className="flex items-center gap-1">
          <span className="text-slate-500">Bots:</span>
          <span className="font-bold text-emerald-400">{activeCount}</span>
        </div>
        <div className="h-3 w-[1px] bg-slate-800" />
        <div className="flex items-center gap-1">
          <span className="text-slate-500">Score:</span>
          <span className="font-bold text-amber-400">{totalScore.toLocaleString()}</span>
        </div>
        <div className="h-3 w-[1px] bg-slate-800" />
        <div className="flex items-center gap-1">
          <span className="text-slate-500">Level:</span>
          <span className="font-bold text-cyan-400">Lv.{totalLevel}</span>
        </div>
        <div className="h-3 w-[1px] bg-slate-800" />
        <div className="flex items-center gap-1">
          <span className="text-slate-500">Speed:</span>
          <span className="font-bold text-purple-400">{totalApm} APM</span>
        </div>
      </div>
    </header>
  );
};
