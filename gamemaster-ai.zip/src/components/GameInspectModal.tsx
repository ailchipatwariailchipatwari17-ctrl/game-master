import React, { useState } from 'react';
import { X, Shield, Zap, Sparkles, Award, Swords, Skull, Plus, Terminal, CheckCircle2, ChevronRight, Clock, Infinity as InfinityIcon, Check, Eye } from 'lucide-react';
import { GameBotState, BotStrategy } from '../types';
import { playSound } from '../utils/audio';
import { LiveGameScreen } from './LiveGameScreen';

interface GameInspectModalProps {
  game: GameBotState | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdateStrategy: (gameId: string, strategy: BotStrategy) => void;
  onUpdateDuration: (gameId: string, hours: number | null) => void;
  onUpgradeSkill: (gameId: string, skill: keyof GameBotState['skills']) => void;
  onAddDirective: (gameId: string, directive: string) => void;
  language: 'hi' | 'en';
}

export const GameInspectModal: React.FC<GameInspectModalProps> = ({
  game,
  isOpen,
  onClose,
  onUpdateStrategy,
  onUpdateDuration,
  onUpgradeSkill,
  onAddDirective,
  language
}) => {
  const [newDirective, setNewDirective] = useState('');
  const [customHours, setCustomHours] = useState('');
  const isHindi = language === 'hi';

  if (!isOpen || !game) return null;

  const formatCountdown = (seconds: number | null) => {
    if (seconds === null || seconds === undefined) return null;
    const s = Math.max(0, Math.floor(seconds));
    const hrs = Math.floor(s / 3600);
    const mins = Math.floor((s % 3600) / 60);
    const secs = s % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAddDirectiveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDirective.trim()) return;
    playSound('ai_command');
    onAddDirective(game.id, newDirective.trim());
    setNewDirective('');
  };

  const countdownText = formatCountdown(game.remainingSeconds);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-3 backdrop-blur-md">
      <div className="relative max-h-[95vh] w-full max-w-md overflow-y-auto rounded-3xl border border-cyan-500/40 bg-slate-950 p-4 shadow-2xl text-slate-100 space-y-3">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 shadow-md">
              <Swords className="h-5 w-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">
                  {isHindi ? game.nameHindi : game.name}
                </h2>
                <span className="rounded-md bg-emerald-500/20 px-2 py-0.5 text-xs font-bold text-emerald-400">
                  Lv. {game.level}
                </span>
              </div>
              <p className="text-[11px] text-cyan-300">
                🔴 {isHindi ? 'लाइव गेम स्क्रीन व टच विज़ुअलाइज़र' : 'Live Game Screen & Touch Stream'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* 🔴 FULLSCREEN LIVE SIMULATED GAME WITH REAL TOUCH CLICKS & GAMEPLAY */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-xs px-1">
            <span className="font-bold text-slate-300 flex items-center gap-1.5">
              <Eye className="h-3.5 w-3.5 text-emerald-400" />
              {isHindi ? 'गेम स्क्रीन (जहाँ AI क्लिक कर रहा है):' : 'Live Screen (AI Touch Clicks):'}
            </span>
            <span className="text-[10px] text-cyan-400 font-mono">
              ⚡ {game.actionsPerMinute} APM
            </span>
          </div>
          
          <LiveGameScreen game={game} language={language} height={290} showOverlayStats={true} />
        </div>

        {/* Duration / Gameplay Timer Bar */}
        <div className="rounded-2xl border border-cyan-500/30 bg-slate-900/80 p-3 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Clock className="h-4 w-4 text-cyan-400" />
              <span className="text-xs font-bold text-cyan-300">
                {isHindi ? 'AI खेलने की अवधि (Timer):' : 'Duration Timer:'}
              </span>
            </div>

            {countdownText ? (
              <div className="flex items-center gap-1.5 rounded-lg bg-cyan-950 px-2.5 py-1 border border-cyan-500/40">
                <span className="h-2 w-2 animate-ping rounded-full bg-cyan-400" />
                <span className="font-mono text-xs font-bold text-cyan-300">
                  {countdownText}
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-1 rounded-lg bg-emerald-950 px-2 py-0.5 border border-emerald-500/30 text-[11px] font-bold text-emerald-400">
                <InfinityIcon className="h-3.5 w-3.5" />
                <span>{isHindi ? '24/7 अनवरत' : 'Endless 24/7'}</span>
              </div>
            )}
          </div>

          {/* Quick Duration Buttons */}
          <div className="flex flex-wrap items-center gap-1.5 pt-1">
            <button
              onClick={() => {
                playSound('click');
                onUpdateDuration(game.id, null);
              }}
              className={`flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-semibold ${
                game.targetDurationHours === null
                  ? 'bg-emerald-600 text-white font-bold'
                  : 'bg-slate-800 text-slate-300'
              }`}
            >
              <InfinityIcon className="h-3 w-3" />
              <span>{isHindi ? '24/7 लगातार' : '24/7 Endless'}</span>
            </button>

            {[1, 2, 4, 8].map((hrs) => (
              <button
                key={hrs}
                onClick={() => {
                  playSound('click');
                  onUpdateDuration(game.id, hrs);
                }}
                className={`rounded-lg px-2.5 py-1 text-xs font-semibold ${
                  game.targetDurationHours === hrs
                    ? 'bg-cyan-600 text-white font-bold'
                    : 'bg-slate-800 text-slate-300'
                }`}
              >
                {hrs} {isHindi ? (hrs === 1 ? 'घंटा' : 'घंटे') : (hrs === 1 ? 'hr' : 'hrs')}
              </button>
            ))}
          </div>
        </div>

        {/* Telemetry Stats Grid */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="rounded-xl bg-slate-900/90 p-2.5 border border-slate-800">
            <span className="block text-[10px] text-slate-400">{isHindi ? 'कुल स्कोर' : 'Total Score'}</span>
            <span className="text-base font-bold text-amber-400">{game.score.toLocaleString()}</span>
          </div>
          <div className="rounded-xl bg-slate-900/90 p-2.5 border border-slate-800">
            <span className="block text-[10px] text-slate-400">{isHindi ? 'गोल्ड कॉइन्स' : 'Gold Coins'}</span>
            <span className="text-base font-bold text-yellow-300">🪙 {game.coins.toLocaleString()}</span>
          </div>
        </div>

        {/* Strategy Selector */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-3 space-y-2">
          <span className="block text-xs font-bold text-slate-300">
            {isHindi ? 'AI रणनीति (Strategy):' : 'AI Play Strategy:'}
          </span>
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'balanced', name: isHindi ? 'संतुलित (Balanced)' : 'Balanced', emoji: '⚖️' },
              { id: 'aggressive_xp', name: isHindi ? 'फास्ट लेवल अप (Fast XP)' : 'Fast XP', emoji: '⚡' },
              { id: 'farm_coins', name: isHindi ? 'गोल्ड फार्मिंग (Coins)' : 'Farm Coins', emoji: '🪙' },
              { id: 'overclock', name: isHindi ? 'ओवरक्लॉक 5x (Blitz)' : 'Overclock 5x', emoji: '🔥' }
            ].map((strat) => (
              <button
                key={strat.id}
                onClick={() => {
                  playSound('click');
                  onUpdateStrategy(game.id, strat.id as BotStrategy);
                }}
                className={`flex items-center gap-1.5 rounded-xl p-2 text-xs font-bold text-left transition-all ${
                  game.strategy === strat.id
                    ? 'border border-cyan-500 bg-cyan-950/80 text-cyan-300 shadow'
                    : 'border border-slate-800 bg-slate-900 text-slate-400 hover:text-white'
                }`}
              >
                <span>{strat.emoji}</span>
                <span className="text-[11px] truncate">{strat.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Footer */}
        <button
          onClick={onClose}
          className="w-full rounded-xl bg-slate-800 py-2.5 text-xs font-bold text-slate-300 hover:bg-slate-700"
        >
          {isHindi ? 'स्क्रीन बंद करें' : 'Close Screen'}
        </button>

      </div>
    </div>
  );
};
