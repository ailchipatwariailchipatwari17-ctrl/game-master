import React, { useState, useEffect } from 'react';
import { Terminal, RefreshCw, Zap, ShieldCheck, Activity } from 'lucide-react';
import { BotLog, GameBotState } from '../types';
import { playSound } from '../utils/audio';

interface TelemetryHubProps {
  logs: BotLog[];
  activeGames: GameBotState[];
  language: 'hi' | 'en';
}

export const TelemetryHub: React.FC<TelemetryHubProps> = ({
  logs,
  activeGames,
  language
}) => {
  const [advisorData, setAdvisorData] = useState<{
    hindiTips: string[];
    englishTips: string[];
    estimatedSynergyMultiplier: string;
    statusSummary: string;
  } | null>(null);
  const [activeTab, setActiveTab] = useState<'logs' | 'tips'>('logs');
  const isHindi = language === 'hi';

  const fetchAdvisorTips = async () => {
    try {
      const res = await fetch('/api/ai/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ activeGames })
      });
      const data = await res.json();
      if (data.analysis) {
        setAdvisorData(data.analysis);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchAdvisorTips();
  }, [activeGames.length]);

  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-3 shadow-lg">
      
      {/* Tab Switcher */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setActiveTab('logs')}
            className={`flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-bold transition-all ${
              activeTab === 'logs' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Terminal className="h-3.5 w-3.5" />
            <span>{isHindi ? 'लाइव AI लॉग' : 'Live Logs'}</span>
          </button>
          <button
            onClick={() => setActiveTab('tips')}
            className={`flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-bold transition-all ${
              activeTab === 'tips' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Zap className="h-3.5 w-3.5" />
            <span>{isHindi ? 'AI टिप्स' : 'AI Tips'}</span>
          </button>
        </div>

        <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-mono">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
          {logs.length} events
        </span>
      </div>

      {/* Content */}
      <div className="mt-2">
        {activeTab === 'logs' ? (
          <div className="h-32 overflow-y-auto space-y-1 font-mono text-[10px]">
            {logs.length === 0 ? (
              <div className="text-slate-500 text-center py-8">
                {isHindi ? 'AI बॉट सक्रिय हैं...' : 'AI bots active...'}
              </div>
            ) : (
              logs.slice(0, 15).map((log, idx) => (
                <div
                  key={`${log.id || 'log'}_${idx}`}
                  className="flex items-center justify-between rounded bg-slate-950/70 px-2 py-1 text-slate-300"
                >
                  <span className="truncate mr-2">
                    {isHindi ? log.messageHindi : log.messageEnglish}
                  </span>
                  <span className="text-[9px] text-slate-500 shrink-0">
                    {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              ))
            )}
          </div>
        ) : (
          <div className="space-y-1.5 text-xs py-1">
            {advisorData ? (
              (isHindi ? advisorData.hindiTips : advisorData.englishTips || []).map((tip, i) => (
                <div key={i} className="flex items-start gap-1.5 rounded-lg bg-slate-950 p-1.5 text-[11px] text-slate-300">
                  <Zap className="h-3 w-3 mt-0.5 shrink-0 text-amber-400" />
                  <span>{tip}</span>
                </div>
              ))
            ) : (
              <div className="text-center text-xs text-slate-500 py-6">
                {isHindi ? 'AI सुझाव लोड हो रहे हैं...' : 'Loading AI recommendations...'}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
