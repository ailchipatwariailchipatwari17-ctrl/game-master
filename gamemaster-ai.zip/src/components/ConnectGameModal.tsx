import React, { useState } from 'react';
import { X, Sparkles, Plus, Smartphone, Clock, Infinity as InfinityIcon, Settings2, RefreshCw } from 'lucide-react';
import { GameBotState, GameCategory } from '../types';
import { playSound } from '../utils/audio';
import { GameSetupModal } from './GameSetupModal';

interface ConnectGameModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddGame: (game: GameBotState) => void;
  onOpenPhoneModal?: () => void;
  language: 'hi' | 'en';
}

const PRESET_TEMPLATES = [
  {
    name: 'Block Blast!',
    nameHindi: 'ब्लॉक ब्लास्ट (Block Blast)',
    category: 'block_blast' as GameCategory,
    description: '8x8 Solver & Combo Blast',
    descriptionHindi: '8x8 कॉम्बो व लेवल रश',
    packageName: 'com.block.puzzle.game.blast',
    bossName: 'Grid Overlord',
    initialScore: 8500,
    speed: 3
  },
  {
    name: 'Fruit Ninja',
    nameHindi: 'फ्रूट निंजा (Fruit Ninja)',
    category: 'fruit_ninja' as GameCategory,
    description: 'Ultra-fast Slice & Bomb Dodge',
    descriptionHindi: 'फ्रूट स्लाइस व जीरो-बम',
    packageName: 'com.halfbrick.fruitninja',
    bossName: 'Sensei Titan',
    initialScore: 9200,
    speed: 3
  },
  {
    name: 'Subway Surfers',
    nameHindi: 'सबवे सर्फर्स (Subway Surfers)',
    category: 'cyber_runner' as GameCategory,
    description: 'Sub-second lane swipes & infinite coins',
    descriptionHindi: 'रिफ्लेक्स जंप/स्वाइप',
    packageName: 'com.kiloo.subwaysurf',
    bossName: 'Inspector Chase',
    initialScore: 12000,
    speed: 3
  },
  {
    name: 'Cyber Dungeon',
    nameHindi: 'डंगियन आरपीजी (RPG Slayer)',
    category: 'dungeon_rpg' as GameCategory,
    description: 'Auto-combat & gear leveling',
    descriptionHindi: 'ऑटो-कॉम्बैट व लेवल अप',
    bossName: 'Abyss Lord',
    initialScore: 5000,
    speed: 2
  }
];

export const ConnectGameModal: React.FC<ConnectGameModalProps> = ({
  isOpen,
  onClose,
  onAddGame,
  onOpenPhoneModal,
  language
}) => {
  const [customPrompt, setCustomPrompt] = useState('');
  const [targetHours, setTargetHours] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedTemplateForSetup, setSelectedTemplateForSetup] = useState<typeof PRESET_TEMPLATES[0] | null>(null);
  const isHindi = language === 'hi';

  if (!isOpen) return null;

  const handleOpenSetupWizard = (template: typeof PRESET_TEMPLATES[0]) => {
    playSound('click');
    setSelectedTemplateForSetup(template);
  };

  const handleGenerateCustom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customPrompt.trim() || isGenerating) return;
    setIsGenerating(true);
    playSound('ai_command');

    try {
      const res = await fetch('/api/ai/create-game', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gamePrompt: customPrompt })
      });
      const data = await res.json();
      const g = data.game || {};

      let resolvedCategory: GameCategory = 'custom';
      const promptLower = customPrompt.toLowerCase();
      if (promptLower.includes('block') || promptLower.includes('blast')) {
        resolvedCategory = 'block_blast';
      } else if (promptLower.includes('fruit') || promptLower.includes('ninja')) {
        resolvedCategory = 'fruit_ninja';
      }

      const newGame: GameBotState = {
        id: `game_custom_${Date.now()}`,
        name: g.name || customPrompt,
        nameHindi: g.nameHindi || customPrompt,
        category: resolvedCategory,
        description: g.description || 'Custom autonomous AI bot.',
        descriptionHindi: g.lore || 'कस्टम AI बॉट',
        status: 'active',
        level: 1,
        exp: 0,
        maxExp: 600,
        score: 5000,
        highScore: 5000,
        coins: 1500,
        crystals: 15,
        bossesDefeated: 0,
        bossName: 'Nexus Boss',
        currentBossHealth: 2000,
        maxBossHealth: 2000,
        actionsPerMinute: 300,
        speedMultiplier: 2,
        strategy: 'aggressive_xp',
        customDirectives: [g.directive || 'Auto-level fast'],
        uptimeSeconds: 0,
        targetDurationHours: targetHours ? parseFloat(targetHours) : null,
        remainingSeconds: targetHours ? parseFloat(targetHours) * 3600 : null,
        autoUpgrade: true,
        botConfidence: 99,
        autoCrossAds: true,
        blockAdDownloads: true,
        adDismissStats: { adsDismissed: 0, downloadsBlocked: 0, fakeCrossesFiltered: 0 },
        playModeGoal: 'level_up',
        touchProfile: 'human_like',
        batterySavingMode: 'ultra_saver',
        executionTarget: 'phone_installed_app',
        phonePackageName: `com.${customPrompt.toLowerCase().replace(/[^a-z0-9]/g, '')}.game`,
        skills: { strength: 12, agility: 12, intelligence: 12, vitality: 12 },
        inventory: [{ id: `item_${Date.now()}`, name: 'Nexus Blade', rarity: 'rare', bonus: '+20% APM' }],
        lastTickTime: Date.now(),
        simulationParams: { heroX: 100, heroY: 100, monstersCount: 2, multiplier: 1.5, currentWave: 1 }
      };

      onAddGame(newGame);
      onClose();
    } catch {
      // Fallback
      const newGame: GameBotState = {
        id: `game_custom_${Date.now()}`,
        name: customPrompt,
        nameHindi: customPrompt,
        category: 'block_blast',
        description: 'Autonomous AI Player',
        descriptionHindi: 'AI ऑटो-प्लेयर',
        status: 'active',
        level: 1,
        exp: 0,
        maxExp: 600,
        score: 4000,
        highScore: 4000,
        coins: 1000,
        crystals: 10,
        bossesDefeated: 0,
        bossName: 'Target Boss',
        currentBossHealth: 1500,
        maxBossHealth: 1500,
        actionsPerMinute: 280,
        speedMultiplier: 2,
        strategy: 'aggressive_xp',
        customDirectives: ['Level up velocity'],
        uptimeSeconds: 0,
        targetDurationHours: targetHours ? parseFloat(targetHours) : null,
        remainingSeconds: targetHours ? parseFloat(targetHours) * 3600 : null,
        autoUpgrade: true,
        botConfidence: 99,
        skills: { strength: 10, agility: 10, intelligence: 10, vitality: 10 },
        inventory: [],
        lastTickTime: Date.now(),
        simulationParams: { heroX: 100, heroY: 100, monstersCount: 0, multiplier: 1.5, currentWave: 1 }
      };
      onAddGame(newGame);
      onClose();
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3 backdrop-blur-md">
      <div className="relative max-h-[90vh] w-full max-w-md overflow-y-auto rounded-3xl border border-emerald-500/30 bg-slate-950 p-4 text-slate-100 shadow-2xl">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-500/20 text-emerald-400">
              <Plus className="h-4 w-4" />
            </div>
            <h3 className="text-sm font-bold text-white">
              {isHindi ? 'नया गेम जोड़ें' : 'Connect Game'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="flex h-7 w-7 items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>

        {/* Phone Scanner Link Banner */}
        {onOpenPhoneModal && (
          <button
            onClick={() => {
              playSound('click');
              onClose();
              onOpenPhoneModal();
            }}
            className="mt-3 flex w-full items-center justify-between rounded-2xl border border-cyan-500/40 bg-cyan-950/40 p-3 text-left hover:bg-cyan-900/30 active:scale-95"
          >
            <div className="flex items-center gap-2.5">
              <Smartphone className="h-5 w-5 text-cyan-400" />
              <div>
                <span className="block text-xs font-bold text-white">
                  {isHindi ? '📱 फोन गेम स्कैनर' : '📱 Scan Phone Games'}
                </span>
                <span className="text-[10px] text-cyan-300">
                  {isHindi ? 'फोन के गेम्स को सीधे सिंक करें' : 'Detect & sync mobile apps'}
                </span>
              </div>
            </div>
            <span className="rounded-lg bg-cyan-600 px-2 py-1 text-[10px] font-bold text-white">
              {isHindi ? 'स्कैन' : 'Scan'}
            </span>
          </button>
        )}

        {/* AI Custom Name Search/Input */}
        <div className="mt-3 rounded-2xl border border-slate-800 bg-slate-900/60 p-3">
          <span className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
            <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
            {isHindi ? 'किसी भी गेम का नाम डालें:' : 'Type Any Game Name:'}
          </span>
          <form onSubmit={handleGenerateCustom} className="flex gap-1.5">
            <input
              type="text"
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              placeholder={isHindi ? 'उदा. Block Blast, Candy Crush, Free Fire...' : 'e.g. Block Blast, Subway Surfers...'}
              className="flex-1 rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
            />
            <button
              type="submit"
              disabled={isGenerating || !customPrompt.trim()}
              className="flex items-center gap-1 rounded-xl bg-emerald-600 px-3 py-2 text-xs font-bold text-white hover:bg-emerald-500 disabled:opacity-50"
            >
              {isGenerating ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
              <span>{isHindi ? 'जोड़ें' : 'Add'}</span>
            </button>
          </form>
        </div>

        {/* Popular Presets */}
        <div className="mt-3">
          <span className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-slate-400">
            {isHindi ? 'लोकप्रिय गेम्स:' : 'Popular Games:'}
          </span>
          <div className="grid grid-cols-2 gap-2">
            {PRESET_TEMPLATES.map((tmpl, idx) => (
              <div
                key={idx}
                onClick={() => handleOpenSetupWizard(tmpl)}
                className="flex cursor-pointer flex-col justify-between rounded-xl border border-slate-800 bg-slate-900/70 p-2.5 hover:border-emerald-500/50 hover:bg-slate-900 active:scale-95"
              >
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                    <span>{tmpl.category === 'fruit_ninja' ? '🍉' : tmpl.category === 'block_blast' ? '🧩' : '🎮'}</span>
                    <span className="truncate">{isHindi ? tmpl.nameHindi : tmpl.name}</span>
                  </div>
                  <span className="block truncate text-[10px] text-slate-400 mt-0.5">
                    {isHindi ? tmpl.descriptionHindi : tmpl.description}
                  </span>
                </div>
                <div className="mt-2 flex items-center justify-between border-t border-slate-800/80 pt-1.5 text-[9px]">
                  <span className="text-emerald-400 font-bold">{tmpl.speed}x APM</span>
                  <span className="flex items-center gap-0.5 text-cyan-400 font-bold">
                    <Settings2 className="h-2.5 w-2.5" />
                    <span>{isHindi ? 'सेट करें' : 'Setup'}</span>
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {selectedTemplateForSetup && (
        <GameSetupModal
          isOpen={!!selectedTemplateForSetup}
          onClose={() => setSelectedTemplateForSetup(null)}
          onConfirmLaunch={(game) => {
            onAddGame(game);
            setSelectedTemplateForSetup(null);
            onClose();
          }}
          initialTemplate={selectedTemplateForSetup}
          language={language}
        />
      )}
    </div>
  );
};
