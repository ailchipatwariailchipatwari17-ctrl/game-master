import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Smartphone,
  QrCode,
  Wifi,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  Zap,
  Play,
  RotateCw,
  Cpu,
  Layers,
  Touchpad,
  BatteryCharging,
  Settings2,
  Lock,
  ArrowRight,
  Download,
  AlertCircle
} from 'lucide-react';
import { GameBotState, GameCategory } from '../types';
import { playSound } from '../utils/audio';
import { GameSetupModal } from './GameSetupModal';

interface PhoneCompanionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnectPhoneGame: (game: GameBotState) => void;
  language: 'hi' | 'en';
}

interface InstalledPhoneGame {
  id: string;
  name: string;
  nameHindi: string;
  packageName: string;
  category: GameCategory;
  description: string;
  descriptionHindi: string;
  iconBg: string;
  iconEmoji: string;
  initialScore: number;
  level: number;
  aiMode: string;
  aiModeHindi: string;
}

const POPULAR_PHONE_GAMES: InstalledPhoneGame[] = [
  {
    id: 'phone_block_blast',
    name: 'Block Blast! (Mobile App)',
    nameHindi: 'ब्लॉक ब्लास्ट (फोन में इंस्टॉल किया हुआ)',
    packageName: 'com.block.puzzle.game.blast',
    category: 'block_blast',
    description: 'AI detects board pixels, predicts best 8x8 combos, and auto-drags blocks with sub-second accuracy.',
    descriptionHindi: 'AI स्क्रीन विजन से 8x8 ग्रिड स्कैन करता है, कॉम्बो ब्लास्ट बनाता है और लगातार लेवल पार करता है।',
    iconBg: 'from-blue-600 to-indigo-700',
    iconEmoji: '🧩',
    initialScore: 14200,
    level: 12,
    aiMode: 'Neural Vision + 8x8 Solver',
    aiModeHindi: 'न्यूरल विजन + 8x8 सॉल्वर'
  },
  {
    id: 'phone_fruit_ninja',
    name: 'Fruit Ninja® Classic / 2',
    nameHindi: 'फ्रूट निंजा (मोबाइल गेम)',
    packageName: 'com.halfbrick.fruitninja',
    category: 'fruit_ninja',
    description: 'AI tracks flying fruits across screen, executes ultra-fast slice swipes, and 100% evades all bombs.',
    descriptionHindi: 'AI स्क्रीन पर उड़ते फलों को ट्रैक करके मिलीसेकंड में काटता है और 100% बम से बचता है।',
    iconBg: 'from-emerald-600 to-teal-800',
    iconEmoji: '🍉',
    initialScore: 18500,
    level: 15,
    aiMode: 'Precision Swipe + Zero-Bomb Dodge',
    aiModeHindi: 'प्रिसिजन स्वाइप + जीरो बम डोज'
  },
  {
    id: 'phone_subway_surfers',
    name: 'Subway Surfers (Mobile)',
    nameHindi: 'सबवे सर्फर्स (फोन गेम)',
    packageName: 'com.kiloo.subwaysurf',
    category: 'cyber_runner',
    description: 'AI neural lane reader performs instant jump/roll/dodge swipes to achieve infinite score runs.',
    descriptionHindi: 'AI लेन को स्कैन करके जंप, रोल और स्वाइप करता है और मिलियन का स्कोर बनाता है।',
    iconBg: 'from-amber-600 to-orange-700',
    iconEmoji: '🏃',
    initialScore: 24500,
    level: 22,
    aiMode: 'Real-time Obstacle Reflex Engine',
    aiModeHindi: 'रियल-टाइम ऑब्सटेकल रिफ्लेक्स इंजन'
  },
  {
    id: 'phone_candy_crush',
    name: 'Candy Crush Saga',
    nameHindi: 'कैंडी क्रश सागा (फोन गेम)',
    packageName: 'com.king.candycrushsaga',
    category: 'block_blast',
    description: 'AI identifies color matches, cascades special wrapped candies, and clears stages automatically.',
    descriptionHindi: 'AI 4 और 5 कैंडी के कॉम्बो पहचानकर अपने आप स्टेज और लेवल पूरे करता है।',
    iconBg: 'from-pink-600 to-rose-700',
    iconEmoji: '🍬',
    initialScore: 31000,
    level: 45,
    aiMode: 'Color Cascade Matcher',
    aiModeHindi: 'कलर कैस्केड मैचर'
  },
  {
    id: 'phone_ludo_king',
    name: 'Ludo King™ (Mobile)',
    nameHindi: 'लूडो किंग (फोन ऐप)',
    packageName: 'com.ludo.king',
    category: 'strategy',
    description: 'AI calculates highest probability token movements and safety squares to win consecutive matches.',
    descriptionHindi: 'AI हर पासे के नंबर पर सबसे सुरक्षित और आक्रामक चाल चलकर मैच जीतता है।',
    iconBg: 'from-yellow-600 to-amber-700',
    iconEmoji: '🎲',
    initialScore: 9200,
    level: 8,
    aiMode: 'Probability Strategy Engine',
    aiModeHindi: 'प्रोबेबिलिटी स्ट्रैटेजी इंजन'
  },
  {
    id: 'phone_hill_climb',
    name: 'Hill Climb Racing 2',
    nameHindi: 'हिल क्लाइम्ब रेसिंग (फोन गेम)',
    packageName: 'com.fingersoft.hillclimb',
    category: 'cyber_runner',
    description: 'AI manages gas/brake balance in mid-air, collects fuel canisters, and sets endless track records.',
    descriptionHindi: 'AI गैस और ब्रेक को बैलेंस करके गाड़ी को पलटने से बचाता है और सिक्के इकट्ठा करता है।',
    iconBg: 'from-red-600 to-rose-800',
    iconEmoji: '🏎️',
    initialScore: 16800,
    level: 18,
    aiMode: 'Physics Momentum Balancer',
    aiModeHindi: 'फिजिक्स मोमेंटम बैलेंसर'
  }
];

export const PhoneCompanionModal: React.FC<PhoneCompanionModalProps> = ({
  isOpen,
  onClose,
  onConnectPhoneGame,
  language
}) => {
  const [activeTab, setActiveTab] = useState<'scan' | 'pairing' | 'settings'>('scan');
  const [devicePaired, setDevicePaired] = useState(true);
  const [pairingCode, setPairingCode] = useState('KAIROS-8924');
  const [isScanning, setIsScanning] = useState(false);
  const [stealthMode, setStealthMode] = useState(true);
  const [screenOffFarming, setScreenOffFarming] = useState(true);
  const [autoResumeOnCall, setAutoResumeOnCall] = useState(true);
  const [autoCrossAds, setAutoCrossAds] = useState(true);
  const [blockAdDownloads, setBlockAdDownloads] = useState(true);
  const [touchSpeedApm, setTouchSpeedApm] = useState(320);
  const [selectedGameForPreview, setSelectedGameForPreview] = useState<InstalledPhoneGame>(POPULAR_PHONE_GAMES[0]);
  const [selectedGameForSetupWizard, setSelectedGameForSetupWizard] = useState<InstalledPhoneGame | null>(null);

  const phoneCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const isHindi = language === 'hi';

  // Live Phone Screen AI Simulation Canvas
  useEffect(() => {
    if (!isOpen) return;
    const canvas = phoneCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let frame = 0;

    const render = () => {
      frame++;
      const w = canvas.width;
      const h = canvas.height;

      // Phone screen background
      ctx.fillStyle = '#0a0f1d';
      ctx.fillRect(0, 0, w, h);

      // Draw Top Status Bar
      ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
      ctx.fillRect(0, 0, w, 18);
      ctx.fillStyle = '#94a3b8';
      ctx.font = '9px sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('10:45', 8, 12);
      ctx.textAlign = 'right';
      ctx.fillText('5G 🔋 98%', w - 8, 12);

      // Render Selected Game on Simulated Phone Screen
      if (selectedGameForPreview.category === 'block_blast') {
        // 8x8 Grid
        const cellSize = 16;
        const startX = (w - 8 * cellSize) / 2;
        const startY = 35;

        ctx.fillStyle = '#0f172a';
        ctx.fillRect(startX - 2, startY - 2, 8 * cellSize + 4, 8 * cellSize + 4);
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 1;
        ctx.strokeRect(startX - 2, startY - 2, 8 * cellSize + 4, 8 * cellSize + 4);

        const colors = ['#06b6d4', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899'];
        for (let r = 0; r < 8; r++) {
          for (let c = 0; c < 8; c++) {
            const x = startX + c * cellSize;
            const y = startY + r * cellSize;
            ctx.strokeStyle = '#1e293b';
            ctx.strokeRect(x, y, cellSize, cellSize);

            const isFilled = (r * 8 + c + Math.floor(frame / 30)) % 11 < 6;
            if (isFilled) {
              ctx.fillStyle = colors[(r + c) % colors.length];
              ctx.fillRect(x + 1, y + 1, cellSize - 2, cellSize - 2);
            }
          }
        }

        // AI Touch Pointer / Drag Circle
        const touchX = startX + ((Math.sin(frame * 0.08) + 1) * 3.5) * cellSize + 8;
        const touchY = startY + ((Math.cos(frame * 0.08) + 1) * 3.5) * cellSize + 8;

        ctx.fillStyle = 'rgba(56, 189, 248, 0.4)';
        ctx.beginPath();
        ctx.arc(touchX, touchY, 14, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(touchX, touchY, 8, 0, Math.PI * 2);
        ctx.stroke();

        // Combo text
        if (Math.sin(frame * 0.15) > 0.4) {
          ctx.fillStyle = '#facc15';
          ctx.font = 'bold 11px monospace';
          ctx.textAlign = 'center';
          ctx.fillText('⚡ AI COMBO x5!', w / 2, startY + 8 * cellSize + 22);
        }
      } else if (selectedGameForPreview.category === 'fruit_ninja') {
        // Flying Fruits & Katana Slices
        for (let i = 0; i < 3; i++) {
          const t = ((frame * 0.04) + i * 1.5) % Math.PI;
          const fx = 35 + i * 55;
          const fy = h - 40 - Math.sin(t) * (h - 90);

          ctx.fillStyle = i === 0 ? '#22c55e' : i === 1 ? '#f97316' : '#ef4444';
          ctx.beginPath();
          ctx.arc(fx, fy, 10, 0, Math.PI * 2);
          ctx.fill();
        }

        // Blade Slash
        const sx = 20 + ((frame * 4) % (w - 40));
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(sx - 15, h / 2 - 10);
        ctx.lineTo(sx + 25, h / 2 + 15);
        ctx.stroke();

        ctx.fillStyle = '#10b981';
        ctx.font = 'bold 10px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('🍉 0 BOMBS | 100% SLICE', w / 2, h - 35);
      } else {
        // Runner / Racer
        const ry = h / 2 + Math.sin(frame * 0.1) * 20;
        ctx.fillStyle = '#06b6d4';
        ctx.beginPath();
        ctx.arc(45, ry, 12, 0, Math.PI * 2);
        ctx.fill();

        for (let i = 0; i < 3; i++) {
          const ox = (w - ((frame * 2.5 + i * 60) % w));
          ctx.fillStyle = '#f43f5e';
          ctx.fillRect(ox, h / 2 - 10 + (i % 2 === 0 ? 15 : -15), 10, 20);
        }

        ctx.fillStyle = '#10b981';
        ctx.font = 'bold 10px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('🏃 AI AUTO-SURFING', w / 2, h - 35);
      }

      // Ad Overlay Simulation & Auto-Cross Interception (every ~5 seconds)
      const adCycle = frame % 220;
      if (adCycle > 140 && adCycle < 210) {
        // Dim background
        ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
        ctx.fillRect(0, 18, w, h - 40);

        // Simulated Ad Popup Card
        ctx.fillStyle = '#1e1b4b';
        ctx.fillRect(15, 45, w - 30, h - 95);
        ctx.strokeStyle = '#6366f1';
        ctx.lineWidth = 1;
        ctx.strokeRect(15, 45, w - 30, h - 95);

        ctx.fillStyle = '#e0e7ff';
        ctx.font = 'bold 10px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('POPUP ADVERTISEMENT', w / 2, 70);

        // Deceptive Install Button (Highlighted in Red forbidden box)
        ctx.fillStyle = 'rgba(239, 68, 68, 0.2)';
        ctx.fillRect(30, 95, w - 60, 24);
        ctx.strokeStyle = '#ef4444';
        ctx.strokeRect(30, 95, w - 60, 24);
        ctx.fillStyle = '#fca5a5';
        ctx.font = '9px sans-serif';
        ctx.fillText('🚫 DOWNLOAD APP (BLOCKED)', w / 2, 110);

        // True Cross Button [✕] at Top Right
        const crossX = w - 35;
        const crossY = 58;
        ctx.fillStyle = '#22c55e';
        ctx.beginPath();
        ctx.arc(crossX, crossY, 9, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#052e16';
        ctx.font = 'bold 10px sans-serif';
        ctx.fillText('✕', crossX, crossY + 3.5);

        // AI Target Reticle snapping onto [✕]
        ctx.strokeStyle = '#4ade80';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(crossX, crossY, 14 + Math.sin(frame * 0.2) * 3, 0, Math.PI * 2);
        ctx.stroke();

        // Banner
        ctx.fillStyle = '#15803d';
        ctx.fillRect(10, h - 48, w - 20, 18);
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 8px monospace';
        ctx.fillText('🛡️ AI AUTO-CROSS: ONLY [✕] TAPPED', w / 2, h - 36);
      }

      // AI Active Banner at bottom of phone screen
      ctx.fillStyle = 'rgba(16, 185, 129, 0.9)';
      ctx.fillRect(0, h - 22, w, 22);
      ctx.fillStyle = '#022c22';
      ctx.font = 'bold 9px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('🤖 AI AUTO-TOUCH ACTIVE (STEALTH 320 APM)', w / 2, h - 8);

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [isOpen, selectedGameForPreview]);

  if (!isOpen) return null;

  const handleScanPhone = () => {
    setIsScanning(true);
    playSound('ai_command');
    setTimeout(() => {
      setIsScanning(false);
      playSound('levelup');
    }, 1200);
  };

  const handleConnectGameToHub = (g: InstalledPhoneGame) => {
    playSound('levelup');
    const newBot: GameBotState = {
      id: `phone_bot_${g.id}_${Date.now()}`,
      name: `${g.name} [Phone Sync]`,
      nameHindi: `${g.nameHindi} [मोबाइल सिंक]`,
      category: g.category,
      description: `${g.description} (Connected via Mobile Screen AI Accessibility Service)`,
      descriptionHindi: `${g.descriptionHindi} (मोबाइल स्क्रीन ऑटोमेशन द्वारा कनेक्टेड)`,
      status: 'active',
      level: g.level,
      exp: 0,
      maxExp: 1000,
      score: g.initialScore,
      highScore: g.initialScore,
      coins: 4500,
      crystals: 50,
      bossesDefeated: 1,
      bossName: `${g.name} Master Boss`,
      currentBossHealth: 2500,
      maxBossHealth: 2500,
      actionsPerMinute: touchSpeedApm,
      speedMultiplier: 3,
      strategy: 'aggressive_xp',
      customDirectives: [
        'Phone Screen Touch Automation Active',
        'Anti-ban Randomized Human Coordinates Enabled',
        'Auto-Resume on Screen Wakeup'
      ],
      uptimeSeconds: 0,
      targetDurationHours: null,
      remainingSeconds: null,
      autoUpgrade: true,
      botConfidence: 99,
      autoCrossAds: autoCrossAds,
      blockAdDownloads: blockAdDownloads,
      adDismissStats: {
        adsDismissed: 0,
        downloadsBlocked: 0,
        fakeCrossesFiltered: 0
      },
      skills: {
        strength: 15,
        agility: 18,
        intelligence: 20,
        vitality: 15
      },
      inventory: [
        {
          id: `phone_perk_${Date.now()}`,
          name: 'Mobile Touch Optimizer Core',
          rarity: 'legendary',
          bonus: '+50% Tap Precision & No-Ban Guarantee'
        }
      ],
      lastTickTime: Date.now(),
      simulationParams: {
        heroX: 120,
        heroY: 100,
        monstersCount: 4,
        multiplier: 2.0,
        currentWave: g.level,
        blocksCleared: g.category === 'block_blast' ? 120 : undefined,
        fruitsSliced: g.category === 'fruit_ninja' ? 180 : undefined
      }
    };

    onConnectPhoneGame(newBot);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-md">
      <div className="relative max-h-[95vh] w-full max-w-5xl overflow-y-auto rounded-3xl border border-emerald-500/40 bg-slate-950 p-6 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-cyan-600 text-white shadow-lg shadow-emerald-500/20">
              <Smartphone className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white sm:text-xl">
                  {isHindi
                    ? '📱 फोन पर डाउनलोड किए गए गेम्स कनेक्ट करें'
                    : '📱 Connect Downloaded Phone Games (Mobile Companion)'}
                </h2>
                <span className="flex items-center gap-1 rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-xs font-bold text-emerald-400">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  {devicePaired ? (isHindi ? 'फोन लिंक्ड' : 'Device Paired') : (isHindi ? 'पेयरिंग रेडी' : 'Ready')}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {isHindi
                  ? 'AI आपके मोबाइल फोन में इंस्टॉल गेम्स (Block Blast, Fruit Ninja आदि) की स्क्रीन पढ़कर अपने आप लेवल अप करेगा।'
                  : 'AI reads mobile phone game screen to auto-touch, clear stages, and level up 24/7.'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-xl border border-slate-700 bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="mt-4 flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
          <button
            onClick={() => {
              playSound('click');
              setActiveTab('scan');
            }}
            className={`flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-bold transition-all ${
              activeTab === 'scan'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="h-4 w-4" />
            <span>{isHindi ? '1. फोन में इंस्टॉल गेम्स (Installed Games)' : '1. Installed Phone Games'}</span>
          </button>

          <button
            onClick={() => {
              playSound('click');
              setActiveTab('pairing');
            }}
            className={`flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-bold transition-all ${
              activeTab === 'pairing'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <QrCode className="h-4 w-4" />
            <span>{isHindi ? '2. फोन पेयरिंग व QR कोड' : '2. Phone Pairing & QR Link'}</span>
          </button>

          <button
            onClick={() => {
              playSound('click');
              setActiveTab('settings');
            }}
            className={`flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-bold transition-all ${
              activeTab === 'settings'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <Settings2 className="h-4 w-4" />
            <span>{isHindi ? '3. एंटी-बैन व स्क्रीन सेटिंग्स' : '3. Anti-Ban & Auto-Touch Settings'}</span>
          </button>
        </div>

        {/* TAB 1: INSTALLED PHONE GAMES SCANNER */}
        {activeTab === 'scan' && (
          <div className="mt-4 grid grid-cols-1 gap-6 lg:grid-cols-12">
            {/* Left: Games List */}
            <div className="space-y-4 lg:col-span-7">
              <div className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900 p-3">
                <div className="flex items-center gap-2">
                  <Smartphone className="h-4 w-4 text-emerald-400" />
                  <span className="text-xs font-bold text-white">
                    {isHindi ? 'डिटेक्टेड डिवाइस:' : 'Connected Device:'}{' '}
                    <span className="text-emerald-400">Android / iOS (Auto-Sync Active)</span>
                  </span>
                </div>
                <button
                  onClick={handleScanPhone}
                  disabled={isScanning}
                  className="flex items-center gap-1 rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:bg-slate-700 active:scale-95"
                >
                  <RotateCw className={`h-3.5 w-3.5 text-cyan-400 ${isScanning ? 'animate-spin' : ''}`} />
                  <span>{isScanning ? (isHindi ? 'स्कैन हो रहा है...' : 'Scanning...') : (isHindi ? 'दोबारा स्कैन करें' : 'Rescan Phone')}</span>
                </button>
              </div>

              <div className="space-y-2.5">
                {POPULAR_PHONE_GAMES.map((game) => {
                  const isSelected = selectedGameForPreview.id === game.id;
                  return (
                    <div
                      key={game.id}
                      onClick={() => {
                        playSound('click');
                        setSelectedGameForPreview(game);
                      }}
                      className={`group cursor-pointer rounded-2xl border p-3.5 transition-all ${
                        isSelected
                          ? 'border-emerald-500 bg-slate-900/90 shadow-lg shadow-emerald-950/30'
                          : 'border-slate-800/80 bg-slate-900/40 hover:border-slate-700 hover:bg-slate-900/70'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-3">
                          <div
                            className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${game.iconBg} text-xl shadow-md`}
                          >
                            {game.iconEmoji}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-sm font-bold text-white group-hover:text-emerald-300">
                                {isHindi ? game.nameHindi : game.name}
                              </h4>
                              <span className="rounded bg-emerald-500/10 px-1.5 py-0.5 text-[10px] font-bold text-emerald-400">
                                Lv. {game.level}
                              </span>
                            </div>
                            <p className="mt-0.5 text-xs text-slate-400 line-clamp-1">
                              {isHindi ? game.descriptionHindi : game.description}
                            </p>
                            <div className="mt-1 flex items-center gap-2 text-[10px] text-cyan-400 font-mono">
                              <span>🤖 {isHindi ? game.aiModeHindi : game.aiMode}</span>
                              <span>• {game.packageName}</span>
                            </div>
                          </div>
                        </div>

                        {/* Connect Button */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            playSound('click');
                            setSelectedGameForSetupWizard(game);
                          }}
                          className="flex shrink-0 items-center gap-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 px-3 py-2 text-xs font-bold text-white shadow-md shadow-emerald-950 hover:from-emerald-500 hover:to-teal-500 active:scale-95"
                        >
                          <Settings2 className="h-3.5 w-3.5" />
                          <span>{isHindi ? 'मोड व सेटिंग्स' : 'Set Mode & Play'}</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Right: Phone Live Mockup & Real-time AI Vision Preview */}
            <div className="flex flex-col items-center justify-center rounded-2xl border border-slate-800 bg-slate-900/60 p-4 lg:col-span-5">
              <div className="mb-2 text-center">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  {isHindi ? 'फोन स्क्रीन लाइव AI टच प्रीव्यू' : 'Live Mobile AI Touch Telemetry'}
                </span>
                <p className="text-[11px] text-slate-500">
                  {isHindi
                    ? 'AI आपकी मोबाइल स्क्रीन पर टच और स्वाइप करके गेम खेलता है।'
                    : 'Real-time simulated smartphone neural touch controller'}
                </p>
              </div>

              {/* Realistic Mobile Frame */}
              <div className="relative mx-auto w-60 rounded-[32px] border-[6px] border-slate-700 bg-black p-1 shadow-2xl shadow-emerald-950/40">
                {/* Camera punch hole */}
                <div className="absolute left-1/2 top-3 z-10 h-3 w-3 -translate-x-1/2 rounded-full bg-black border border-slate-800" />

                {/* Simulated Screen */}
                <div className="overflow-hidden rounded-[24px] bg-slate-950">
                  <canvas ref={phoneCanvasRef} width={224} height={340} className="h-[340px] w-full" />
                </div>
              </div>

              <div className="mt-3 w-full space-y-2 text-center">
                <button
                  onClick={() => {
                    playSound('click');
                    setSelectedGameForSetupWizard(selectedGameForPreview);
                  }}
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 py-2.5 text-xs font-bold text-slate-950 shadow-lg shadow-emerald-500/20 hover:brightness-110 active:scale-95"
                >
                  <Play className="h-4 w-4 fill-current" />
                  <span>
                    {isHindi
                      ? `"${selectedGameForPreview.nameHindi}" का मोड व ऑटोप्ले सेट करें`
                      : `Configure Mode & Launch ${selectedGameForPreview.name}`}
                  </span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PAIRING & QR LINK */}
        {activeTab === 'pairing' && (
          <div className="mt-5 grid grid-cols-1 gap-6 md:grid-cols-2">
            <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5">
              <h3 className="flex items-center gap-2 text-sm font-bold text-white">
                <QrCode className="h-5 w-5 text-emerald-400" />
                <span>{isHindi ? 'विधि 1: फोन से QR कोड स्कैन करें' : 'Method 1: Scan QR Code with Phone'}</span>
              </h3>
              <p className="mt-1 text-xs text-slate-400">
                {isHindi
                  ? 'अपने स्मार्टफोन के कैमरे से इस QR कोड को स्कैन करें ताकि AI कंपेनियन आपके फोन से जुड़ सके।'
                  : 'Open camera on your Android / iOS phone to link AI Companion.'}
              </p>

              {/* QR Code Mockup */}
              <div className="mt-4 flex flex-col items-center justify-center rounded-2xl border border-slate-800 bg-white p-6 text-slate-950">
                <div className="grid grid-cols-6 gap-1 bg-white p-2">
                  {Array.from({ length: 36 }).map((_, i) => (
                    <div
                      key={i}
                      className={`h-4 w-4 rounded-sm ${
                        (i % 2 === 0 || i % 7 === 0 || i < 6 || i > 30) ? 'bg-slate-950' : 'bg-slate-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="mt-2 font-mono text-xs font-bold text-slate-800">
                  {pairingCode}
                </span>
              </div>

              <div className="mt-3 text-center text-xs text-emerald-400 font-semibold">
                ✓ {isHindi ? 'डिवाइस ऑटो-सिंक्रोनाइज़ेशन तैयार है' : 'Device Auto-Synchronization Ready'}
              </div>
            </div>

            <div className="space-y-4 rounded-2xl border border-slate-800 bg-slate-900/80 p-5">
              <h3 className="flex items-center gap-2 text-sm font-bold text-white">
                <Wifi className="h-5 w-5 text-cyan-400" />
                <span>{isHindi ? 'विधि 2: वायरलेस Wi-Fi / ADB पेयरिंग' : 'Method 2: Wi-Fi / ADB Pairing Code'}</span>
              </h3>
              <p className="text-xs text-slate-400">
                {isHindi
                  ? 'यदि आप बिना किसी केबल के खेलना चाहते हैं, तो वायरलेस डिबगिंग कोड का उपयोग करें:'
                  : 'Connect wirelessly via Local Wi-Fi without needing a USB cable:'}
              </p>

              <div className="rounded-xl border border-slate-700 bg-slate-950 p-4">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  {isHindi ? 'डिवाइस पेयरिंग कोड (PIN):' : 'Device Pairing PIN:'}
                </label>
                <div className="mt-1 flex items-center justify-between">
                  <span className="font-mono text-xl font-bold tracking-widest text-cyan-400">{pairingCode}</span>
                  <button
                    onClick={() => {
                      setPairingCode(`KAIROS-${Math.floor(1000 + Math.random() * 9000)}`);
                      playSound('click');
                    }}
                    className="rounded-lg bg-slate-800 px-3 py-1.5 text-xs text-slate-300 hover:bg-slate-700"
                  >
                    {isHindi ? 'नया कोड जनरेट करें' : 'Refresh PIN'}
                  </button>
                </div>
              </div>

              <div className="space-y-2 text-xs text-slate-300">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{isHindi ? '1. फोन में "Accessibility Service" ऑन करें।' : '1. Enable Accessibility AI Service on Phone.'}</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{isHindi ? '2. फोन की स्क्रीन पर ओवरले परमिशन दें।' : '2. Grant Screen Overlay permission.'}</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{isHindi ? '3. गेम खोलें, AI तुरंत खेलना शुरू कर देगा!' : '3. Launch game, AI begins auto-play immediately!'}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: ANTI-BAN & TOUCH SETTINGS */}
        {activeTab === 'settings' && (
          <div className="mt-5 space-y-4">
            <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5">
              <h3 className="mb-4 text-sm font-bold text-white flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-emerald-400" />
                <span>{isHindi ? 'एंटी-बैन सुरक्षा व स्टेल्थ मोड' : 'Anti-Ban Protection & Stealth Mode'}</span>
              </h3>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                {/* Stealth Tapping */}
                <div className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-950 p-3.5">
                  <div>
                    <span className="font-bold text-white text-xs block">
                      {isHindi ? 'मानव जैसा स्टेल्थ टच (Human-like Randomization)' : 'Human-like Touch Jitter'}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {isHindi ? 'टैप लोकेशन में सूक्ष्म बदलाव जिससे कभी बैन न लगे।' : 'Adds natural micro-delays to evade bot detection.'}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      playSound('click');
                      setStealthMode(!stealthMode);
                    }}
                    className={`h-6 w-11 rounded-full transition-colors relative ${
                      stealthMode ? 'bg-emerald-600' : 'bg-slate-700'
                    }`}
                  >
                    <span
                      className={`absolute top-1 h-4 w-4 rounded-full bg-white transition-transform ${
                        stealthMode ? 'left-6' : 'left-1'
                      }`}
                    />
                  </button>
                </div>

                {/* Screen-off farming */}
                <div className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-950 p-3.5">
                  <div>
                    <span className="font-bold text-white text-xs block">
                      {isHindi ? 'स्क्रीन ऑफ / बैकग्राउंड फार्मिंग' : 'Screen-Off Battery Saver Farming'}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {isHindi ? 'फोन की स्क्रीन बंद होने पर भी AI गेम खेलता रहेगा।' : 'Keeps bot farming even when phone display is off.'}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      playSound('click');
                      setScreenOffFarming(!screenOffFarming);
                    }}
                    className={`h-6 w-11 rounded-full transition-colors relative ${
                      screenOffFarming ? 'bg-emerald-600' : 'bg-slate-700'
                    }`}
                  >
                    <span
                      className={`absolute top-1 h-4 w-4 rounded-full bg-white transition-transform ${
                        screenOffFarming ? 'left-6' : 'left-1'
                      }`}
                    />
                  </button>
                </div>

                {/* Auto Resume on call */}
                <div className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-950 p-3.5">
                  <div>
                    <span className="font-bold text-white text-xs block">
                      {isHindi ? 'फोन कॉल आने पर ऑटो-पॉज' : 'Auto-Pause on Phone Call'}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {isHindi ? 'कॉल खत्म होते ही गेम अपने आप फिर चालू हो जाएगा।' : 'Safely pauses on incoming calls and resumes afterwards.'}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      playSound('click');
                      setAutoResumeOnCall(!autoResumeOnCall);
                    }}
                    className={`h-6 w-11 rounded-full transition-colors relative ${
                      autoResumeOnCall ? 'bg-emerald-600' : 'bg-slate-700'
                    }`}
                  >
                    <span
                      className={`absolute top-1 h-4 w-4 rounded-full bg-white transition-transform ${
                        autoResumeOnCall ? 'left-6' : 'left-1'
                      }`}
                    />
                  </button>
                </div>

                {/* Auto Cross Ads */}
                <div className="flex items-center justify-between rounded-xl border border-rose-900/40 bg-rose-950/20 p-3.5">
                  <div>
                    <span className="font-bold text-rose-300 text-xs flex items-center gap-1">
                      <span>🛡️</span>
                      {isHindi ? 'ऐड पर केवल "✕" (Cross) दबाएं' : 'Always Tap [✕] on Ads'}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {isHindi ? 'विज्ञापन आने पर AI केवल क्रॉस दबाकर बंद करेगा।' : 'AI accurately snaps to top [✕] button to dismiss ad.'}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      playSound('click');
                      setAutoCrossAds(!autoCrossAds);
                    }}
                    className={`h-6 w-11 rounded-full transition-colors relative ${
                      autoCrossAds ? 'bg-rose-600' : 'bg-slate-700'
                    }`}
                  >
                    <span
                      className={`absolute top-1 h-4 w-4 rounded-full bg-white transition-transform ${
                        autoCrossAds ? 'left-6' : 'left-1'
                      }`}
                    />
                  </button>
                </div>

                {/* Block Ad Downloads */}
                <div className="flex items-center justify-between rounded-xl border border-emerald-900/40 bg-emerald-950/20 p-3.5">
                  <div>
                    <span className="font-bold text-emerald-300 text-xs flex items-center gap-1">
                      <span>🚫</span>
                      {isHindi ? 'जीरो ऐप डाउनलोड शील्ड (0-Click)' : 'Zero-Download Shield'}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {isHindi ? 'किसी भी ऐप डाउनलोड या प्ले स्टोर लिंक पर क्लिक नहीं होगा।' : 'Completely prevents clicking install links or app stores.'}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      playSound('click');
                      setBlockAdDownloads(!blockAdDownloads);
                    }}
                    className={`h-6 w-11 rounded-full transition-colors relative ${
                      blockAdDownloads ? 'bg-emerald-600' : 'bg-slate-700'
                    }`}
                  >
                    <span
                      className={`absolute top-1 h-4 w-4 rounded-full bg-white transition-transform ${
                        blockAdDownloads ? 'left-6' : 'left-1'
                      }`}
                    />
                  </button>
                </div>

                {/* APM Touch Speed */}
                <div className="rounded-xl border border-slate-800 bg-slate-950 p-3.5">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-bold text-white text-xs">
                      {isHindi ? 'AI टच स्पीड (APM):' : 'AI Touch Speed (APM):'}
                    </span>
                    <span className="font-mono text-xs font-bold text-cyan-400">{touchSpeedApm} APM</span>
                  </div>
                  <input
                    type="range"
                    min="120"
                    max="600"
                    step="20"
                    value={touchSpeedApm}
                    onChange={(e) => setTouchSpeedApm(parseInt(e.target.value))}
                    className="w-full accent-emerald-500"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                    <span>120 (Safe)</span>
                    <span>320 (Optimal)</span>
                    <span>600 (Lightning)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Game Setup Modal for Selected Phone Game */}
      {selectedGameForSetupWizard && (
        <GameSetupModal
          isOpen={!!selectedGameForSetupWizard}
          onClose={() => setSelectedGameForSetupWizard(null)}
          onConfirmLaunch={(game) => {
            onConnectPhoneGame(game);
            setSelectedGameForSetupWizard(null);
            onClose();
          }}
          initialTemplate={{
            name: `${selectedGameForSetupWizard.name} [Phone App]`,
            nameHindi: `${selectedGameForSetupWizard.nameHindi} [फोन ऐप सिंक]`,
            category: selectedGameForSetupWizard.category,
            description: selectedGameForSetupWizard.description,
            descriptionHindi: selectedGameForSetupWizard.descriptionHindi,
            packageName: selectedGameForSetupWizard.packageName,
            bossName: `${selectedGameForSetupWizard.name} Master Boss`,
            initialScore: selectedGameForSetupWizard.initialScore,
            speed: 3
          }}
          language={language}
        />
      )}
    </div>
  );
};
