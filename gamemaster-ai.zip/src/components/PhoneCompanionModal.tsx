import React, { useState, useEffect } from 'react';
import {
  X,
  Smartphone,
  QrCode,
  Wifi,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  Zap,
  Play,
  RotateCw,
  Search,
  Plus,
  Trash2,
  Layers,
  BatteryCharging,
  Settings2,
  Check,
  AlertCircle
} from 'lucide-react';
import { GameBotState, GameCategory } from '../types';
import { playSound } from '../utils/audio';
import { GameSetupModal } from './GameSetupModal';

interface PhoneCompanionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnectPhoneGame: (game: GameBotState) => void;
  language: 'hi' | 'en';
}

export interface CatalogGame {
  id: string;
  name: string;
  nameHindi: string;
  packageName: string;
  category: GameCategory;
  tag: string;
  tagHindi: string;
  iconBg: string;
  iconEmoji: string;
  initialScore: number;
  level: number;
}

const CATALOG_GAMES: CatalogGame[] = [
  {
    id: 'phone_block_blast',
    name: 'Block Blast!',
    nameHindi: 'ब्लॉक ब्लास्ट (Block Blast)',
    packageName: 'com.block.puzzle.game.blast',
    category: 'block_blast',
    tag: '8x8 Solver',
    tagHindi: '8x8 कॉम्बो',
    iconBg: 'from-blue-600 to-indigo-700',
    iconEmoji: '🧩',
    initialScore: 8400,
    level: 1
  },
  {
    id: 'phone_fruit_ninja',
    name: 'Fruit Ninja',
    nameHindi: 'फ्रूट निंजा (Fruit Ninja)',
    packageName: 'com.halfbrick.fruitninja',
    category: 'fruit_ninja',
    tag: 'Fast Slice',
    tagHindi: 'स्लाइस + डोज',
    iconBg: 'from-emerald-600 to-teal-800',
    iconEmoji: '🍉',
    initialScore: 9200,
    level: 1
  },
  {
    id: 'phone_subway_surfers',
    name: 'Subway Surfers',
    nameHindi: 'सबवे सर्फर्स (Subway Surfers)',
    packageName: 'com.kiloo.subwaysurf',
    category: 'cyber_runner',
    tag: 'Reflex Jump',
    tagHindi: 'रिफ्लेक्स स्वाइप',
    iconBg: 'from-amber-600 to-orange-700',
    iconEmoji: '🏃',
    initialScore: 12000,
    level: 1
  },
  {
    id: 'phone_candy_crush',
    name: 'Candy Crush Saga',
    nameHindi: 'कैंडी क्रश (Candy Crush)',
    packageName: 'com.king.candycrushsaga',
    category: 'block_blast',
    tag: 'Cascade Match',
    tagHindi: 'कलर कैस्केड',
    iconBg: 'from-pink-600 to-rose-700',
    iconEmoji: '🍬',
    initialScore: 6500,
    level: 1
  },
  {
    id: 'phone_ludo_king',
    name: 'Ludo King',
    nameHindi: 'लूडो किंग (Ludo King)',
    packageName: 'com.ludo.king',
    category: 'combat',
    tag: 'Probability AI',
    tagHindi: 'स्मार्ट चाल',
    iconBg: 'from-yellow-600 to-amber-700',
    iconEmoji: '🎲',
    initialScore: 4500,
    level: 1
  },
  {
    id: 'phone_hill_climb',
    name: 'Hill Climb Racing',
    nameHindi: 'हिल क्लाइम्ब (Hill Climb)',
    packageName: 'com.fingersoft.hillclimb',
    category: 'cyber_runner',
    tag: 'Physics Balance',
    tagHindi: 'गैस/ब्रेक बैलेंस',
    iconBg: 'from-red-600 to-rose-800',
    iconEmoji: '🏎️',
    initialScore: 7800,
    level: 1
  },
  {
    id: 'phone_free_fire',
    name: 'Free Fire / Action',
    nameHindi: 'फ्री फायर / एक्शन गेम',
    packageName: 'com.dts.freefireth',
    category: 'combat',
    tag: 'Reflex Aim',
    tagHindi: 'ऑटो-एम',
    iconBg: 'from-purple-600 to-indigo-800',
    iconEmoji: '🔥',
    initialScore: 5000,
    level: 1
  },
  {
    id: 'phone_bgmi',
    name: 'BGMI / Battle Royale',
    nameHindi: 'BGMI / बैटल रॉयल',
    packageName: 'com.pubg.imobile',
    category: 'combat',
    tag: 'Survival AI',
    tagHindi: 'सर्वाइवल',
    iconBg: 'from-slate-700 to-slate-900',
    iconEmoji: '🎯',
    initialScore: 6200,
    level: 1
  }
];

export const PhoneCompanionModal: React.FC<PhoneCompanionModalProps> = ({
  isOpen,
  onClose,
  onConnectPhoneGame,
  language
}) => {
  const isHindi = language === 'hi';
  const [isScanning, setIsScanning] = useState(false);
  const [deviceInfo, setDeviceInfo] = useState<{
    os: string;
    screen: string;
    touch: boolean;
    battery: string;
    network: string;
  }>({
    os: 'Android 14',
    screen: '1080x2400 (120Hz)',
    touch: true,
    battery: '94%',
    network: '5G / Wi-Fi'
  });

  // State to store verified installed games selected or entered by user
  const [verifiedInstalledGames, setVerifiedInstalledGames] = useState<CatalogGame[]>(() => {
    try {
      const saved = localStorage.getItem('autoplay_verified_phone_games_v4');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [customGameName, setCustomGameName] = useState('');
  const [selectedGameForSetup, setSelectedGameForSetup] = useState<CatalogGame | null>(null);
  const [activeTab, setActiveTab] = useState<'scanner' | 'pairing'>('scanner');
  const [pairingCode] = useState('KAIROS-9941');

  // Real hardware device detection on open
  useEffect(() => {
    if (!isOpen) return;

    const ua = navigator.userAgent;
    let detectedOs = 'Android';
    if (/iPhone|iPad|iPod/i.test(ua)) detectedOs = 'iOS (Apple)';
    else if (/Android/i.test(ua)) detectedOs = 'Android OS';
    else if (/Windows/i.test(ua)) detectedOs = 'Windows Mobile/PC';
    else detectedOs = 'Mobile Device';

    const screenRes = `${window.screen.width}x${window.screen.height}`;
    const touchSupported = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    const connectionType = (navigator as any).connection?.effectiveType || '4G/5G';

    setDeviceInfo({
      os: detectedOs,
      screen: `${screenRes}`,
      touch: touchSupported,
      battery: '95%',
      network: `${connectionType.toUpperCase()} Online`
    });

    // Try Battery API
    if ('getBattery' in navigator) {
      (navigator as any).getBattery().then((batt: any) => {
        setDeviceInfo((prev) => ({
          ...prev,
          battery: `${Math.round(batt.level * 100)}%`
        }));
      }).catch(() => {});
    }
  }, [isOpen]);

  // Save verified list
  const saveVerifiedGames = (newList: CatalogGame[]) => {
    setVerifiedInstalledGames(newList);
    try {
      localStorage.setItem('autoplay_verified_phone_games_v4', JSON.stringify(newList));
    } catch (err) {
      console.error(err);
    }
  };

  const handleToggleInstall = (game: CatalogGame) => {
    playSound('click');
    const exists = verifiedInstalledGames.some((g) => g.id === game.id);
    let updated: CatalogGame[];
    if (exists) {
      updated = verifiedInstalledGames.filter((g) => g.id !== game.id);
    } else {
      updated = [...verifiedInstalledGames, game];
    }
    saveVerifiedGames(updated);
  };

  const handleScanDevice = () => {
    setIsScanning(true);
    playSound('ai_command');
    setTimeout(() => {
      setIsScanning(false);
      playSound('levelup');
    }, 900);
  };

  const handleAddCustomGame = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customGameName.trim()) return;
    playSound('levelup');
    const newG: CatalogGame = {
      id: `custom_${Date.now()}`,
      name: customGameName,
      nameHindi: customGameName,
      packageName: `com.${customGameName.toLowerCase().replace(/[^a-z0-9]/g, '')}.app`,
      category: 'block_blast',
      tag: 'Custom Phone Game',
      tagHindi: 'कस्टम फोन ऐप',
      iconBg: 'from-cyan-600 to-blue-800',
      iconEmoji: '📱',
      initialScore: 5000,
      level: 1
    };
    saveVerifiedGames([...verifiedInstalledGames, newG]);
    setCustomGameName('');
  };

  const handleConnectGameToHub = (g: CatalogGame) => {
    playSound('levelup');
    const newBot: GameBotState = {
      id: `phone_bot_${g.id}_${Date.now()}`,
      name: g.name,
      nameHindi: g.nameHindi,
      category: g.category,
      description: `Phone Game: ${g.name} (${g.packageName})`,
      descriptionHindi: `फोन ऐप: ${g.nameHindi} (मोबाइल सिंक)`,
      status: 'active',
      level: 1,
      exp: 0,
      maxExp: 1000,
      score: g.initialScore,
      highScore: g.initialScore,
      coins: 3000,
      crystals: 30,
      bossesDefeated: 0,
      bossName: `${g.name} Boss`,
      currentBossHealth: 2000,
      maxBossHealth: 2000,
      actionsPerMinute: 320,
      speedMultiplier: 2,
      strategy: 'aggressive_xp',
      customDirectives: ['Anti-ban Human-like Touch Profile Active', 'Auto-skip ads with [X] only'],
      uptimeSeconds: 0,
      targetDurationHours: null,
      remainingSeconds: null,
      autoUpgrade: true,
      botConfidence: 99,
      autoCrossAds: true,
      blockAdDownloads: true,
      adDismissStats: { adsDismissed: 0, downloadsBlocked: 0, fakeCrossesFiltered: 0 },
      playModeGoal: 'level_up',
      touchProfile: 'human_like',
      batterySavingMode: 'ultra_saver',
      executionTarget: 'phone_installed_app',
      phonePackageName: g.packageName,
      skills: { strength: 12, agility: 18, intelligence: 20, vitality: 14 },
      inventory: [{ id: `item_${Date.now()}`, name: 'Mobile Optimizer Chip', rarity: 'rare', bonus: '+25% APM' }],
      lastTickTime: Date.now(),
      simulationParams: { heroX: 140, heroY: 100, monstersCount: 0, multiplier: 2.0, currentWave: 1 }
    };

    onConnectPhoneGame(newBot);
    onClose();
  };

  if (!isOpen) return null;

  const filteredCatalog = CATALOG_GAMES.filter((g) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return g.name.toLowerCase().includes(q) || g.nameHindi.toLowerCase().includes(q) || g.packageName.toLowerCase().includes(q);
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3 backdrop-blur-md">
      <div className="relative flex max-h-[92vh] w-full max-w-md flex-col overflow-hidden rounded-3xl border border-cyan-500/30 bg-slate-950 text-slate-100 shadow-2xl">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-slate-900/90 px-4 py-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-cyan-500/20 text-cyan-400">
              <Smartphone className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                {isHindi ? '📱 मोबाइल गेम स्कैनर' : '📱 Phone Game Scanner'}
              </h3>
              <p className="text-[11px] text-slate-400">
                {isHindi ? 'सटीक डिवाइस डिटेक्शन' : 'Real Hardware & App Link'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Real Device Hardware Status Bar */}
        <div className="grid grid-cols-3 gap-2 border-b border-slate-800/80 bg-slate-900/50 p-2.5 text-center text-[10px]">
          <div className="rounded-lg bg-slate-800/60 p-1.5">
            <span className="block text-slate-400">OS</span>
            <span className="font-bold text-emerald-400">{deviceInfo.os}</span>
          </div>
          <div className="rounded-lg bg-slate-800/60 p-1.5">
            <span className="block text-slate-400">Battery / Net</span>
            <span className="font-bold text-cyan-400">{deviceInfo.battery} • 5G</span>
          </div>
          <div className="rounded-lg bg-slate-800/60 p-1.5">
            <span className="block text-slate-400">Verified Games</span>
            <span className="font-bold text-amber-400">{verifiedInstalledGames.length} Found</span>
          </div>
        </div>

        {/* Scan Actions & Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-900/30 p-2 gap-2">
          <button
            onClick={() => setActiveTab('scanner')}
            className={`flex flex-1 items-center justify-center gap-1.5 rounded-xl py-2 text-xs font-bold transition-all ${
              activeTab === 'scanner' ? 'bg-cyan-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="h-3.5 w-3.5" />
            <span>{isHindi ? 'गेम स्कैन व चुनें' : 'Scan & Select Games'}</span>
          </button>
          <button
            onClick={() => setActiveTab('pairing')}
            className={`flex flex-1 items-center justify-center gap-1.5 rounded-xl py-2 text-xs font-bold transition-all ${
              activeTab === 'pairing' ? 'bg-cyan-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            <QrCode className="h-3.5 w-3.5" />
            <span>{isHindi ? 'QR पेयरिंग' : 'QR Link'}</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          {activeTab === 'scanner' ? (
            <>
              {/* Scan Trigger Button */}
              <div className="flex items-center justify-between gap-2 rounded-2xl border border-slate-800 bg-slate-900/80 p-3">
                <div className="flex items-center gap-2">
                  <RotateCw className={`h-4 w-4 text-cyan-400 ${isScanning ? 'animate-spin' : ''}`} />
                  <div>
                    <span className="block text-xs font-bold text-white">
                      {isHindi ? 'डिवाइस स्कैन स्थिति' : 'Device Scan Status'}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {isScanning
                        ? (isHindi ? 'डिवाइस स्कैन हो रहा है...' : 'Scanning device...')
                        : `${verifiedInstalledGames.length} ${isHindi ? 'गेम्स सत्यापित' : 'games verified on phone'}`}
                    </span>
                  </div>
                </div>
                <button
                  onClick={handleScanDevice}
                  disabled={isScanning}
                  className="rounded-xl bg-cyan-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-cyan-500 active:scale-95 shadow-md"
                >
                  {isScanning ? (isHindi ? 'स्कैनिंग...' : 'Scanning...') : (isHindi ? 'स्कैन करें' : 'Scan')}
                </button>
              </div>

              {/* SECTION: 1. Verified Installed Games (Honest list) */}
              <div>
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    {isHindi ? 'फोन पर उपलब्ध गेम्स' : 'Installed Phone Games'} ({verifiedInstalledGames.length})
                  </span>
                </div>

                {verifiedInstalledGames.length === 0 ? (
                  <div className="rounded-2xl border border-dashed border-slate-800 p-4 text-center">
                    <p className="text-xs text-slate-400">
                      {isHindi
                        ? 'कोई गेम अभी चिह्नित नहीं है। नीचे दी गई सूची से वही गेम चुनें जो आपके फोन में वास्तव में इंस्टॉल है!'
                        : 'No games linked yet. Select only the games you actually have installed below!'}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {verifiedInstalledGames.map((g) => (
                      <div
                        key={g.id}
                        className="flex items-center justify-between rounded-2xl border border-emerald-500/40 bg-emerald-950/20 p-2.5"
                      >
                        <div className="flex items-center gap-2.5">
                          <div className={`flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br ${g.iconBg} text-lg shadow`}>
                            {g.iconEmoji}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="text-xs font-bold text-white">{isHindi ? g.nameHindi : g.name}</span>
                              <span className="rounded bg-emerald-500/20 px-1 py-0.2 text-[9px] font-bold text-emerald-400">
                                {isHindi ? 'सत्यापित' : 'Verified'}
                              </span>
                            </div>
                            <span className="text-[10px] text-slate-400 font-mono">{g.packageName}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleConnectGameToHub(g)}
                            className="flex items-center gap-1 rounded-lg bg-emerald-600 px-2.5 py-1 text-xs font-bold text-white hover:bg-emerald-500 shadow-sm"
                          >
                            <Play className="h-3 w-3 fill-current" />
                            <span>{isHindi ? 'खेलें' : 'Play'}</span>
                          </button>
                          <button
                            onClick={() => handleToggleInstall(g)}
                            className="flex h-7 w-7 items-center justify-center rounded-lg bg-slate-800 text-rose-400 hover:bg-rose-950/40"
                            title={isHindi ? 'हटाएं' : 'Remove'}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* SECTION: 2. Add / Search Any Phone Game */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                  <Search className="h-3.5 w-3.5 text-cyan-400" />
                  {isHindi ? 'फोन गेम चुनें (Select Installed App)' : 'Select Installed App'}
                </span>

                {/* Search input */}
                <div className="relative">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={isHindi ? 'गेम का नाम खोजें (e.g. Block Blast, Free Fire)...' : 'Search game name...'}
                    className="w-full rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-2.5 top-2 text-xs text-slate-400 hover:text-white"
                    >
                      ✕
                    </button>
                  )}
                </div>

                {/* Catalog items */}
                <div className="grid grid-cols-2 gap-2">
                  {filteredCatalog.map((item) => {
                    const isInstalled = verifiedInstalledGames.some((g) => g.id === item.id);
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleToggleInstall(item)}
                        className={`flex items-center gap-2 rounded-xl border p-2 text-left transition-all ${
                          isInstalled
                            ? 'border-emerald-500/50 bg-emerald-950/30'
                            : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
                        }`}
                      >
                        <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br ${item.iconBg} text-base shadow`}>
                          {item.iconEmoji}
                        </div>
                        <div className="min-w-0 flex-1">
                          <span className="block truncate text-xs font-bold text-white">
                            {isHindi ? item.nameHindi : item.name}
                          </span>
                          <span className="block truncate text-[9px] text-slate-400">
                            {isInstalled ? (
                              <span className="text-emerald-400 font-semibold">✓ {isHindi ? 'इंस्टॉल है' : 'Installed'}</span>
                            ) : (
                              isHindi ? '+ जोड़ें' : '+ Add'
                            )}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Custom Game Name Input */}
                <form onSubmit={handleAddCustomGame} className="mt-2 flex gap-1.5">
                  <input
                    type="text"
                    value={customGameName}
                    onChange={(e) => setCustomGameName(e.target.value)}
                    placeholder={isHindi ? 'अन्य गेम का नाम या पैकेज (e.g. Candy Crush)...' : 'Other game name or package...'}
                    className="flex-1 rounded-xl border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="flex items-center gap-1 rounded-xl bg-cyan-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-cyan-500"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>{isHindi ? 'जोड़ें' : 'Add'}</span>
                  </button>
                </form>
              </div>
            </>
          ) : (
            /* Pairing & QR code tab */
            <div className="space-y-4 text-center py-4">
              <div className="mx-auto flex h-36 w-36 items-center justify-center rounded-2xl border-2 border-dashed border-cyan-500/40 bg-slate-900 p-2">
                <div className="flex flex-col items-center justify-center">
                  <QrCode className="h-20 w-20 text-cyan-400" />
                  <span className="mt-1 text-[10px] font-mono text-emerald-400">AUTO-PAIR READY</span>
                </div>
              </div>

              <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-3">
                <span className="block text-[10px] text-slate-400">PAIRING PIN CODE</span>
                <span className="font-mono text-base font-bold text-cyan-400">{pairingCode}</span>
              </div>

              <div className="flex items-center justify-center gap-2 text-xs text-emerald-400">
                <ShieldCheck className="h-4 w-4" />
                <span>{isHindi ? '100% सुरक्षित स्थानीय स्क्रीन ऑटोमेशन' : '100% Secure Local Screen Automation'}</span>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-800 bg-slate-900/90 p-3 text-center">
          <button
            onClick={onClose}
            className="w-full rounded-xl bg-slate-800 py-2 text-xs font-bold text-slate-300 hover:bg-slate-700"
          >
            {isHindi ? 'बंद करें' : 'Close'}
          </button>
        </div>
      </div>

      {/* Setup Wizard */}
      {selectedGameForSetup && (
        <GameSetupModal
          isOpen={!!selectedGameForSetup}
          onClose={() => setSelectedGameForSetup(null)}
          game={{
            name: selectedGameForSetup.name,
            nameHindi: selectedGameForSetup.nameHindi,
            category: selectedGameForSetup.category,
            description: selectedGameForSetup.tag,
            descriptionHindi: selectedGameForSetup.tagHindi,
            packageName: selectedGameForSetup.packageName,
            bossName: `${selectedGameForSetup.name} Boss`,
            initialScore: selectedGameForSetup.initialScore,
            speed: 3
          }}
          language={language}
          onConfirm={(config) => {
            handleConnectGameToHub(selectedGameForSetup);
            setSelectedGameForSetup(null);
          }}
        />
      )}
    </div>
  );
};
