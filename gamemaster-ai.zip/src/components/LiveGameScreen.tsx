import React, { useEffect, useRef, useState } from 'react';
import { GameBotState } from '../types';

interface LiveGameScreenProps {
  game: GameBotState;
  language: 'hi' | 'en';
  height?: number;
  showOverlayStats?: boolean;
}

interface TouchPoint {
  id: number;
  x: number;
  y: number;
  type: 'tap' | 'swipe' | 'drag' | 'slice';
  alpha: number;
  radius: number;
  label?: string;
  color?: string;
}

export const LiveGameScreen: React.FC<LiveGameScreenProps> = ({
  game,
  language,
  height = 280,
  showOverlayStats = true
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isHindi = language === 'hi';
  const touchesRef = useRef<TouchPoint[]>([]);
  const frameRef = useRef(0);
  const [currentStageName, setCurrentStageName] = useState<string>('Live Gameplay');

  const gameRef = useRef(game);
  gameRef.current = game;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    // Block Blast Internal Board Simulator
    let blockGrid: number[][] = Array(8).fill(0).map(() => Array(8).fill(0));
    for (let r = 3; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        if (Math.random() > 0.45) {
          blockGrid[r][c] = Math.floor(Math.random() * 5) + 1;
        }
      }
    }

    const blockQueue = [
      { shape: [[1, 1], [1, 1]], color: 1, name: '2x2' },
      { shape: [[1, 1, 1]], color: 2, name: '3x1' },
      { shape: [[1, 0], [1, 1]], color: 3, name: 'L' }
    ];

    // Fruit Ninja fruits simulator
    let activeFruits: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      radius: number;
      type: 'watermelon' | 'orange' | 'banana' | 'strawberry';
      sliced: boolean;
      sliceProgress: number;
    }> = [];

    // Subway Surfers / Runner State
    let runnerLane = 1;
    let runnerY = 0;

    const blockColors = ['#0f172a', '#06b6d4', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899'];

    const render = () => {
      frameRef.current++;
      const frame = frameRef.current;
      const w = canvas.width;
      const h = canvas.height;
      const g = gameRef.current;

      // Authentic mobile game lifecycle cycle (800 frames ~ 13 seconds full cycle)
      // 0..90: Splash / Loading Screen
      // 91..180: Game Main Menu / Lobby Screen (Tap Play)
      // 181..680: Real Gameplay Active
      // 681..740: Victory / Level Clear Popup
      // 741..800: Ad Popup with AI Auto-Dismiss [X]
      const cycleLength = 800;
      const phase = frame % cycleLength;

      // Clear Canvas
      ctx.fillStyle = '#090d16';
      ctx.fillRect(0, 0, w, h);

      // ==========================================================
      // STAGE A: GAME STARTUP / SPLASH & LOADING BAR (0..90)
      // ==========================================================
      if (phase < 90) {
        // Gradient Splash Background
        const grad = ctx.createLinearGradient(0, 0, 0, h);
        grad.addColorStop(0, '#0f172a');
        grad.addColorStop(1, '#020617');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);

        // Studio / Game Logo Icon
        ctx.fillStyle = '#1e293b';
        ctx.beginPath();
        ctx.arc(w / 2, h * 0.35, 34, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2.5;
        ctx.stroke();

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 24px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(g.category === 'fruit_ninja' ? '🍉' : g.category === 'block_blast' ? '🧩' : g.category === 'cyber_runner' ? '🏃' : '🎮', w / 2, h * 0.35 + 8);

        // Game Title
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 15px sans-serif';
        ctx.fillText(isHindi ? g.nameHindi : g.name, w / 2, h * 0.53);

        // Package Subtitle
        ctx.fillStyle = '#64748b';
        ctx.font = '10px monospace';
        ctx.fillText(g.phonePackageName || 'com.mobile.game.hd', w / 2, h * 0.6);

        // Loading Bar
        const barW = w * 0.65;
        const barH = 8;
        const barX = (w - barW) / 2;
        const barY = h * 0.72;
        const loadProgress = Math.min(1, phase / 80);

        ctx.fillStyle = '#1e293b';
        ctx.beginPath();
        ctx.roundRect ? ctx.roundRect(barX, barY, barW, barH, 4) : ctx.fillRect(barX, barY, barW, barH);
        ctx.fill();

        ctx.fillStyle = '#06b6d4';
        ctx.beginPath();
        ctx.roundRect ? ctx.roundRect(barX, barY, barW * loadProgress, barH, 4) : ctx.fillRect(barX, barY, barW * loadProgress, barH);
        ctx.fill();

        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 10px monospace';
        ctx.fillText(`LOADING ASSETS... ${Math.floor(loadProgress * 100)}%`, w / 2, barY + 20);
      }

      // ==========================================================
      // STAGE B: MAIN MENU / LOBBY (91..180)
      // ==========================================================
      else if (phase < 180) {
        // Lobby Background
        ctx.fillStyle = '#0b1329';
        ctx.fillRect(0, 0, w, h);

        // Top currency bar
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(0, 0, w, 28);
        ctx.fillStyle = '#f59e0b';
        ctx.font = 'bold 11px sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(`🪙 ${g.coins.toLocaleString()}`, 12, 18);
        ctx.fillStyle = '#38bdf8';
        ctx.textAlign = 'right';
        ctx.fillText(`💎 ${g.crystals} GEMS`, w - 12, 18);

        // Game Title Banner
        ctx.fillStyle = '#ffffff';
        ctx.font = '900 18px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(isHindi ? g.nameHindi : g.name, w / 2, h * 0.32);

        ctx.fillStyle = '#10b981';
        ctx.font = 'bold 12px sans-serif';
        ctx.fillText(`🏆 BEST: ${(g.score + 5000).toLocaleString()}`, w / 2, h * 0.42);

        // Big "TAP TO PLAY" Button
        const btnW = 140;
        const btnH = 40;
        const btnX = (w - btnW) / 2;
        const btnY = h * 0.58;

        ctx.fillStyle = '#16a34a';
        ctx.beginPath();
        ctx.roundRect ? ctx.roundRect(btnX, btnY, btnW, btnH, 12) : ctx.fillRect(btnX, btnY, btnW, btnH);
        ctx.fill();
        ctx.strokeStyle = '#4ade80';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 14px sans-serif';
        ctx.fillText(isHindi ? '▶ शुरू करें (PLAY)' : '▶ TAP TO PLAY', w / 2, btnY + 25);

        // Simulated AI Hand Click on Play Button at frame ~150
        const tapX = w / 2;
        const tapY = btnY + btnH / 2;
        if (phase > 140 && phase < 170) {
          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.arc(tapX, tapY, 18 + Math.sin(frame * 0.3) * 4, 0, Math.PI * 2);
          ctx.stroke();
          ctx.fillStyle = 'rgba(56, 189, 248, 0.4)';
          ctx.fill();

          if (phase === 150) {
            touchesRef.current.push({
              id: Date.now(),
              x: tapX,
              y: tapY,
              type: 'tap',
              alpha: 1,
              radius: 20,
              label: isHindi ? 'प्ले बटन दबाया' : 'Play Tapped!',
              color: '#4ade80'
            });
          }
        }
      }

      // ==========================================================
      // STAGE C: ACTIVE GAMEPLAY (181..680)
      // ==========================================================
      else if (phase < 680) {
        // 1. BLOCK BLAST GAMEPLAY
        if (g.category === 'block_blast' || g.name.toLowerCase().includes('block')) {
          const gridCols = 8;
          const gridRows = 8;
          const cellSize = Math.min(Math.floor((w - 40) / gridCols), Math.floor((h * 0.58) / gridRows));
          const boardW = cellSize * gridCols;
          const boardH = cellSize * gridRows;
          const startX = Math.floor((w - boardW) / 2);
          const startY = Math.floor(h * 0.12);

          // Top Status Header
          ctx.fillStyle = '#1e293b';
          ctx.fillRect(0, 0, w, Math.floor(h * 0.1));
          
          ctx.fillStyle = '#f59e0b';
          ctx.font = 'bold 12px sans-serif';
          ctx.textAlign = 'left';
          ctx.fillText(`👑 HIGH: ${(g.score + 14200).toLocaleString()}`, 12, 18);

          ctx.fillStyle = '#ffffff';
          ctx.font = '900 16px sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText(`${g.score.toLocaleString()}`, w / 2, 20);

          ctx.fillStyle = '#38bdf8';
          ctx.font = 'bold 10px sans-serif';
          ctx.textAlign = 'right';
          ctx.fillText(`⚡ COMBO x${Math.floor((frame / 40) % 5) + 1}`, w - 12, 18);

          // 8x8 Board Box
          ctx.fillStyle = '#0f172a';
          ctx.beginPath();
          ctx.roundRect ? ctx.roundRect(startX - 4, startY - 4, boardW + 8, boardH + 8, 8) : ctx.fillRect(startX - 4, startY - 4, boardW + 8, boardH + 8);
          ctx.fill();
          ctx.strokeStyle = '#334155';
          ctx.lineWidth = 1.5;
          ctx.stroke();

          // Render 8x8 Grid Cells
          for (let r = 0; r < gridRows; r++) {
            for (let c = 0; c < gridCols; c++) {
              const val = blockGrid[r][c];
              const cx = startX + c * cellSize;
              const cy = startY + r * cellSize;

              ctx.fillStyle = '#1e293b';
              ctx.fillRect(cx + 1, cy + 1, cellSize - 2, cellSize - 2);

              if (val > 0) {
                ctx.fillStyle = blockColors[val % blockColors.length];
                ctx.fillRect(cx + 2, cy + 2, cellSize - 4, cellSize - 4);
                ctx.fillStyle = 'rgba(255,255,255,0.4)';
                ctx.fillRect(cx + 2, cy + 2, cellSize - 4, 3);
              }
            }
          }

          // Drag / Move Cycle
          const placementCycle = 80;
          const moveProgress = (frame % placementCycle) / placementCycle;
          const currentBlockIdx = Math.floor(frame / placementCycle) % 3;
          const currentBlock = blockQueue[currentBlockIdx];

          const trayY = startY + boardH + 14;
          const traySpacing = w / 3;

          for (let i = 0; i < 3; i++) {
            const shapeObj = blockQueue[i];
            const shapeX = traySpacing * i + traySpacing / 2;
            const shapeY = trayY + 20;
            const miniCell = 8;
            const sRows = shapeObj.shape.length;
            const sCols = shapeObj.shape[0].length;
            const sW = sCols * miniCell;
            const sH = sRows * miniCell;

            ctx.fillStyle = '#1e293b';
            ctx.beginPath();
            ctx.arc(shapeX, shapeY, 18, 0, Math.PI * 2);
            ctx.fill();

            for (let sr = 0; sr < sRows; sr++) {
              for (let sc = 0; sc < sCols; sc++) {
                if (shapeObj.shape[sr][sc]) {
                  ctx.fillStyle = blockColors[shapeObj.color % blockColors.length];
                  ctx.fillRect(shapeX - sW / 2 + sc * miniCell, shapeY - sH / 2 + sr * miniCell, miniCell - 1, miniCell - 1);
                }
              }
            }
          }

          const targetRow = (currentBlockIdx * 2 + 1) % 6;
          const targetCol = (currentBlockIdx * 3 + 2) % 6;
          const fromX = traySpacing * currentBlockIdx + traySpacing / 2;
          const fromY = trayY + 20;
          const toX = startX + targetCol * cellSize + cellSize / 2;
          const toY = startY + targetRow * cellSize + cellSize / 2;

          const currentTouchX = fromX + (toX - fromX) * Math.min(1, moveProgress * 1.3);
          const currentTouchY = fromY + (toY - fromY) * Math.min(1, moveProgress * 1.3);

          if (moveProgress > 0.85 && moveProgress < 0.95) {
            if (frame % placementCycle === Math.floor(placementCycle * 0.86)) {
              for (let sr = 0; sr < currentBlock.shape.length; sr++) {
                for (let sc = 0; sc < currentBlock.shape[0].length; sc++) {
                  if (currentBlock.shape[sr][sc]) {
                    const rPos = Math.min(7, targetRow + sr);
                    const cPos = Math.min(7, targetCol + sc);
                    blockGrid[rPos][cPos] = currentBlock.color;
                  }
                }
              }
              touchesRef.current.push({
                id: Date.now(),
                x: toX,
                y: toY,
                type: 'drag',
                alpha: 1,
                radius: 14,
                label: isHindi ? 'ब्लॉक रखा (+120)' : 'Block Placed +120',
                color: '#38bdf8'
              });
            }
          }

          // Dragged piece
          if (moveProgress < 0.9) {
            const miniCell = cellSize;
            const sRows = currentBlock.shape.length;
            const sCols = currentBlock.shape[0].length;
            for (let sr = 0; sr < sRows; sr++) {
              for (let sc = 0; sc < sCols; sc++) {
                if (currentBlock.shape[sr][sc]) {
                  ctx.fillStyle = blockColors[currentBlock.color % blockColors.length];
                  ctx.globalAlpha = 0.85;
                  ctx.fillRect(currentTouchX - (sCols * miniCell) / 2 + sc * miniCell, currentTouchY - (sRows * miniCell) / 2 + sr * miniCell, miniCell - 2, miniCell - 2);
                  ctx.globalAlpha = 1.0;
                }
              }
            }
          }

          // Finger Touch Ring
          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.arc(currentTouchX, currentTouchY, 14 + Math.sin(frame * 0.2) * 3, 0, Math.PI * 2);
          ctx.stroke();
          ctx.fillStyle = 'rgba(56, 189, 248, 0.4)';
          ctx.beginPath();
          ctx.arc(currentTouchX, currentTouchY, 8, 0, Math.PI * 2);
          ctx.fill();
        }

        // 2. FRUIT NINJA GAMEPLAY
        else if (g.category === 'fruit_ninja' || g.name.toLowerCase().includes('fruit')) {
          ctx.fillStyle = '#27170a';
          ctx.fillRect(0, 0, w, h);
          ctx.strokeStyle = '#3f2512';
          ctx.lineWidth = 2;
          for (let y = 0; y < h; y += 24) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(w, y);
            ctx.stroke();
          }

          ctx.fillStyle = '#f59e0b';
          ctx.font = '900 18px sans-serif';
          ctx.textAlign = 'left';
          ctx.fillText(`🍉 ${g.score.toLocaleString()}`, 14, 26);
          ctx.textAlign = 'right';
          ctx.font = 'bold 14px sans-serif';
          ctx.fillStyle = '#ef4444';
          ctx.fillText('❌ ❌ ❌', w - 12, 24);

          if (frame % 45 === 0 && activeFruits.length < 5) {
            const types: Array<'watermelon' | 'orange' | 'banana' | 'strawberry'> = ['watermelon', 'orange', 'banana', 'strawberry'];
            const randomType = types[Math.floor(Math.random() * types.length)];
            activeFruits.push({
              x: 40 + Math.random() * (w - 80),
              y: h + 20,
              vx: (Math.random() - 0.5) * 4,
              vy: -(8 + Math.random() * 4),
              radius: randomType === 'watermelon' ? 18 : 14,
              type: randomType,
              sliced: false,
              sliceProgress: 0
            });
          }

          for (let i = activeFruits.length - 1; i >= 0; i--) {
            const f = activeFruits[i];
            f.x += f.vx;
            f.y += f.vy;
            f.vy += 0.22;

            if (f.y > h + 40 && f.vy > 0) {
              activeFruits.splice(i, 1);
              continue;
            }

            if (!f.sliced && f.vy > -2 && f.y < h * 0.75) {
              f.sliced = true;
              touchesRef.current.push({
                id: Date.now() + i,
                x: f.x,
                y: f.y,
                type: 'slice',
                alpha: 1,
                radius: 20,
                label: isHindi ? 'स्लाइस! (+10)' : 'Sliced! +10',
                color: '#ef4444'
              });
            }

            if (!f.sliced) {
              ctx.fillStyle = f.type === 'watermelon' ? '#16a34a' : f.type === 'orange' ? '#ea580c' : '#eab308';
              ctx.beginPath();
              ctx.arc(f.x, f.y, f.radius, 0, Math.PI * 2);
              ctx.fill();
            } else {
              f.sliceProgress += 2.5;
              const sep = f.sliceProgress;
              ctx.fillStyle = f.type === 'watermelon' ? '#ef4444' : '#f97316';
              ctx.beginPath();
              ctx.arc(f.x - sep, f.y, f.radius, Math.PI / 2, (3 * Math.PI) / 2);
              ctx.fill();
              ctx.beginPath();
              ctx.arc(f.x + sep, f.y, f.radius, -(Math.PI / 2), Math.PI / 2);
              ctx.fill();
            }
          }

          const slashPhase = (frame * 0.12) % Math.PI;
          const slashX1 = 30 + (Math.sin(slashPhase) * (w - 60));
          const slashY1 = h * 0.6 + Math.cos(slashPhase * 2) * 40;
          const slashX2 = slashX1 + 50;
          const slashY2 = slashY1 - 40;

          ctx.strokeStyle = 'rgba(56, 189, 248, 0.9)';
          ctx.lineWidth = 4;
          ctx.beginPath();
          ctx.moveTo(slashX1 - 25, slashY1 + 20);
          ctx.quadraticCurveTo(slashX1, slashY1, slashX2, slashY2);
          ctx.stroke();
        }

        // 3. SUBWAY SURFERS / 3D RUNNER GAMEPLAY
        else if (g.category === 'cyber_runner' || g.name.toLowerCase().includes('subway') || g.name.toLowerCase().includes('surf')) {
          ctx.fillStyle = '#0f172a';
          ctx.fillRect(0, 0, w, h * 0.35);

          ctx.fillStyle = '#1e293b';
          ctx.beginPath();
          ctx.moveTo(w * 0.35, h * 0.35);
          ctx.lineTo(w * 0.65, h * 0.35);
          ctx.lineTo(w, h);
          ctx.lineTo(0, h);
          ctx.closePath();
          ctx.fill();

          const trackY1 = h * 0.35;
          const trackY2 = h;

          for (let i = 0; i < 8; i++) {
            const ty = trackY1 + ((frame * 4 + i * 35) % (trackY2 - trackY1));
            const p = (ty - trackY1) / (trackY2 - trackY1);
            const tw = (w * 0.3) + p * (w * 0.7);
            const tx = (w - tw) / 2;

            ctx.strokeStyle = '#334155';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(tx, ty);
            ctx.lineTo(tx + tw, ty);
            ctx.stroke();
          }

          if (frame % 55 === 0) {
            runnerLane = Math.floor(Math.random() * 3);
            touchesRef.current.push({
              id: Date.now(),
              x: (w / 3) * runnerLane + w / 6,
              y: h * 0.8,
              type: 'swipe',
              alpha: 1,
              radius: 16,
              label: isHindi ? 'स्वाइप लेन' : 'Swipe Lane',
              color: '#10b981'
            });
          }

          const charX = (w / 3) * runnerLane + w / 6;
          const charY = h * 0.78;

          ctx.fillStyle = '#f59e0b';
          ctx.fillRect(charX - 14, charY + 12, 28, 6);
          ctx.fillStyle = '#06b6d4';
          ctx.fillRect(charX - 8, charY - 14, 16, 24);
          ctx.fillStyle = '#ef4444';
          ctx.beginPath();
          ctx.arc(charX, charY - 18, 7, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = '#f59e0b';
          ctx.font = '900 16px sans-serif';
          ctx.textAlign = 'left';
          ctx.fillText(`⚡ 30x | ${g.score.toLocaleString()}m`, 14, 24);
        }

        // 4. ACTION / LUDO / OTHER GAMEPLAY
        else {
          ctx.fillStyle = '#0f172a';
          ctx.fillRect(0, 0, w, h);
          ctx.strokeStyle = '#1e293b';
          ctx.lineWidth = 1.5;
          for (let x = 0; x < w; x += 25) {
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, h);
            ctx.stroke();
          }

          const targetX = w / 2 + Math.sin(frame * 0.05) * 50;
          const targetY = h / 2 + Math.cos(frame * 0.05) * 35;

          ctx.fillStyle = 'rgba(16, 185, 129, 0.2)';
          ctx.beginPath();
          ctx.arc(targetX, targetY, 24, 0, Math.PI * 2);
          ctx.fill();

          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(targetX, targetY, 18, 0, Math.PI * 2);
          ctx.stroke();

          if (frame % 50 === 0) {
            touchesRef.current.push({
              id: Date.now(),
              x: targetX,
              y: targetY,
              type: 'tap',
              alpha: 1,
              radius: 15,
              label: isHindi ? 'क्लिक (+50 XP)' : 'Tap Hit +50',
              color: '#38bdf8'
            });
          }
        }
      }

      // ==========================================================
      // STAGE D: VICTORY / LEVEL CLEAR BANNER (681..740)
      // ==========================================================
      else if (phase < 740) {
        ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
        ctx.fillRect(0, 0, w, h);

        ctx.fillStyle = '#f59e0b';
        ctx.font = '900 20px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(isHindi ? '🎉 लेवल पूरा हुआ!' : '🎉 LEVEL CLEARED!', w / 2, h * 0.38);

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 13px sans-serif';
        ctx.fillText(`+${(g.level * 500).toLocaleString()} XP & +250 🪙 Coins`, w / 2, h * 0.5);

        // Auto Next Button
        const nextBtnY = h * 0.62;
        ctx.fillStyle = '#06b6d4';
        ctx.beginPath();
        ctx.roundRect ? ctx.roundRect(w / 2 - 60, nextBtnY, 120, 36, 10) : ctx.fillRect(w / 2 - 60, nextBtnY, 120, 36);
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 12px sans-serif';
        ctx.fillText(isHindi ? 'अगला राउंड ▶' : 'CONTINUE ▶', w / 2, nextBtnY + 22);

        if (phase === 710) {
          touchesRef.current.push({
            id: Date.now(),
            x: w / 2,
            y: nextBtnY + 18,
            type: 'tap',
            alpha: 1,
            radius: 16,
            label: isHindi ? 'जारी रखें' : 'Continue Clicked',
            color: '#06b6d4'
          });
        }
      }

      // ==========================================================
      // STAGE E: INTERSTITIAL AD POPUP WITH AI AUTO [X] (741..800)
      // ==========================================================
      else {
        // Ad Overlay
        ctx.fillStyle = '#1e1b4b';
        ctx.fillRect(0, 0, w, h);

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 12px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('📢 SPONSORED ADVERTISEMENT', w / 2, h * 0.35);

        ctx.fillStyle = '#a5b4fc';
        ctx.font = '10px sans-serif';
        ctx.fillText('Special Offer • Play Free Now', w / 2, h * 0.45);

        // Top-Right [X] Close Ad Button
        const xBtnX = w - 30;
        const xBtnY = 24;

        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.arc(xBtnX, xBtnY, 14, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.fillStyle = '#ffffff';
        ctx.font = '900 13px sans-serif';
        ctx.fillText('✕', xBtnX, xBtnY + 4);

        // AI Auto-Dismiss Touch on [X] at frame 770
        if (phase >= 765) {
          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.arc(xBtnX, xBtnY, 18, 0, Math.PI * 2);
          ctx.stroke();

          if (phase === 770) {
            touchesRef.current.push({
              id: Date.now(),
              x: xBtnX,
              y: xBtnY,
              type: 'tap',
              alpha: 1,
              radius: 18,
              label: isHindi ? '🛡️ विज्ञापन ऑटो-कट [X]' : '🛡️ Ad Auto-Closed [X]',
              color: '#ef4444'
            });
          }
        }
      }

      // ==========================================================
      // RENDER ALL REAL CLICK & TOUCH RIPPLES
      // ==========================================================
      for (let i = touchesRef.current.length - 1; i >= 0; i--) {
        const t = touchesRef.current[i];
        t.alpha -= 0.025;
        t.radius += 1.2;

        if (t.alpha <= 0) {
          touchesRef.current.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.globalAlpha = t.alpha;
        ctx.strokeStyle = t.color || '#38bdf8';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(t.x, t.y, t.radius, 0, Math.PI * 2);
        ctx.stroke();

        ctx.fillStyle = t.color || '#38bdf8';
        ctx.beginPath();
        ctx.arc(t.x, t.y, 4, 0, Math.PI * 2);
        ctx.fill();

        if (t.label) {
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 10px sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText(t.label, t.x, t.y - t.radius - 4);
        }
        ctx.restore();
      }

      // Bottom Status bar
      if (showOverlayStats) {
        ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
        ctx.beginPath();
        ctx.roundRect ? ctx.roundRect(8, h - 26, w - 16, 20, 6) : ctx.fillRect(8, h - 26, w - 16, 20);
        ctx.fill();
        ctx.strokeStyle = '#334155';
        ctx.stroke();

        const stageTitle = phase < 90 ? (isHindi ? '1/4: गेम खुल रहा है (Loading)' : '1/4: Opening Game') :
                           phase < 180 ? (isHindi ? '2/4: मेन मेन्यू (Tapping Play)' : '2/4: Main Menu') :
                           phase < 680 ? (isHindi ? '3/4: लाइव गेमप्ले (Playing)' : '3/4: Live Gameplay') :
                           phase < 740 ? (isHindi ? '4/4: लेवल क्लियर' : '4/4: Victory') :
                           (isHindi ? '🛡️ विज्ञापन ऑटो-कट' : '🛡️ Ad Auto-Dismiss');

        ctx.fillStyle = '#10b981';
        ctx.font = 'bold 9px monospace';
        ctx.textAlign = 'left';
        ctx.fillText(`🔴 ${stageTitle}`, 14, h - 13);

        ctx.fillStyle = '#38bdf8';
        ctx.textAlign = 'right';
        ctx.fillText(`⚡ ${g.actionsPerMinute} APM`, w - 14, h - 13);
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [game.id, game.category]);

  return (
    <div className="relative w-full overflow-hidden rounded-2xl border border-slate-700 bg-slate-950 shadow-inner">
      <canvas
        ref={canvasRef}
        width={360}
        height={height}
        className="h-full w-full object-cover"
      />

      {/* Screen Header Badge */}
      <div className="absolute top-2 left-2 flex items-center gap-1.5 rounded-lg border border-emerald-500/30 bg-slate-900/90 px-2 py-1 shadow-md">
        <span className="h-2 w-2 animate-ping rounded-full bg-emerald-400" />
        <span className="text-[10px] font-bold text-white">
          {isHindi ? '🔴 लाइव मोबाइल स्क्रीन' : '🔴 Live Mobile Screen'}
        </span>
      </div>

      <div className="absolute top-2 right-2 rounded-lg border border-cyan-500/30 bg-slate-900/90 px-2 py-1 text-[10px] font-mono text-cyan-300">
        👆 {isHindi ? 'टच व क्लिक सक्रिय' : 'Touch Active'}
      </div>
    </div>
  );
};
